# Boss 直聘职位采集器

🚀 一个现代化、模块化的 Chrome 扩展，用于可视化采集 Boss 直聘职位数据。

## ✨ 特性

- 📌 **可视化选择器** - 点击选择列表元素，无需编写CSS选择器
- 🤖 **智能采集** - 自动滚动、去重、限制数量
- 🔍 **深度采集** - 可配置采集详情页额外字段
- 🛡️ **AI验证** - 本地AI智能验证数据准确性
- 📊 **Excel导出** - 一键导出为格式化的Excel文件
- ⚡ **性能优化** - 随机延迟、防检测
- 🎯 **模块化架构** - 标准化目录结构，易于维护和扩展

## 📁 项目结构

```
boss-job-scraper/
├── src/                    # 源代码目录
│   ├── background/        # Service Worker模块
│   ├── content/          # 内容脚本模块
│   ├── popup/            # 侧边栏界面模块
│   ├── utils/            # 通用工具库
│   ├── config/           # 配置管理
│   └── debug/            # 调试工具
├── assets/               # 静态资源
│   ├── icons/           # 图标
│   └── libs/            # 第三方库
└── docs/                # 文档
    ├── zh/             # 中文文档
    └── en/             # 英文文档
```

## 🚀 快速开始

### 安装

1. 克隆或下载本项目
2. 打开 Chrome 浏览器，进入 `chrome://extensions/`
3. 启用"开发者模式"
4. 点击"加载已解压的扩展程序"
5. 选择项目根目录

### 使用

详细使用说明请查看:
- 中文文档: [docs/zh/user/快速开始.md](docs/zh/user/快速开始.md)
- English: [docs/en/user/README.md](docs/en/user/README.md)

## 📚 文档

### 用户文档
- [快速开始](docs/zh/user/快速开始.md) - 新手入门指南
- [使用指南](docs/zh/user/使用指南.md) - 详细功能说明
- [深度采集使用说明](docs/zh/user/深度采集使用说明.md) - 高级功能

### 开发文档
- [实现文档](docs/en/dev/IMPLEMENTATION.md) - 技术实现说明
- [调试指南](docs/zh/dev/调试指南.md) - 开发调试方法
- [更新日志](docs/zh/dev/更新日志.md) - 版本历史

## 🛠️ 技术栈

- **Chrome Extension API** - Manifest V3
- **原生JavaScript** - ES6+模块化
- **SheetJS** - Excel导出
- **HTML5 + CSS3** - 侧边栏界面

## 📊 数据字段

### 基础字段 (列表页)
- 职位名称
- 公司名称
- 薪资范围
- 工作地点
- 工作经验

### 详情字段 (可配置)
- 职位描述
- 福利待遇
- HR活跃状态
- 公司规模
- 所属行业

## 🎯 版本信息

- **当前版本**: v1.3.0
- **Manifest**: V3
- **兼容性**: Chrome 88+

## 📝 License

MIT License

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## ⚠️ 免责声明

本工具仅供学习和研究使用，请遵守目标网站的 robots.txt 和服务条款。
