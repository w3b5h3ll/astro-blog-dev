# 归档文件说明

## v1.0/ - 旧版本代码

这些文件是项目迁移到 `src/` 目录结构之前的旧版本代码，已不再使用。
保留用于参考和回滚需要。

### 文件清单：

- `background.js` - 旧版 Service Worker（已迁移至 `src/background/index.js`）
- `content/` - 旧版内容脚本（已迁移至 `src/content/`）
- `popup/` - 旧版弹窗界面（已迁移至 `src/popup/`）
- `diagnostic-tool.js` - 旧版诊断工具（原文件名：`诊断工具.js`，已迁移至 `src/debug/diagnostics.js`）

### 注意事项：

- 这些文件不再被 `manifest.json` 引用
- 仅作为历史参考保留
- 如需回滚，请参考 Git 历史记录

## backups/ - 备份文件

开发过程中创建的临时备份文件。

### 文件清单：

- `deep-scraper.js.backup` - 深度采集器的备份版本
- `popup.js.backup` - 弹窗脚本的备份版本

### 注意事项：

- 这些是开发过程中的临时备份
- 可以安全删除，但保留用于紧急恢复
