// Background Service Worker
console.log('[Boss Scraper] Background service worker 已加载');

// 监听扩展安装事件
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[Boss Scraper] 扩展已安装/更新:', details.reason);

  if (details.reason === 'install') {
    // 首次安装，初始化存储
    chrome.storage.local.set({
      selectedSelector: null,
      scrapedJobs: [],
      config: {
        autoDedupe: true,
        scrollDelay: 1000
      }
    });

    // 打开欢迎页面（可选）
    // chrome.tabs.create({ url: 'https://www.zhipin.com' });
  }
});

// 监听扩展图标点击事件，打开侧边栏
chrome.action.onClicked.addListener(async (tab) => {
  // 打开侧边栏
  await chrome.sidePanel.open({ windowId: tab.windowId });
});

// 监听来自 content script 和 popup 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Background] 收到消息:', message.action, 'from:', sender.tab ? 'content' : 'popup');

  switch (message.action) {
    case 'selectorConfirmed':
      handleSelectorConfirmed(message, sender);
      break;

    case 'selectorCancelled':
      handleSelectorCancelled(sender);
      break;

    case 'updateProgress':
      forwardToPopup(message);
      break;

    case 'scrapingComplete':
      handleScrapingComplete(message);
      break;

    case 'scrapingError':
      forwardToPopup(message);
      break;
  }

  return true; // 保持消息通道开放
});

// 处理选择器确认
function handleSelectorConfirmed(message, sender) {
  console.log('[Background] 保存选择器:', message.selector);

  // 保存到存储
  chrome.storage.local.set({
    selectedSelector: message.selector
  });

  // 转发到 popup（如果打开）
  forwardToPopup(message);
}

// 处理选择器取消
function handleSelectorCancelled(sender) {
  console.log('[Background] 选择器已取消');
  forwardToPopup({ action: 'selectorCancelled' });
}

// 处理采集完成
function handleScrapingComplete(message) {
  console.log('[Background] 采集完成，保存数据:', message.count, '条');

  // 保存数据到存储
  chrome.storage.local.set({
    scrapedJobs: message.jobs,
    lastScrapedAt: new Date().toISOString()
  });

  // 转发到 popup
  forwardToPopup(message);

  // 显示通知
  showNotification('采集完成', `成功采集 ${message.count} 条职位信息`);
}

// 转发消息到 popup
function forwardToPopup(message) {
  chrome.runtime.sendMessage(message).catch(err => {
    // Popup 可能未打开，忽略错误
    console.log('[Background] Popup 未打开，消息未转发');
  });
}

// 显示系统通知
function showNotification(title, message) {
  // Chrome Extensions 不再需要 notifications 权限即可显示基础通知
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: title,
      message: message,
      priority: 2
    }).catch(err => {
      console.log('[Background] 通知权限未授予或不支持');
    });
  } catch (error) {
    console.log('[Background] 通知功能不可用');
  }
}

// 监听存储变化（用于调试）
chrome.storage.onChanged.addListener((changes, areaName) => {
  console.log('[Background] 存储已更新:', Object.keys(changes));
});
