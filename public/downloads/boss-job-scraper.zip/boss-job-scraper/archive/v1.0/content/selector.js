// 元素选择器类 - 实现可视化元素选择功能
class ElementSelector {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.selectedElement = null;
    this.currentElement = null;
    this.isActive = false;
    this.confirmDialog = null;
    this.isDetailFieldMode = false; // 是否是详情页字段配置模式
    this.isListFieldMode = false; // 是否是列表页字段配置模式
    this.detailField = null; // 当前配置的字段
    this.detailFieldName = null; // 当前配置的字段名称
    this.listField = null; // 列表页字段
    this.listFieldName = null; // 列表页字段名称

    // 绑定事件处理函数
    this.boundMouseMove = this.handleMouseMove.bind(this);
    this.boundClick = this.handleClick.bind(this);
    this.boundKeyDown = this.handleKeyDown.bind(this);
  }

  // 创建 Canvas 遮罩层
  createCanvas() {
    const canvas = document.createElement('canvas');
    canvas.id = 'boss-scraper-canvas';
    canvas.style.cssText = `
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      z-index: 999999 !important;
      pointer-events: none !important;
      cursor: crosshair !important;
    `;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    return canvas;
  }

  // 激活选择模式
  activate() {
    if (this.isActive) return;

    this.isActive = true;
    this.isDetailFieldMode = false;
    this.canvas = this.createCanvas();
    this.ctx = this.canvas.getContext('2d');

    document.body.appendChild(this.canvas);
    this.canvas.style.pointerEvents = 'auto';

    // 添加事件监听
    document.addEventListener('mousemove', this.boundMouseMove, true);
    document.addEventListener('click', this.boundClick, true);
    document.addEventListener('keydown', this.boundKeyDown, true);

    // 显示提示信息
    this.showTip('移动鼠标选择元素，点击确认。按 ESC 取消。');
  }

  // 激活详情页字段选择模式
  activateForDetailField(field, fieldName) {
    if (this.isActive) return;

    this.isActive = true;
    this.isDetailFieldMode = true;
    this.isListFieldMode = false;
    this.detailField = field;
    this.detailFieldName = fieldName;

    this.canvas = this.createCanvas();
    this.ctx = this.canvas.getContext('2d');

    document.body.appendChild(this.canvas);
    this.canvas.style.pointerEvents = 'auto';

    // 添加事件监听
    document.addEventListener('mousemove', this.boundMouseMove, true);
    document.addEventListener('click', this.boundClick, true);
    document.addEventListener('keydown', this.boundKeyDown, true);

    // 显示提示信息
    this.showTip(`请选择: ${fieldName}，点击确认。按 ESC 取消。`);
  }

  // 激活列表页字段选择模式
  activateForListField(field, fieldName) {
    if (this.isActive) return;

    this.isActive = true;
    this.isDetailFieldMode = false;
    this.isListFieldMode = true;
    this.listField = field;
    this.listFieldName = fieldName;

    this.canvas = this.createCanvas();
    this.ctx = this.canvas.getContext('2d');

    document.body.appendChild(this.canvas);
    this.canvas.style.pointerEvents = 'auto';

    // 添加事件监听
    document.addEventListener('mousemove', this.boundMouseMove, true);
    document.addEventListener('click', this.boundClick, true);
    document.addEventListener('keydown', this.boundKeyDown, true);

    // 显示提示信息
    this.showTip(`请在单个职位卡片内选择: ${fieldName}，点击确认。按 ESC 取消。`);
  }

  // 处理鼠标移动
  handleMouseMove(e) {
    // 临时移除 canvas 以获取下方元素
    this.canvas.style.pointerEvents = 'none';
    const element = document.elementFromPoint(e.clientX, e.clientY);
    this.canvas.style.pointerEvents = 'auto';

    if (element && element !== this.canvas && element !== document.body) {
      this.currentElement = element;
      this.highlightElement(element);
    }
  }

  // 高亮元素
  highlightElement(element) {
    const rect = element.getBoundingClientRect();

    // 清空画布
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // 绘制半透明背景
    this.ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // 清除高亮区域（显示原始内容）
    this.ctx.clearRect(
      rect.left,
      rect.top,
      rect.width,
      rect.height
    );

    // 绘制蓝色边框
    this.ctx.strokeStyle = '#2196F3';
    this.ctx.lineWidth = 3;
    this.ctx.strokeRect(
      rect.left,
      rect.top,
      rect.width,
      rect.height
    );

    // 绘制元素信息标签
    this.drawInfoTag(element, rect);
  }

  // 绘制元素信息标签
  drawInfoTag(element, rect) {
    const tagName = element.tagName.toLowerCase();
    const className = element.className ? `.${Array.from(element.classList).join('.')}` : '';
    const info = `${tagName}${className}`;

    // 设置字体
    this.ctx.font = '12px Arial';
    const textWidth = this.ctx.measureText(info).width;

    // 标签位置（在元素上方）
    const tagX = rect.left;
    const tagY = Math.max(20, rect.top - 5);

    // 绘制标签背景
    this.ctx.fillStyle = '#2196F3';
    this.ctx.fillRect(tagX, tagY - 18, textWidth + 10, 20);

    // 绘制标签文字
    this.ctx.fillStyle = '#FFFFFF';
    this.ctx.fillText(info, tagX + 5, tagY - 4);
  }

  // 处理点击事件
  handleClick(e) {
    e.preventDefault();
    e.stopPropagation();

    if (this.currentElement) {
      this.selectedElement = this.currentElement;
      this.deactivate();
      this.showConfirmDialog();
    }
  }

  // 处理键盘事件
  handleKeyDown(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      this.cancel();
    }
  }

  // 显示确认对话框
  showConfirmDialog() {
    // 如果是详情页字段模式，直接确认
    if (this.isDetailFieldMode) {
      this.confirmDetailFieldSelection();
      return;
    }

    // 如果是列表页字段模式，直接确认
    if (this.isListFieldMode) {
      this.confirmListFieldSelection();
      return;
    }

    // 否则使用原有的列表容器确认逻辑
    const selector = this.generateSelector(this.selectedElement);
    const elementsCount = document.querySelectorAll(this.getParentSelector()).length;
    const childrenCount = this.selectedElement.children.length;
    const tagName = this.selectedElement.tagName;
    const className = this.selectedElement.className || '(无)';

    this.confirmDialog = document.createElement('div');
    this.confirmDialog.id = 'boss-scraper-dialog';
    this.confirmDialog.innerHTML = `
      <div style="
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 24px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        z-index: 1000000;
        min-width: 400px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      ">
        <h3 style="margin: 0 0 16px 0; color: #333; font-size: 18px;">确认选择区域</h3>

        <div style="margin-bottom: 12px;">
          <label style="display: block; color: #666; font-size: 14px; margin-bottom: 4px;">元素信息:</label>
          <div style="background: #f5f5f5; padding: 12px; border-radius: 4px; font-size: 13px;">
            <div style="margin-bottom: 4px;">📌 标签: <strong>${tagName}</strong></div>
            <div style="margin-bottom: 4px;">🏷️ 类名: <strong>${className}</strong></div>
            <div style="margin-bottom: 4px;">👶 子元素数量: <strong style="color: ${childrenCount > 10 ? '#4CAF50' : childrenCount > 1 ? '#FF9800' : '#f44336'}">${childrenCount} 个</strong></div>
            <div>📊 页面相似元素: <strong>${elementsCount} 个</strong></div>
          </div>
        </div>

        <div style="margin-bottom: 12px;">
          <label style="display: block; color: #666; font-size: 14px; margin-bottom: 4px;">生成的选择器:</label>
          <code style="
            display: block;
            background: #f5f5f5;
            padding: 8px;
            border-radius: 4px;
            font-size: 12px;
            word-break: break-all;
            color: #d63384;
          ">${selector}</code>
        </div>

        <div style="margin-bottom: 20px; padding: 12px; background: ${childrenCount > 10 ? '#e8f5e9' : '#fff3e0'}; border-radius: 4px; border-left: 4px solid ${childrenCount > 10 ? '#4CAF50' : '#FF9800'};">
          <div style="color: ${childrenCount > 10 ? '#2e7d32' : '#f57c00'}; font-size: 14px; font-weight: 500;">
            ${childrenCount > 10 ? '✅ 看起来不错！' : childrenCount > 1 ? '⚠️ 子元素较少' : '❌ 这可能是单个职位'}
          </div>
          <div style="color: #666; font-size: 12px; margin-top: 4px;">
            ${childrenCount > 10 ? '这个容器包含多个元素，应该是正确的列表容器' : childrenCount > 1 ? '建议点击"向上一层"寻找包含更多子元素的容器' : '这是单个职位卡片，请点击"向上一层"'}
          </div>
        </div>

        <div style="display: flex; gap: 12px; justify-content: flex-end;">
          <button id="boss-dialog-cancel" style="
            padding: 8px 20px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
          ">✖ 取消</button>

          <button id="boss-dialog-adjust" style="
            padding: 8px 20px;
            border: 1px solid #2196F3;
            background: white;
            color: #2196F3;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
          ">↑ 向上一层</button>

          <button id="boss-dialog-confirm" style="
            padding: 8px 20px;
            border: none;
            background: linear-gradient(90deg, #2196F3, #1976D2);
            color: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
          ">✓ 确认选择</button>
        </div>
      </div>

      <div style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0,0,0,0.5);
        z-index: 999999;
      "></div>
    `;

    document.body.appendChild(this.confirmDialog);

    // 绑定按钮事件
    document.getElementById('boss-dialog-confirm').onclick = () => this.confirmSelection();
    document.getElementById('boss-dialog-cancel').onclick = () => this.cancelSelection();
    document.getElementById('boss-dialog-adjust').onclick = () => this.navigateUp();
  }

  // 向上导航到父元素
  navigateUp() {
    if (this.selectedElement && this.selectedElement.parentElement) {
      this.selectedElement = this.selectedElement.parentElement;
      this.confirmDialog.remove();
      this.showConfirmDialog();
    }
  }

  // 确认选择
  confirmSelection() {
    const selector = this.getParentSelector();

    // 发送消息到 popup
    chrome.runtime.sendMessage({
      action: 'selectorConfirmed',
      selector: selector,
      elementsCount: document.querySelectorAll(selector).length
    });

    this.confirmDialog.remove();
    this.hideTip();
  }

  // 取消选择
  cancelSelection() {
    this.confirmDialog.remove();
    this.selectedElement = null;
    this.cancel();
  }

  // 取消选择模式
  cancel() {
    // 根据模式发送不同的消息
    if (this.isDetailFieldMode) {
      chrome.runtime.sendMessage({ action: 'detailFieldCancelled' });
    } else if (this.isListFieldMode) {
      chrome.runtime.sendMessage({ action: 'listFieldCancelled' });
    } else {
      chrome.runtime.sendMessage({ action: 'selectorCancelled' });
    }

    this.deactivate();
    this.hideTip();
  }

  // 停用选择模式
  deactivate() {
    this.isActive = false;

    if (this.canvas) {
      this.canvas.remove();
      this.canvas = null;
    }

    document.removeEventListener('mousemove', this.boundMouseMove, true);
    document.removeEventListener('click', this.boundClick, true);
    document.removeEventListener('keydown', this.boundKeyDown, true);
  }

  // 生成 CSS 选择器
  generateSelector(element) {
    // 优先使用 ID
    if (element.id) {
      return `#${element.id}`;
    }

    // 使用类名组合
    if (element.className && typeof element.className === 'string') {
      const classes = element.className.trim().split(/\s+/).filter(c => c);
      if (classes.length > 0) {
        return `${element.tagName.toLowerCase()}.${classes.join('.')}`;
      }
    }

    // 使用标签名 + nth-child
    const parent = element.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children);
      const index = siblings.indexOf(element) + 1;
      return `${parent.tagName.toLowerCase()} > ${element.tagName.toLowerCase()}:nth-child(${index})`;
    }

    return element.tagName.toLowerCase();
  }

  // 获取父容器选择器（用于批量选择）
  getParentSelector() {
    // 对于 Boss 直聘，通常选择职位列表的父容器
    return this.generateSelector(this.selectedElement);
  }

  // 显示提示信息
  showTip(message) {
    const tip = document.createElement('div');
    tip.id = 'boss-scraper-tip';
    tip.textContent = message;
    tip.style.cssText = `
      position: fixed !important;
      top: 20px !important;
      left: 50% !important;
      transform: translateX(-50%) !important;
      background: linear-gradient(90deg, #2196F3, #1976D2) !important;
      color: white !important;
      padding: 12px 24px !important;
      border-radius: 24px !important;
      z-index: 1000001 !important;
      font-size: 14px !important;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2) !important;
      animation: slideDown 0.3s ease-out !important;
    `;

    // 添加动画
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideDown {
        from { transform: translateX(-50%) translateY(-20px); opacity: 0; }
        to { transform: translateX(-50%) translateY(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);

    document.body.appendChild(tip);
  }

  // 隐藏提示信息
  hideTip() {
    const tip = document.getElementById('boss-scraper-tip');
    if (tip) {
      tip.remove();
    }
  }

  // 确认详情页字段选择
  confirmDetailFieldSelection() {
    const selector = this.generateSelector(this.selectedElement);

    console.log('[Selector] 详情页字段已确认:', this.detailField, selector);

    // 发送消息到 popup
    chrome.runtime.sendMessage({
      action: 'detailFieldConfigured',
      field: this.detailField,
      selector: selector,
      fieldName: this.detailFieldName
    });

    this.hideTip();
    this.isDetailFieldMode = false;
    this.detailField = null;
    this.detailFieldName = null;
  }

  // 确认列表页字段选择
  confirmListFieldSelection() {
    const selector = this.generateSelector(this.selectedElement);

    console.log('[Selector] 列表页字段已确认:', this.listField, selector);

    // 发送消息到 popup
    chrome.runtime.sendMessage({
      action: 'listFieldConfigured',
      field: this.listField,
      selector: selector,
      fieldName: this.listFieldName
    });

    this.hideTip();
    this.isListFieldMode = false;
    this.listField = null;
    this.listFieldName = null;
  }
}

// 导出为全局变量供 content.js 使用
window.BossElementSelector = ElementSelector;
