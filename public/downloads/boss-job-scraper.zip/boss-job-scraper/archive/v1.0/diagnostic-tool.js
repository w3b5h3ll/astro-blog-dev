// Boss 直聘采集器 - 诊断工具
// 在 Boss 直聘页面的控制台中运行此脚本来诊断问题

(function() {
  console.log('=== Boss 直聘采集器诊断工具 ===\n');

  // 1. 检查页面
  console.log('1️⃣ 页面检查:');
  console.log('   当前 URL:', window.location.href);
  console.log('   是否在 Boss 直聘:', window.location.hostname.includes('zhipin.com') ? '✅ 是' : '❌ 否');
  console.log('');

  // 2. 检查常见的职位列表容器
  console.log('2️⃣ 检查常见容器:');

  const containerSelectors = [
    'ul.job-list-box',
    'ul.job-list',
    'div.job-list-wrapper',
    'ul[class*="job-list"]',
    'div[class*="job-list"]'
  ];

  let foundContainers = [];
  containerSelectors.forEach(selector => {
    const el = document.querySelector(selector);
    if (el) {
      const childCount = el.children.length;
      console.log(`   ✅ ${selector} - 找到! (${childCount} 个子元素)`);
      foundContainers.push({ selector, element: el, childCount });
    } else {
      console.log(`   ❌ ${selector} - 未找到`);
    }
  });
  console.log('');

  // 3. 检查职位卡片
  console.log('3️⃣ 检查职位卡片:');

  const jobCardSelectors = [
    '.job-card-wrapper',
    'li.job-card-box',
    '[class*="job-card"]',
    'li[ka*="job"]',
    '.job-primary'
  ];

  let foundCards = [];
  jobCardSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.log(`   ✅ ${selector} - 找到 ${elements.length} 个`);
      foundCards.push({ selector, count: elements.length });
    } else {
      console.log(`   ❌ ${selector} - 未找到`);
    }
  });
  console.log('');

  // 4. 检查存储的选择器
  console.log('4️⃣ 检查已保存的选择器:');
  chrome.storage.local.get(['selectedSelector'], (result) => {
    if (result.selectedSelector) {
      console.log('   已保存选择器:', result.selectedSelector);
      const el = document.querySelector(result.selectedSelector);
      if (el) {
        console.log('   ✅ 选择器有效');
        console.log('   容器标签:', el.tagName);
        console.log('   容器类名:', el.className);
        console.log('   子元素数量:', el.children.length);

        // 检查子元素
        if (el.children.length > 0) {
          console.log('   第一个子元素:', el.children[0].tagName, el.children[0].className);
        }
      } else {
        console.log('   ❌ 选择器无效（找不到元素）');
      }
    } else {
      console.log('   ⚠️  未保存选择器');
    }
  });
  console.log('');

  // 5. 测试数据提取
  if (foundCards.length > 0) {
    console.log('5️⃣ 测试数据提取 (第一个职位卡片):');
    const bestCardSelector = foundCards[0].selector;
    const firstCard = document.querySelector(bestCardSelector);

    if (firstCard) {
      console.log('   职位卡片元素:', firstCard.tagName, firstCard.className);

      // 测试各个字段
      const tests = {
        '职位名称': ['.job-title', '.job-name', '[class*="job-title"]'],
        '公司名称': ['.company-name', '[class*="company-name"]'],
        '薪资': ['.salary', '[class*="salary"]', 'span.red'],
        '地点': ['.job-area', '[class*="area"]']
      };

      Object.entries(tests).forEach(([field, selectors]) => {
        let found = false;
        for (const sel of selectors) {
          const el = firstCard.querySelector(sel);
          if (el && el.textContent.trim()) {
            console.log(`   ✅ ${field}: "${el.textContent.trim()}" (选择器: ${sel})`);
            found = true;
            break;
          }
        }
        if (!found) {
          console.log(`   ❌ ${field}: 未找到`);
        }
      });
    }
  }
  console.log('');

  // 6. 建议
  console.log('6️⃣ 建议:');
  if (foundContainers.length > 0) {
    const best = foundContainers.reduce((a, b) => a.childCount > b.childCount ? a : b);
    console.log(`   ✅ 推荐选择器: ${best.selector}`);
    console.log(`   📊 包含 ${best.childCount} 个子元素`);
  } else {
    console.log('   ⚠️  未找到常见的职位列表容器');
    console.log('   💡 请手动检查页面结构，或使用可视化选择器');
  }

  if (foundCards.length > 0) {
    console.log(`   ✅ 页面上有 ${foundCards[0].count} 个职位卡片`);
  } else {
    console.log('   ⚠️  未找到职位卡片');
    console.log('   💡 页面可能还在加载，或结构已改变');
  }

  console.log('\n=== 诊断完成 ===');
  console.log('💡 如果看到很多 ❌，说明页面结构可能已更新');
  console.log('💡 请将此诊断结果截图或复制，以便进一步分析');
})();
