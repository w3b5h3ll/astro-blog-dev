// Boss 直聘采集器 - Popup 脚本
(function() {
  'use strict';

  // DOM 元素
  const elements = {
    selectBtn: document.getElementById('select-btn'),
    startBtn: document.getElementById('start-btn'),
    stopBtn: document.getElementById('stop-btn'),
    deepScrapeBtn: document.getElementById('deep-scrape-btn'),
    pauseDeepBtn: document.getElementById('pause-deep-btn'),
    exportBtn: document.getElementById('export-btn'),
    statusText: document.getElementById('status-text'),
    jobCount: document.getElementById('job-count'),
    progressSection: document.getElementById('progress-section'),
    progressFill: document.getElementById('progress-fill'),
    progressText: document.getElementById('progress-text'),
    autoDedupe: document.getElementById('auto-dedupe'),
    enableLimit: document.getElementById('enable-limit'),
    limitNumber: document.getElementById('limit-number'),
    limitNumberContainer: document.getElementById('limit-number-container'),
    scrollDelay: document.getElementById('scroll-delay'),
    randomDelay: document.getElementById('random-delay'),
    enableAIValidation: document.getElementById('enable-ai-validation'),
    enableBasicValidation: document.getElementById('enable-basic-validation'),
    detailDelay: document.getElementById('detail-delay'),
    selectorInfo: document.getElementById('selector-info'),
    toggleDebug: document.getElementById('toggle-debug'),
    debugLogs: document.getElementById('debug-logs')
  };

  // 调试日志数组
  let debugLogs = [];

  // 状态管理
  let state = {
    selectedSelector: null,
    scrapedJobs: [],
    isScraping: false,
    isDeepScraping: false,
    deepScrapePaused: false,
    detailFieldSelectors: {}, // 详情页字段选择器配置
    listFieldSelectors: {}, // 列表页字段选择器配置
    configuringField: null // 当前正在配置的字段
  };

  // 初始化
  async function init() {
    console.log('[Popup] 初始化...');

    // 加载保存的状态
    await loadState();

    // 绑定事件
    elements.selectBtn.addEventListener('click', handleSelectClick);
    elements.startBtn.addEventListener('click', handleStartClick);
    elements.stopBtn.addEventListener('click', handleStopClick);
    elements.deepScrapeBtn.addEventListener('click', handleDeepScrapeClick);
    elements.pauseDeepBtn.addEventListener('click', handlePauseDeepClick);
    elements.exportBtn.addEventListener('click', handleExportClick);
    elements.toggleDebug.addEventListener('click', toggleDebugPanel);

    // 绑定限制数量开关事件
    if (elements.enableLimit) {
      elements.enableLimit.addEventListener('change', (e) => {
        if (e.target.checked) {
          elements.limitNumberContainer.style.display = 'block';
        } else {
          elements.limitNumberContainer.style.display = 'none';
        }
      });
    }

    // 绑定详情页配置按钮
    document.querySelectorAll('.btn-config').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const field = e.target.getAttribute('data-field');
        handleConfigureField(field);
      });
    });

    document.querySelectorAll('.btn-clear').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const field = e.target.getAttribute('data-field');
        handleClearFieldConfig(field);
      });
    });

    document.getElementById('test-config-btn')?.addEventListener('click', handleTestConfig);

    // 绑定列表页配置按钮
    document.querySelectorAll('.btn-config-list').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const field = e.target.getAttribute('data-field');
        handleConfigureListField(field);
      });
    });

    document.querySelectorAll('.btn-clear-list').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const field = e.target.getAttribute('data-field');
        handleClearListFieldConfig(field);
      });
    });

    document.getElementById('test-list-config-btn')?.addEventListener('click', handleTestListConfig);

    // 监听来自 content script 的消息
    chrome.runtime.onMessage.addListener(handleMessage);

    // 检查当前标签页是否是 Boss 直聘
    checkCurrentTab();

    // 添加初始日志
    addLog('info', '侧边栏已加载');
  }

  // 加载保存的状态
  async function loadState() {
    const data = await chrome.storage.local.get([
      'selectedSelector',
      'scrapedJobs',
      'detailFieldSelectors',
      'listFieldSelectors'
    ]);

    if (data.selectedSelector) {
      state.selectedSelector = data.selectedSelector;
      updateSelectorStatus(data.selectedSelector);
      elements.startBtn.disabled = false;
    }

    if (data.scrapedJobs && data.scrapedJobs.length > 0) {
      state.scrapedJobs = data.scrapedJobs;
      updateJobCount(data.scrapedJobs.length);
      elements.exportBtn.disabled = false;
    }

    if (data.detailFieldSelectors) {
      state.detailFieldSelectors = data.detailFieldSelectors;
      updateFieldConfigUI();
    }

    if (data.listFieldSelectors) {
      state.listFieldSelectors = data.listFieldSelectors;
      updateListFieldConfigUI();
    }
  }

  // 检查当前标签页
  async function checkCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab.url || !tab.url.includes('zhipin.com')) {
      elements.statusText.textContent = '请在 Boss 直聘页面使用';
      elements.selectBtn.disabled = true;
      return;
    }

    // Ping content script
    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
      console.log('[Popup] Content script 已就绪');
    } catch (error) {
      console.warn('[Popup] Content script 未加载，尝试注入...');
      // Content script 可能未加载，等待页面刷新
    }
  }

  // 处理选择按钮点击
  async function handleSelectClick() {
    console.log('[Popup] 点击选择按钮');
    addLog('info', '准备激活元素选择器...');

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      console.log('[Popup] 当前标签页:', tab.url);
      addLog('info', `当前页面: ${tab.url}`);

      // 发送消息到 content script
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'activateSelector' });

      console.log('[Popup] 收到响应:', response);
      addLog('success', '选择器已激活，请在页面上选择元素');

      elements.statusText.textContent = '请在页面上选择元素...';

      // 不关闭侧边栏，让用户可以看到状态更新

    } catch (error) {
      console.error('[Popup] 激活选择器失败:', error);
      addLog('error', '激活选择器失败: ' + error.message);
      alert('激活选择器失败，请刷新页面后重试\n\n错误信息: ' + error.message);
    }
  }

  // 处理开始采集按钮点击
  async function handleStartClick() {
    console.log('[Popup] 点击开始采集');
    addLog('info', '开始采集...');

    if (state.isScraping) {
      return;
    }

    state.isScraping = true;
    elements.startBtn.disabled = true;
    elements.startBtn.style.display = 'none';
    elements.stopBtn.style.display = 'inline-flex';
    elements.exportBtn.disabled = true;

    // 显示进度条
    elements.progressSection.style.display = 'block';
    updateProgress(0, '准备采集...');

    // 获取配置
    const config = {
      autoDedupe: elements.autoDedupe.checked,
      scrollDelay: parseInt(elements.scrollDelay.value) || 1000,
      listFieldSelectors: state.listFieldSelectors, // 传递列表字段选择器
      enableLimit: elements.enableLimit?.checked || false,
      limitNumber: parseInt(elements.limitNumber?.value) || 10
    };

    if (config.enableLimit) {
      addLog('info', `配置: 去重=${config.autoDedupe}, 延迟=${config.scrollDelay}ms, 限制数量=${config.limitNumber}`);
    } else {
      addLog('info', `配置: 去重=${config.autoDedupe}, 延迟=${config.scrollDelay}ms, 无限制`);
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // 发送消息到 content script
      await chrome.tabs.sendMessage(tab.id, {
        action: 'startScraping',
        config: config
      });

      elements.statusText.textContent = '正在采集...';

    } catch (error) {
      console.error('[Popup] 开始采集失败:', error);
      addLog('error', '开始采集失败: ' + error.message);
      alert('开始采集失败: ' + error.message);
      resetScrapingState();
    }
  }

  // 处理停止采集按钮点击
  async function handleStopClick() {
    console.log('[Popup] 点击停止采集');
    addLog('warning', '用户请求停止采集');

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // 发送停止消息到 content script
      await chrome.tabs.sendMessage(tab.id, {
        action: 'stopScraping'
      });

      elements.statusText.textContent = '正在停止...';
      elements.stopBtn.disabled = true;

    } catch (error) {
      console.error('[Popup] 停止采集失败:', error);
      addLog('error', '停止采集失败: ' + error.message);
      alert('停止采集失败: ' + error.message);
    }
  }

  // 处理深度采集按钮点击
  async function handleDeepScrapeClick() {
    console.log('[Popup] 点击深度采集');
    addLog('info', '开始深度采集详情页...');

    if (state.scrapedJobs.length === 0) {
      alert('请先完成基础采集');
      return;
    }

    // 检查是否配置了字段
    if (Object.keys(state.detailFieldSelectors).length === 0) {
      const confirmed = confirm('您还没有配置详情页字段！\n\n是否继续？（将只更新已配置的字段）');
      if (!confirmed) return;
    }

    state.isDeepScraping = true;
    state.deepScrapePaused = false;

    elements.deepScrapeBtn.disabled = true;
    elements.deepScrapeBtn.style.display = 'none';
    elements.pauseDeepBtn.style.display = 'inline-flex';
    elements.pauseDeepBtn.textContent = '⏸ 暂停深度采集';
    elements.exportBtn.disabled = true;

    // 显示进度条
    elements.progressSection.style.display = 'block';
    updateProgress(0, '准备深度采集...');

    // 获取配置
    const config = {
      randomDelay: elements.randomDelay.checked,
      enableAIValidation: elements.enableAIValidation?.checked !== false, // 默认启用
      enableBasicValidation: elements.enableBasicValidation?.checked || false, // 默认关闭
      detailDelay: parseInt(elements.detailDelay.value) || 2000,
      jobs: state.scrapedJobs,
      detailSelectors: state.detailFieldSelectors // 传递详情页选择器配置
    };

    const configuredFields = Object.keys(state.detailFieldSelectors).map(getFieldName).join(', ');
    addLog('info', `深度采集配置: 随机延迟=${config.randomDelay}, AI验证=${config.enableAIValidation}, 正则验证=${config.enableBasicValidation}, 基础延迟=${config.detailDelay}ms, 职位数=${config.jobs.length}`);
    if (configuredFields) {
      addLog('info', `已配置字段: ${configuredFields}`);
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // 发送深度采集消息
      await chrome.tabs.sendMessage(tab.id, {
        action: 'startDeepScraping',
        config: config
      });

      elements.statusText.textContent = '正在深度采集...';

    } catch (error) {
      console.error('[Popup] 深度采集失败:', error);
      addLog('error', '深度采集失败: ' + error.message);
      alert('深度采集失败: ' + error.message);
      resetDeepScrapingState();
    }
  }

  // 处理暂停/继续深度采集
  async function handlePauseDeepClick() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (state.deepScrapePaused) {
        // 继续
        addLog('info', '继续深度采集');
        await chrome.tabs.sendMessage(tab.id, {
          action: 'resumeDeepScraping'
        });
        state.deepScrapePaused = false;
        elements.pauseDeepBtn.innerHTML = '<span class="btn-icon">⏸</span><span>暂停深度采集</span>';
      } else {
        // 暂停
        addLog('warning', '暂停深度采集');
        await chrome.tabs.sendMessage(tab.id, {
          action: 'pauseDeepScraping'
        });
        state.deepScrapePaused = true;
        elements.pauseDeepBtn.innerHTML = '<span class="btn-icon">▶</span><span>继续深度采集</span>';
      }

    } catch (error) {
      console.error('[Popup] 暂停/继续失败:', error);
      addLog('error', '操作失败: ' + error.message);
    }
  }

  // 配置详情页字段
  async function handleConfigureField(field) {
    console.log('[Popup] 配置字段:', field);
    addLog('info', `开始配置: ${getFieldName(field)}`);

    const fieldNames = {
      salary: '薪资范围',
      description: '职位描述',
      welfare: '福利待遇',
      hrActivity: 'HR活跃状态',
      companySize: '公司规模',
      industry: '所属行业'
    };

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // 检查是否在详情页
      if (!tab.url || !tab.url.includes('zhipin.com/job_detail')) {
        alert('请先打开任意一个职位详情页！\n\n提示：在列表页点击任意职位，打开详情页后再配置。');
        return;
      }

      state.configuringField = field;

      // 发送消息到 content script
      await chrome.tabs.sendMessage(tab.id, {
        action: 'configureDetailField',
        field: field,
        fieldName: fieldNames[field]
      });

      elements.statusText.textContent = `配置中: ${fieldNames[field]}...`;

    } catch (error) {
      console.error('[Popup] 配置字段失败:', error);
      addLog('error', '配置失败: ' + error.message);
      alert('配置失败: ' + error.message);
    }
  }

  // 清除字段配置
  async function handleClearFieldConfig(field) {
    if (confirm(`确定要清除 ${getFieldName(field)} 的配置吗？`)) {
      delete state.detailFieldSelectors[field];

      // 保存到存储
      await chrome.storage.local.set({
        detailFieldSelectors: state.detailFieldSelectors
      });

      updateFieldConfigUI();
      addLog('warning', `已清除: ${getFieldName(field)}`);
    }
  }

  // 测试当前配置
  async function handleTestConfig() {
    console.log('[Popup] 测试配置');
    addLog('info', '测试当前配置...');

    if (Object.keys(state.detailFieldSelectors).length === 0) {
      alert('请先配置至少一个字段！');
      return;
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab.url || !tab.url.includes('zhipin.com/job_detail')) {
        alert('请在职位详情页测试配置！');
        return;
      }

      // 发送测试消息
      await chrome.tabs.sendMessage(tab.id, {
        action: 'testDetailConfig',
        selectors: state.detailFieldSelectors
      });

    } catch (error) {
      console.error('[Popup] 测试失败:', error);
      addLog('error', '测试失败: ' + error.message);
      alert('测试失败: ' + error.message);
    }
  }

  // 配置列表页字段
  async function handleConfigureListField(field) {
    console.log('[Popup] 配置列表页字段:', field);
    addLog('info', `开始配置列表字段: ${getListFieldName(field)}`);

    const fieldNames = {
      title: '职位名称',
      company: '公司名称',
      salary: '薪资范围',
      location: '工作地点',
      experience: '工作经验',
      education: '学历要求'
    };

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // 确保在职位列表页
      if (!tab.url || !tab.url.includes('zhipin.com')) {
        alert('请在 Boss 直聘页面使用！');
        return;
      }

      // 发送配置消息
      await chrome.tabs.sendMessage(tab.id, {
        action: 'configureListField',
        field: field,
        fieldName: fieldNames[field]
      });

      elements.statusText.textContent = `配置列表字段: ${fieldNames[field]}...`;

    } catch (error) {
      console.error('[Popup] 配置列表字段失败:', error);
      addLog('error', '配置失败: ' + error.message);
      alert('配置失败: ' + error.message);
    }
  }

  // 清除列表页字段配置
  async function handleClearListFieldConfig(field) {
    if (confirm(`确定要清除 ${getListFieldName(field)} 的配置吗？`)) {
      delete state.listFieldSelectors[field];

      // 保存到存储
      await chrome.storage.local.set({
        listFieldSelectors: state.listFieldSelectors
      });

      updateListFieldConfigUI();
      addLog('warning', `已清除列表字段: ${getListFieldName(field)}`);
    }
  }

  // 测试列表页配置
  async function handleTestListConfig() {
    console.log('[Popup] 测试列表页配置');
    addLog('info', '测试列表页配置...');

    if (Object.keys(state.listFieldSelectors).length === 0) {
      alert('请先配置至少一个列表字段！');
      return;
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab.url || !tab.url.includes('zhipin.com')) {
        alert('请在 Boss 直聘页面测试配置！');
        return;
      }

      // 发送测试消息
      await chrome.tabs.sendMessage(tab.id, {
        action: 'testListConfig',
        selectors: state.listFieldSelectors,
        listSelector: state.selectedSelector
      });

    } catch (error) {
      console.error('[Popup] 测试失败:', error);
      addLog('error', '测试失败: ' + error.message);
      alert('测试失败: ' + error.message);
    }
  }

  // 获取字段名称
  function getFieldName(field) {
    const names = {
      salary: '薪资范围',
      description: '职位描述',
      welfare: '福利待遇',
      hrActivity: 'HR活跃状态',
      companySize: '公司规模',
      industry: '所属行业'
    };
    return names[field] || field;
  }

  // 获取列表页字段名称
  function getListFieldName(field) {
    const names = {
      title: '职位名称',
      company: '公司名称',
      location: '工作地点',
      experience: '工作经验',
      education: '学历要求'
    };
    return names[field] || field;
  }

  // 更新字段配置UI
  function updateFieldConfigUI() {
    const fields = ['salary', 'description', 'welfare', 'hrActivity', 'companySize', 'industry'];

    fields.forEach(field => {
      const statusEl = document.getElementById(`status-${field}`);
      const configBtn = document.querySelector(`.btn-config[data-field="${field}"]`);
      const clearBtn = document.querySelector(`.btn-clear[data-field="${field}"]`);

      if (state.detailFieldSelectors[field]) {
        // 已配置
        statusEl.textContent = '✓ 已配置';
        statusEl.className = 'field-status configured';
        if (configBtn) configBtn.textContent = '重新配置';
        if (clearBtn) clearBtn.style.display = 'inline-block';
      } else {
        // 未配置
        statusEl.textContent = '未配置';
        statusEl.className = 'field-status unconfigured';
        if (configBtn) configBtn.textContent = '配置';
        if (clearBtn) clearBtn.style.display = 'none';
      }
    });
  }

  // 更新列表页字段配置UI
  function updateListFieldConfigUI() {
    const fields = ['title', 'company', 'location', 'experience', 'education'];

    fields.forEach(field => {
      const statusEl = document.getElementById(`status-list-${field}`);
      const configBtn = document.querySelector(`.btn-config-list[data-field="${field}"]`);
      const clearBtn = document.querySelector(`.btn-clear-list[data-field="${field}"]`);

      if (state.listFieldSelectors[field]) {
        // 已配置
        statusEl.textContent = '✓ 已配置';
        statusEl.className = 'field-status configured';
        if (configBtn) configBtn.textContent = '重新配置';
        if (clearBtn) clearBtn.style.display = 'inline-block';
      } else {
        // 未配置
        statusEl.textContent = '未配置';
        statusEl.className = 'field-status unconfigured';
        if (configBtn) configBtn.textContent = '配置';
        if (clearBtn) clearBtn.style.display = 'none';
      }
    });
  }

  // 处理导出按钮点击
  async function handleExportClick() {
    console.log('[Popup] 点击导出按钮');

    if (state.scrapedJobs.length === 0) {
      alert('没有可导出的数据');
      return;
    }

    try {
      elements.exportBtn.disabled = true;
      elements.exportBtn.textContent = '导出中...';

      const exporter = new ExcelExporter(state.scrapedJobs);
      await exporter.exportToExcel();

      elements.exportBtn.textContent = '✅ 导出成功';
      setTimeout(() => {
        elements.exportBtn.innerHTML = '<span class="btn-icon">📥</span><span>导出 Excel</span>';
        elements.exportBtn.disabled = false;
      }, 2000);

    } catch (error) {
      console.error('[Popup] 导出失败:', error);
      alert('导出失败: ' + error.message);
      elements.exportBtn.disabled = false;
      elements.exportBtn.innerHTML = '<span class="btn-icon">📥</span><span>导出 Excel</span>';
    }
  }

  // 处理来自 content script 的消息
  function handleMessage(message, sender, sendResponse) {
    console.log('[Popup] 收到消息:', message.action);

    switch (message.action) {
      case 'selectorConfirmed':
        handleSelectorConfirmed(message);
        break;

      case 'selectorCancelled':
        handleSelectorCancelled();
        break;

      case 'updateProgress':
        updateProgress(message.progress, message.status);
        break;

      case 'scrapingComplete':
        handleScrapingComplete(message);
        break;

      case 'scrapingError':
        handleScrapingError(message);
        break;

      case 'scrapingStopped':
        handleScrapingStopped(message);
        break;

      case 'deepScrapeProgress':
        handleDeepScrapeProgress(message);
        break;

      case 'deepScrapeComplete':
        handleDeepScrapeComplete(message);
        break;

      case 'deepScrapeError':
        handleDeepScrapeError(message);
        break;

      case 'detailFieldConfigured':
        handleDetailFieldConfigured(message);
        break;

      case 'detailFieldCancelled':
        handleDetailFieldCancelled();
        break;

      case 'testConfigResult':
        handleTestConfigResult(message);
        break;

      case 'listFieldConfigured':
        handleListFieldConfigured(message);
        break;

      case 'listFieldCancelled':
        handleListFieldCancelled();
        break;

      case 'testListConfigResult':
        handleTestListConfigResult(message);
        break;

      case 'debugLog':
        // 接收来自 content script 的调试日志
        addLog(message.logType || 'info', message.logMessage);
        break;
    }
  }

  // 处理选择器确认
  function handleSelectorConfirmed(message) {
    console.log('[Popup] 选择器已确认:', message.selector);

    state.selectedSelector = message.selector;

    // 保存到存储
    chrome.storage.local.set({
      selectedSelector: message.selector
    });

    updateSelectorStatus(message.selector, message.elementsCount);
    elements.startBtn.disabled = false;
  }

  // 处理选择器取消
  function handleSelectorCancelled() {
    console.log('[Popup] 选择器已取消');
    elements.statusText.textContent = '已取消选择';
  }

  // 更新选择器状态
  function updateSelectorStatus(selector, count) {
    elements.statusText.textContent = '已选择区域';
    elements.selectorInfo.textContent = `选择器: ${selector.substring(0, 50)}${selector.length > 50 ? '...' : ''}`;

    if (count) {
      elements.selectorInfo.textContent += ` (${count} 个元素)`;
    }
  }

  // 更新进度
  function updateProgress(progress, status) {
    elements.progressFill.style.width = progress + '%';
    elements.progressText.textContent = status || `${progress}%`;
  }

  // 处理采集完成
  function handleScrapingComplete(message) {
    console.log('[Popup] 采集完成:', message.count, '条');

    state.scrapedJobs = message.jobs;
    state.isScraping = false;

    // 保存数据
    chrome.storage.local.set({
      scrapedJobs: message.jobs
    });

    updateProgress(100, '采集完成！');
    updateJobCount(message.count);

    elements.statusText.textContent = '采集完成';
    elements.startBtn.disabled = false;
    elements.startBtn.style.display = 'inline-flex';
    elements.stopBtn.style.display = 'none';
    elements.exportBtn.disabled = false;

    // 显示深度采集按钮
    if (message.count > 0) {
      elements.deepScrapeBtn.disabled = false;
      elements.deepScrapeBtn.style.display = 'inline-flex';
      addLog('success', `采集完成 ${message.count} 条，可以进行深度采集`);
    }

    // 3秒后隐藏进度条
    setTimeout(() => {
      elements.progressSection.style.display = 'none';
    }, 3000);
  }

  // 处理采集错误
  function handleScrapingError(message) {
    console.error('[Popup] 采集错误:', message.error);

    alert('采集失败: ' + message.error);
    resetScrapingState();
  }

  // 处理采集停止
  function handleScrapingStopped(message) {
    console.log('[Popup] 采集已停止:', message.count, '条');
    addLog('warning', `采集已停止，共采集 ${message.count} 条数据`);

    if (message.jobs && message.jobs.length > 0) {
      state.scrapedJobs = message.jobs;

      // 保存已采集的数据
      chrome.storage.local.set({
        scrapedJobs: message.jobs
      });

      updateJobCount(message.count);
      elements.exportBtn.disabled = false;

      // 显示深度采集按钮
      elements.deepScrapeBtn.disabled = false;
      elements.deepScrapeBtn.style.display = 'inline-flex';

      addLog('success', `已保存 ${message.count} 条数据，可以导出或深度采集`);
    } else {
      addLog('warning', '没有采集到数据');
    }

    updateProgress(message.progress || 0, '已停止');
    elements.statusText.textContent = `已停止 (已采集 ${message.count} 条)`;

    // 重置状态，但保持状态文本
    resetScrapingState(true);
  }

  // 处理深度采集进度
  function handleDeepScrapeProgress(message) {
    const { current, total, progress, job } = message;
    updateProgress(progress, `深度采集中 ${current}/${total}`);

    if (job) {
      addLog('info', `[${current}/${total}] ${job.title} - ${job.company}`);

      // 实时更新数据
      if (message.updatedJob) {
        const index = state.scrapedJobs.findIndex(j => j.jobId === message.updatedJob.jobId);
        if (index !== -1) {
          state.scrapedJobs[index] = message.updatedJob;
        }
      }
    }
  }

  // 处理深度采集完成
  function handleDeepScrapeComplete(message) {
    console.log('[Popup] 深度采集完成:', message.count, '条');
    addLog('success', `深度采集完成！成功: ${message.successCount}, 失败: ${message.failCount}`);

    if (message.jobs && message.jobs.length > 0) {
      state.scrapedJobs = message.jobs;

      // 保存数据
      chrome.storage.local.set({
        scrapedJobs: message.jobs
      });
    }

    updateProgress(100, '深度采集完成！');
    elements.statusText.textContent = `深度采集完成 (${message.count} 条)`;

    resetDeepScrapingState();

    // 3秒后隐藏进度条
    setTimeout(() => {
      elements.progressSection.style.display = 'none';
    }, 3000);
  }

  // 处理深度采集错误
  function handleDeepScrapeError(message) {
    console.error('[Popup] 深度采集错误:', message.error);
    addLog('error', '深度采集错误: ' + message.error);
    alert('深度采集失败: ' + message.error);
    resetDeepScrapingState();
  }

  // 重置深度采集状态
  function resetDeepScrapingState() {
    state.isDeepScraping = false;
    state.deepScrapePaused = false;
    elements.deepScrapeBtn.disabled = false;
    elements.deepScrapeBtn.style.display = 'inline-flex';
    elements.pauseDeepBtn.style.display = 'none';
    elements.exportBtn.disabled = false;
  }

  // 处理详情页字段配置完成
  function handleDetailFieldConfigured(message) {
    const { field, selector } = message;
    console.log('[Popup] 字段配置完成:', field, selector);

    // 保存选择器
    state.detailFieldSelectors[field] = selector;

    // 保存到存储
    chrome.storage.local.set({
      detailFieldSelectors: state.detailFieldSelectors
    });

    // 更新UI
    updateFieldConfigUI();

    addLog('success', `✓ ${getFieldName(field)} 配置完成: ${selector.substring(0, 30)}...`);
    elements.statusText.textContent = `${getFieldName(field)} 配置完成`;
  }

  // 处理配置取消
  function handleDetailFieldCancelled() {
    console.log('[Popup] 字段配置已取消');
    state.configuringField = null;
    elements.statusText.textContent = '配置已取消';
    addLog('warning', '配置已取消');
  }

  // 处理测试配置结果
  function handleTestConfigResult(message) {
    const { results } = message;
    console.log('[Popup] 测试结果:', results);

    addLog('info', '=== 测试结果 ===');

    Object.entries(results).forEach(([field, value]) => {
      const fieldName = getFieldName(field);
      if (value && value.length > 0) {
        const preview = Array.isArray(value) ? value.join(', ') : value;
        addLog('success', `✓ ${fieldName}: ${preview.substring(0, 50)}${preview.length > 50 ? '...' : ''}`);
      } else {
        addLog('error', `✗ ${fieldName}: 未提取到数据`);
      }
    });

    addLog('info', '=== 测试完成 ===');
  }

  // 处理列表页字段配置完成
  function handleListFieldConfigured(message) {
    const { field, selector } = message;
    console.log('[Popup] 列表字段配置完成:', field, selector);

    // 保存选择器
    state.listFieldSelectors[field] = selector;

    // 保存到存储
    chrome.storage.local.set({
      listFieldSelectors: state.listFieldSelectors
    });

    // 更新UI
    updateListFieldConfigUI();

    addLog('success', `✓ ${getListFieldName(field)} 配置完成: ${selector.substring(0, 30)}...`);
    elements.statusText.textContent = `${getListFieldName(field)} 配置完成`;
  }

  // 处理列表字段配置取消
  function handleListFieldCancelled() {
    console.log('[Popup] 列表字段配置已取消');
    state.configuringField = null;
    elements.statusText.textContent = '配置已取消';
    addLog('warning', '配置已取消');
  }

  // 处理测试列表配置结果
  function handleTestListConfigResult(message) {
    const { results } = message;
    console.log('[Popup] 测试列表配置结果:', results);

    addLog('info', '=== 列表字段测试结果 ===');

    Object.entries(results).forEach(([field, value]) => {
      const fieldName = getListFieldName(field);
      if (value && value.length > 0) {
        const preview = Array.isArray(value) ? value.join(', ') : value;
        addLog('success', `✓ ${fieldName}: ${preview.substring(0, 50)}${preview.length > 50 ? '...' : ''}`);
      } else {
        addLog('error', `✗ ${fieldName}: 未提取到数据`);
      }
    });

    addLog('info', '=== 测试完成 ===');
  }

  // 重置采集状态
  function resetScrapingState(keepStatusText = false) {
    state.isScraping = false;
    elements.startBtn.disabled = false;
    elements.startBtn.style.display = 'inline-flex';
    elements.stopBtn.style.display = 'none';
    elements.stopBtn.disabled = false;
    elements.progressSection.style.display = 'none';

    // 只在没有数据且不保持状态文本时，才设置为"采集失败"
    if (!keepStatusText && state.scrapedJobs.length === 0) {
      elements.statusText.textContent = '采集失败';
    }
  }

  // 更新职位数量
  function updateJobCount(count) {
    elements.jobCount.textContent = `${count} 条`;
  }

  // 添加调试日志
  function addLog(type, message) {
    const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
    const log = { type, message, time };
    debugLogs.push(log);

    // 限制日志数量
    if (debugLogs.length > 100) {
      debugLogs.shift();
    }

    // 更新显示
    updateDebugDisplay();
  }

  // 更新调试面板显示
  function updateDebugDisplay() {
    if (elements.debugLogs.style.display === 'none') {
      return; // 如果面板是隐藏的，不更新
    }

    elements.debugLogs.innerHTML = debugLogs.map(log => {
      const className = `log-${log.type}`;
      return `<div class="debug-log-item">
        <span class="log-time">[${log.time}]</span>
        <span class="${className}">${log.message}</span>
      </div>`;
    }).join('');

    // 自动滚动到底部
    elements.debugLogs.scrollTop = elements.debugLogs.scrollHeight;
  }

  // 切换调试面板
  function toggleDebugPanel() {
    if (elements.debugLogs.style.display === 'none') {
      elements.debugLogs.style.display = 'block';
      elements.toggleDebug.textContent = '收起';
      updateDebugDisplay();
    } else {
      elements.debugLogs.style.display = 'none';
      elements.toggleDebug.textContent = '展开';
    }
  }

  // Excel 导出类
  class ExcelExporter {
    constructor(jobs) {
      this.jobs = jobs;
    }

    async exportToExcel() {
      console.log('[Exporter] 开始导出 Excel...');

      // 加载 SheetJS 库
      const XLSX = await this.loadXLSX();

      // 格式化数据
      const data = this.formatData();

      // 创建工作表
      const ws = XLSX.utils.json_to_sheet(data);

      // 设置列宽
      ws['!cols'] = [
        { wch: 25 }, // 职位名称
        { wch: 20 }, // 公司名称
        { wch: 15 }, // 薪资范围
        { wch: 20 }, // 工作地点
        { wch: 12 }, // 工作经验
        { wch: 10 }, // 学历要求
        { wch: 60 }, // 职位描述
        { wch: 35 }, // 福利待遇
        { wch: 18 }, // HR活跃状态
        { wch: 12 }, // 公司规模
        { wch: 15 }, // 所属行业
        { wch: 50 }, // 职位链接
        { wch: 18 }  // 采集时间
      ];

      // 创建工作簿
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Boss直聘职位');

      // 导出文件
      const filename = `Boss直聘职位_${this.getDateString()}.xlsx`;
      XLSX.writeFile(wb, filename);

      console.log('[Exporter] 导出完成:', filename);
    }

    formatData() {
      return this.jobs.map(job => ({
        '职位名称': job.title || '',
        '公司名称': job.company || '',
        '薪资范围': job.salary || '',
        '工作地点': job.location || '',
        '工作经验': job.experience || '',
        '学历要求': job.education || '',
        '职位描述': job.description || '',
        '福利待遇': (job.welfare || []).join(', '),
        'HR活跃状态': job.hrActivity || '',
        '公司规模': job.companySize || '',
        '所属行业': job.industry || '',
        '职位链接': job.jobUrl || '',
        '采集时间': job.scrapedAt ? new Date(job.scrapedAt).toLocaleString('zh-CN') : ''
      }));
    }

    async loadXLSX() {
      return new Promise((resolve, reject) => {
        if (window.XLSX) {
          resolve(window.XLSX);
          return;
        }

        const script = document.createElement('script');
        script.src = '../libs/xlsx.full.min.js';
        script.onload = () => {
          console.log('[Exporter] SheetJS 加载成功');
          resolve(window.XLSX);
        };
        script.onerror = () => {
          reject(new Error('加载 SheetJS 失败'));
        };
        document.head.appendChild(script);
      });
    }

    getDateString() {
      const now = new Date();
      const year = now.getFullYear();
      const month = String(now.getMonth() + 1).padStart(2, '0');
      const day = String(now.getDate()).padStart(2, '0');
      const hour = String(now.getHours()).padStart(2, '0');
      const minute = String(now.getMinutes()).padStart(2, '0');
      return `${year}${month}${day}_${hour}${minute}`;
    }
  }

  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
