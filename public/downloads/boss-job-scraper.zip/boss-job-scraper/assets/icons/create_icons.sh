#!/bin/bash

# 创建简单的 PNG 图标（使用 ImageMagick 或其他工具）
# 这里提供一个使用 Python PIL 的脚本

python3 << 'PYTHON'
try:
    from PIL import Image, ImageDraw, ImageFont
    
    # 创建 16x16 图标
    img16 = Image.new('RGBA', (16, 16), (33, 150, 243, 255))
    draw = ImageDraw.Draw(img16)
    draw.rectangle([2, 2, 13, 13], outline=(255, 255, 255, 255), width=2)
    img16.save('icon16.png')
    
    # 创建 48x48 图标
    img48 = Image.new('RGBA', (48, 48), (33, 150, 243, 255))
    draw = ImageDraw.Draw(img48)
    draw.rectangle([6, 6, 41, 41], outline=(255, 255, 255, 255), width=3)
    draw.line([12, 24, 36, 24], fill=(255, 255, 255, 255), width=2)
    draw.line([24, 12, 24, 36], fill=(255, 255, 255, 255), width=2)
    img48.save('icon48.png')
    
    # 创建 128x128 图标
    img128 = Image.new('RGBA', (128, 128), (33, 150, 243, 255))
    draw = ImageDraw.Draw(img128)
    draw.rectangle([16, 16, 112, 112], outline=(255, 255, 255, 255), width=8)
    draw.line([32, 64, 96, 64], fill=(255, 255, 255, 255), width=6)
    draw.line([64, 32, 64, 96], fill=(255, 255, 255, 255), width=6)
    img128.save('icon128.png')
    
    print("图标创建成功！")
except ImportError:
    print("PIL 库未安装，请手动创建图标")
    print("或运行: pip3 install Pillow")
PYTHON

