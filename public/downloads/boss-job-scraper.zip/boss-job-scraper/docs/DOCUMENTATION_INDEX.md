# 📚 Boss 直聘静默抓取方案 - 文档导航

> 完整的 Offscreen API 迁移方案，包含详细分析、实现代码和使用指南

---

## 🎯 快速开始

**我该从哪里开始？**

1. **如果你想立即使用** → [⚡ 快速参考](./QUICK_REFERENCE.md)
2. **如果你想了解全貌** → [📋 完整总结](./README_SUMMARY.md)
3. **如果你想深入理解** → [📊 方案分析](./SOLUTION_ANALYSIS.md)

---

## 📖 文档索引

### 核心文档 (按推荐阅读顺序)

#### 1️⃣ [⚡ 快速参考卡片](./QUICK_REFERENCE.md)
**最快速上手的参考指南**

- ✅ 一行命令测试 Offscreen API
- ✅ 代码片段速查
- ✅ 故障排除速查表
- ✅ 验收检查清单

**适合**: 想要立即开始使用的开发者

---

#### 2️⃣ [📋 完整方案总结](./README_SUMMARY.md)
**所有方案的汇总和对比**

- ✅ 问题分析
- ✅ 4 种方案详细对比
- ✅ 性能数据
- ✅ 常见问题 FAQ
- ✅ 下一步行动建议

**适合**: 需要全面了解所有方案的决策者

---

#### 3️⃣ [📊 方案深度分析](./en/dev/SOLUTION_ANALYSIS.md)
**详细的技术方案分析和代码示例**

- ✅ 每种方案的工作原理
- ✅ 完整的代码实现示例
- ✅ 优势和限制详解
- ✅ 性能对比数据

**适合**: 需要深入理解技术细节的开发者

---

#### 4️⃣ [🚀 迁移指南](./en/dev/MIGRATION_GUIDE.md)
**从旧方案迁移到 Offscreen API 的完整步骤**

- ✅ 文件清单和修改说明
- ✅ 详细的测试步骤
- ✅ 常见问题解答
- ✅ 验收标准

**适合**: 正在进行迁移的开发者

---

#### 5️⃣ [🔍 API 分析指南](./en/dev/API_ANALYSIS_GUIDE.md)
**如何分析 Boss 直聘的数据接口**

- ✅ Chrome DevTools 使用技巧
- ✅ API 接口分析步骤
- ✅ 反爬虫机制处理
- ✅ 完整的实现代码

**适合**: 想要进一步优化速度的开发者

---

### 历史文档

这些文档记录了项目的演进历史：

- [📝 原始 README](../README.md) - 项目介绍
- [🔧 重构报告](./en/dev/REFACTORING_REPORT.md) - 代码重构记录
- [🔕 静默模式升级](./archive/SILENT_MODE_UPGRADE.md) - 之前的静默模式方案
- [✅ 测试清单](./project/TEST_CHECKLIST.md) - 功能测试清单

---

## 🗂️ 代码文件索引

### 新增文件 ✅

```
src/offscreen/
├── offscreen.html              # Offscreen Document 页面
└── offscreen.js                # Offscreen 核心逻辑

src/content/scraper/
└── deep-scraper-offscreen.js   # 新版深度采集类
```

### 修改文件 ✅

```
manifest.json                   # 添加 offscreen 权限
src/background/index.js         # 添加 Offscreen 管理逻辑
```

### 保留文件

```
src/content/scraper/
└── deep-scraper.js             # 旧版（window.open 方式）
```

---

## 🎓 学习路径

### 路径 1: 快速实施者

**目标**: 尽快让 Offscreen API 工作起来

1. 阅读 [⚡ 快速参考](./QUICK_REFERENCE.md)（5 分钟）
2. 验证 Offscreen API 可用（1 分钟）
3. 使用新版深度采集类（2 分钟）
4. 遇到问题时查看 [🚀 迁移指南](./MIGRATION_GUIDE.md)

**总耗时**: 约 10-15 分钟

---

### 路径 2: 全面理解者

**目标**: 理解所有方案并做出最佳选择

1. 阅读 [📋 完整方案总结](./README_SUMMARY.md)（15 分钟）
2. 阅读 [📊 方案深度分析](./SOLUTION_ANALYSIS.md)（20 分钟）
3. 阅读 [🚀 迁移指南](./MIGRATION_GUIDE.md)（15 分钟）
4. 实施并测试（30 分钟）

**总耗时**: 约 1.5 小时

---

### 路径 3: 性能优化者

**目标**: 在稳定运行基础上进一步优化

1. 完成路径 1 或路径 2
2. 阅读 [🔍 API 分析指南](./API_ANALYSIS_GUIDE.md)（30 分钟）
3. 分析 Boss 直聘 API 接口（1 小时）
4. 实现混合方案（API + Offscreen）（1 小时）

**总耗时**: 约 2.5 小时（在路径 2 基础上）

---

## 🔍 按场景查找

### 场景 1: 我想立即开始使用

→ [⚡ 快速参考](./QUICK_REFERENCE.md) → 第 2 节"使用新版深度采集"

---

### 场景 2: 我遇到了错误

→ [⚡ 快速参考](./QUICK_REFERENCE.md) → "故障排除速查"表格

或

→ [🚀 迁移指南](./MIGRATION_GUIDE.md) → "常见问题"章节

---

### 场景 3: 我想理解为什么要用 Offscreen API

→ [📋 完整方案总结](./README_SUMMARY.md) → "方案对比表"

或

→ [📊 方案深度分析](./en/dev/SOLUTION_ANALYSIS.md) → "当前问题分析"

---

### 场景 4: 我想进一步提升速度

→ [🔍 API 分析指南](./en/dev/API_ANALYSIS_GUIDE.md) → "分析步骤"

→ [📋 完整方案总结](./README_SUMMARY.md) → "方案 4: 混合方案"

---

### 场景 5: 我想知道如何测试

→ [🚀 迁移指南](./MIGRATION_GUIDE.md) → "测试步骤"

或

→ [⚡ 快速参考](./QUICK_REFERENCE.md) → "验收检查清单"

---

## 📊 方案速查表

| 场景 | 推荐方案 | 相关文档 |
|------|----------|----------|
| **立即使用，无需深究** | Offscreen API | [快速参考](./QUICK_REFERENCE.md) |
| **需要最高成功率** | Offscreen API | [迁移指南](./en/dev/MIGRATION_GUIDE.md) |
| **需要最快速度** | API 直调 | [API 分析指南](./en/dev/API_ANALYSIS_GUIDE.md) |
| **需要兼顾速度和成功率** | 混合方案 | [完整总结](./README_SUMMARY.md) |
| **需要深入理解原理** | 阅读所有文档 | [方案分析](./en/dev/SOLUTION_ANALYSIS.md) |

---

## ❓ FAQ 快速查找

### Q: 我的 Chrome 是什么版本？需要升级吗？

**A**: 在地址栏输入 `chrome://version/`，需要 Chrome 109+

详见: [迁移指南 - Q1](./en/dev/MIGRATION_GUIDE.md#q1-chrome-版本不支持-offscreen-api)

---

### Q: 为什么 iframe 加载不了页面？

**A**: 可能是 `X-Frame-Options` 限制

详见: [迁移指南 - Q2](./en/dev/MIGRATION_GUIDE.md#q2-offscreen-中-iframe-无法加载页面x-frame-options)

---

### Q: 如何查看 Offscreen Document 的控制台？

**A**:
```javascript
chrome.runtime.getContexts({contextTypes: ['OFFSCREEN_DOCUMENT']})
  .then(c => console.log('Offscreen URL:', c[0].documentUrl));
```

详见: [快速参考 - 查看调试日志](./QUICK_REFERENCE.md#3️⃣-查看调试日志)

---

### Q: Boss 直聘有 API 接口吗？如何找到？

**A**: 使用 Chrome DevTools Network 面板，筛选 XHR/Fetch 请求

详见: [API 分析指南 - 分析步骤](./en/dev/API_ANALYSIS_GUIDE.md#🔍-分析步骤)

---

### Q: 如何切换回旧版（window.open 方式）？

**A**:
```javascript
// 使用旧版
const scraper = new DeepScraper(jobs, config);

// 使用新版
const scraper = new DeepScraperOffscreen(jobs, config);
```

详见: [快速参考 - 代码片段速查](./QUICK_REFERENCE.md#💡-代码片段速查)

---

## 🎯 检查清单

### 准备工作

- [ ] Chrome 版本 >= 109
- [ ] 所有新文件已创建 (`src/offscreen/*`)
- [ ] `manifest.json` 已添加 `offscreen` 权限
- [ ] `src/background/index.js` 已添加 Offscreen 管理逻辑

### 测试验证

- [ ] Offscreen Document 能成功创建
- [ ] 深度采集不打开新标签页 ⭐⭐⭐
- [ ] 能成功提取详情数据
- [ ] Service Worker 有正确的日志输出
- [ ] Offscreen Document 有正确的日志输出

### 性能优化（可选）

- [ ] 已分析 Boss 直聘 API 接口
- [ ] 已实现 API 直调方式
- [ ] 已实现混合方案（API + Offscreen 回退）
- [ ] 已调整延迟参数优化速度

---

## 📞 获取帮助

### 遇到技术问题

1. **查看文档**: 使用本索引找到相关章节
2. **查看日志**: 三个控制台（Service Worker / Offscreen / Content Script）
3. **检查配置**: 选择器、权限、文件路径

### 常见问题速查

- **无法创建 Offscreen** → [迁移指南 Q1](./en/dev/MIGRATION_GUIDE.md#q1-chrome-版本不支持-offscreen-api)
- **iframe 加载失败** → [迁移指南 Q2](./en/dev/MIGRATION_GUIDE.md#q2-offscreen-中-iframe-无法加载页面x-frame-options)
- **提取不到数据** → [迁移指南 Q3](./en/dev/MIGRATION_GUIDE.md#q3-提取不到数据)
- **速度太慢** → [迁移指南 Q4](./en/dev/MIGRATION_GUIDE.md#q4-速度太慢)

---

## 🌟 推荐阅读顺序

### 对于首次使用者

```
1. ⚡ 快速参考卡片 (5 分钟)
   ↓
2. 测试 Offscreen API (5 分钟)
   ↓
3. 使用新版深度采集 (10 分钟)
   ↓
4. 遇到问题时查看 🚀 迁移指南
```

### 对于深度用户

```
1. 📋 完整方案总结 (15 分钟)
   ↓
2. 📊 方案深度分析 (20 分钟)
   ↓
3. 🚀 迁移指南 (15 分钟)
   ↓
4. 🔍 API 分析指南 (30 分钟)
   ↓
5. 实施混合方案 (1 小时)
```

---

## 📈 版本演进

```
v1.0 - 原始版本 (window.open)
  ↓
v1.1 - 静默模式尝试 (archive/SILENT_MODE_UPGRADE.md)
  ↓
v1.2 - Offscreen API 方案 (本次更新)
  ↓
v1.3 - API 直调 + 混合方案 (规划中)
```

---

## ✅ 总结

**核心改进**: 从 `window.open()` 迁移到 **Offscreen API**

**核心优势**:
- ✅ 完全后台运行，用户无感知
- ✅ 真实浏览器环境，成功率高
- ✅ Chrome 官方推荐方案

**推荐路径**:
1. 立即使用 Offscreen API（已完成代码）
2. 调研 Boss 直聘 API 接口（性能优化）
3. 实现混合方案（最佳方案）

---

**祝你使用顺利！🚀**

如有问题，请参考上面的文档索引和 FAQ 章节。
