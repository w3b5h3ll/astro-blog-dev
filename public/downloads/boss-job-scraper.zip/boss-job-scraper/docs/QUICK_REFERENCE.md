# 🚀 快速参考卡片

## ⚡ 立即开始使用 Offscreen API

### 1️⃣ 验证扩展已更新

打开 Service Worker 控制台（`chrome://extensions/` → 点击 Service Worker）：

```javascript
// 测试 Offscreen API
chrome.offscreen.createDocument({
  url: chrome.runtime.getURL('src/offscreen/offscreen.html'),
  reasons: ['DOM_SCRAPING'],
  justification: '测试'
}).then(() => console.log('✅ Offscreen API 可用'));

// 查看 Offscreen Document
chrome.runtime.getContexts({
  contextTypes: ['OFFSCREEN_DOCUMENT']
}).then(c => console.log('Offscreen contexts:', c));
```

---

### 2️⃣ 使用新版深度采集

```javascript
// 使用 Offscreen API 版本（不打开新标签页）
const scraper = new DeepScraperOffscreen(jobs, config);
await scraper.start();
```

---

### 3️⃣ 查看调试日志

**三个地方查看日志**:

1. **Service Worker** (`chrome://extensions/` → Service Worker)
   - `[Background] Offscreen document 已创建`
   - `[Background] 发送抓取请求到 Offscreen`

2. **Offscreen Document** (Service Worker 控制台执行)
   ```javascript
   chrome.runtime.getContexts({contextTypes: ['OFFSCREEN_DOCUMENT']})
     .then(c => console.log('Offscreen URL:', c[0].documentUrl));
   // 复制 URL，在新标签页打开，打开 DevTools
   ```
   - `[Offscreen] 等待接收抓取任务...`
   - `[Offscreen] 开始加载: https://...`

3. **Content Script** (Boss 直聘页面的 DevTools)
   - `[Deep Scraper Offscreen] 开始深度采集`

---

## 🔧 故障排除速查

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| Cannot create offscreen document | Chrome 版本太低 | 升级到 Chrome 109+ |
| Offscreen 无响应 | 文件路径错误 | 检查 `src/offscreen/offscreen.html` 是否存在 |
| iframe 加载失败 | X-Frame-Options 限制 | 见 MIGRATION_GUIDE.md Q2 |
| 提取不到数据 | 选择器错误 | 在 Offscreen 控制台检查 DOM |
| 速度太慢 | 等待时间过长 | 减少 `maxWait` 时间 |

---

## 📋 文件清单速查

### 已创建的核心文件 ✅

```
src/offscreen/
├── offscreen.html          # Offscreen Document 页面
└── offscreen.js            # 在 iframe 中加载页面并提取数据

src/content/scraper/
└── deep-scraper-offscreen.js  # 新版深度采集类

src/background/
└── index.js                # 已修改：Offscreen 管理逻辑

manifest.json               # 已修改：添加 offscreen 权限
```

### 已创建的文档文件 ✅

```
SOLUTION_ANALYSIS.md        # 详细方案分析和代码示例
MIGRATION_GUIDE.md          # 迁移指南和常见问题
API_ANALYSIS_GUIDE.md       # 如何分析 Boss 直聘 API
README_SUMMARY.md           # 所有方案总结
QUICK_REFERENCE.md          # 本文件 - 快速参考
```

---

## 🎯 方案速查

| 方案 | 速度 | 成功率 | 用户体验 | 推荐度 |
|------|------|--------|----------|---------|
| **Offscreen API** | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **API 直调** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **混合方案** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |

**推荐路径**: Offscreen API (立即) → API 分析 (调研) → 混合方案 (最终)

---

## 🔍 Boss API 分析速查

### 快速分析步骤

1. 打开 Boss 直聘详情页
2. `F12` → Network → **Fetch/XHR**
3. 刷新页面 (`F5`)
4. 查找包含 `/api/`, `/wapi/`, `/json/` 的请求
5. 查看响应数据是否包含职位信息

### 常见 API 模式

```javascript
// 可能的 API 接口
https://www.zhipin.com/wapi/zpgeek/job/detail.json?id={jobId}

// 从 URL 提取 jobId
const jobId = url.match(/job_detail\/(.+?)\.html/)?.[1];

// 测试调用
fetch(`https://www.zhipin.com/wapi/zpgeek/job/detail.json?id=${jobId}`, {
  headers: { 'X-Requested-With': 'XMLHttpRequest' },
  credentials: 'include'
}).then(r => r.json()).then(console.log);
```

---

## 💡 代码片段速查

### 切换到 Offscreen 方案

```javascript
// 修改前
const scraper = new DeepScraper(jobs, config);

// 修改后
const scraper = new DeepScraperOffscreen(jobs, config);
```

### 动态选择方案

```javascript
const useOffscreen = true; // 配置项

const scraper = useOffscreen
  ? new DeepScraperOffscreen(jobs, config)
  : new DeepScraper(jobs, config);

await scraper.start();
```

### 混合方案（推荐）

```javascript
// 优先 API，失败回退到 Offscreen
async function scrapeJobDetail(url) {
  // 1. 尝试 API
  try {
    const data = await BossAPI.getJobDetail(url);
    if (data) return data;
  } catch (e) { console.warn('API failed'); }

  // 2. 回退到 Offscreen
  try {
    const data = await fetchViaOffscreen(url);
    if (data) return data;
  } catch (e) { console.warn('Offscreen failed'); }

  // 3. 最后回退到 window.open
  return await fetchViaNewTab(url);
}
```

---

## 📱 联系信息

- 📘 **详细文档**: [README_SUMMARY.md](./README_SUMMARY.md)
- 📘 **迁移指南**: [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md)
- 📘 **API 分析**: [API_ANALYSIS_GUIDE.md](./API_ANALYSIS_GUIDE.md)

---

## ✅ 验收检查清单

- [ ] Chrome 版本 >= 109
- [ ] 扩展加载无错误
- [ ] Service Worker 控制台有 Offscreen 日志
- [ ] 深度采集不打开新标签页 ⭐⭐⭐
- [ ] 能成功提取详情数据
- [ ] 侧边栏有实时进度显示

全部通过 = 迁移成功！🎉

---

## 🚀 性能提示

```javascript
// 调整等待时间（在 offscreen.js 中）
const maxWait = 3000; // 默认 5000，可减少到 3000

// 调整延迟（在 deep-scraper 中）
detailDelay: 1500,   // 默认 2000，可减少到 1500
randomDelay: true    // 启用随机延迟，避免检测
```

---

**一切准备就绪！开始使用 Offscreen API 吧！** 🎉
