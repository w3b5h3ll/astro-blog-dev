# Boss 直聘静默抓取方案 - 完整总结

## 📋 问题总结

你当前遇到的问题：

1. ❌ 使用 `fetch + DOMParser` 无法获取完整的详情页数据（可能是前端渲染）
2. ❌ 使用 `window.open()` 会打开可见的新标签页，用户体验差
3. ❌ 可能被 Boss 直聘的反爬虫机制检测

---

## 🎯 推荐方案汇总

我为你准备了 **3 种方案** + **1 个混合方案**：

### 方案对比表

| 方案 | 用户体验 | 成功率 | 速度 | 实施难度 | 推荐度 |
|------|----------|--------|------|----------|---------|
| **1. Offscreen API** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ **首选** |
| **2. API 直调** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ **推荐** |
| **3. Content Script Iframe** | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ 备选 |
| **4. 混合方案** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ **最佳** |

---

## 方案 1: Chrome Offscreen API ⭐⭐⭐⭐⭐

### 原理

```
[Content Script] 发起请求
    ↓
[Background Worker] 创建 Offscreen Document
    ↓
[Offscreen Document] 在隐藏 iframe 中加载详情页
    ↓ 执行 JavaScript，等待渲染完成
[Offscreen Document] 提取数据
    ↓
[Background Worker] 返回数据
    ↓
[Content Script] 更新职位信息
```

### 优势

- ✅ **完全后台运行** - 不打开可见窗口
- ✅ **真实浏览器环境** - 支持 JavaScript 渲染
- ✅ **官方推荐方案** - Chrome Manifest V3 最佳实践
- ✅ **绕过反爬检测** - 使用真实渲染引擎

### 已实现的文件

1. **`src/offscreen/offscreen.html`** - Offscreen Document 页面
2. **`src/offscreen/offscreen.js`** - Offscreen 脚本，负责在 iframe 中加载页面并提取数据
3. **`src/background/index.js`** - 已修改，添加 Offscreen 管理逻辑
4. **`src/content/scraper/deep-scraper-offscreen.js`** - 新版深度采集类
5. **`manifest.json`** - 已添加 `offscreen` 权限

### 使用方法

```javascript
// 使用新版深度采集
const scraper = new DeepScraperOffscreen(jobs, config);
await scraper.start();
```

### 详细文档

- 📘 **实现指南**: [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md)
- 📘 **方案分析**: [SOLUTION_ANALYSIS.md](./SOLUTION_ANALYSIS.md)

---

## 方案 2: API 直调 ⭐⭐⭐⭐

### 原理

绕过页面渲染，直接调用 Boss 直聘的数据接口。

```
[Content Script] 提取 jobId
    ↓
[API 调用] GET /wapi/zpgeek/job/detail.json?id={jobId}
    ↓
[解析 JSON] 提取字段
    ↓
[更新数据] 返回给 Content Script
```

### 优势

- ✅ **速度最快** - 无需等待页面渲染
- ✅ **资源消耗小** - 只请求 JSON 数据
- ✅ **实现简单** - 不需要复杂的 DOM 操作

### 需要分析的内容

1. Boss 直聘是否有公开的 API 接口？
2. API 需要哪些参数？（jobId, securityId 等）
3. 是否需要签名验证？
4. 是否有频率限制？

### 分析步骤

详见 **[API_ANALYSIS_GUIDE.md](./API_ANALYSIS_GUIDE.md)**

---

## 方案 3: Content Script Iframe ⭐⭐⭐

### 原理

在 Content Script 中创建隐藏的 iframe 加载详情页。

```javascript
// 在当前页面创建隐藏 iframe
const iframe = document.createElement('iframe');
iframe.style.display = 'none';
iframe.src = jobUrl;
document.body.appendChild(iframe);

// 等待加载完成
iframe.onload = () => {
  const data = extractDataFromDocument(iframe.contentDocument);
  // ...
};
```

### 优势

- ✅ 不打开新标签页
- ✅ 可以执行 JavaScript
- ✅ 实现相对简单

### 限制

- ⚠️ 可能遇到 `X-Frame-Options` 限制
- ⚠️ 页面可能检测到 iframe 环境
- ⚠️ 同源策略限制（虽然扩展有 host_permissions）

---

## 方案 4: 混合方案 ⭐⭐⭐⭐⭐ **最佳实践**

### 智能回退策略

```javascript
async function scrapeJobDetailSmart(jobUrl) {
  // 优先级 1: API 直调（最快）
  try {
    const data = await BossAPI.getJobDetail(jobUrl);
    if (data) return { success: true, data, method: 'API' };
  } catch (error) {
    console.warn('API 方式失败，尝试下一个方案');
  }

  // 优先级 2: Offscreen API（最稳定）
  try {
    const data = await fetchJobDetailViaOffscreen(jobUrl);
    if (data) return { success: true, data, method: 'Offscreen' };
  } catch (error) {
    console.warn('Offscreen 方式失败，尝试下一个方案');
  }

  // 优先级 3: window.open（兜底方案）
  try {
    const data = await fetchJobDetailInNewTab(jobUrl);
    if (data) return { success: true, data, method: 'NewTab' };
  } catch (error) {
    console.warn('所有方法均失败');
  }

  return { success: false, error: '所有方法均失败' };
}
```

### 优势

- ✅ **速度 + 成功率兼顾** - API 快速，Offscreen 稳定
- ✅ **自动降级** - 一个失败自动尝试下一个
- ✅ **最大化成功率** - 三重保障

---

## 📁 已创建的文件清单

### 核心实现文件

1. **`src/offscreen/offscreen.html`** ✅
   Offscreen Document 的 HTML 页面

2. **`src/offscreen/offscreen.js`** ✅
   Offscreen 脚本，负责在 iframe 中加载页面并提取数据

3. **`src/content/scraper/deep-scraper-offscreen.js`** ✅
   使用 Offscreen API 的新版深度采集类

4. **`src/background/index.js`** ✅
   已修改，添加 Offscreen 管理和消息处理逻辑

5. **`manifest.json`** ✅
   已添加 `offscreen` 权限

### 文档文件

1. **`SOLUTION_ANALYSIS.md`** ✅
   详细的方案分析和代码示例

2. **`MIGRATION_GUIDE.md`** ✅
   从旧方案迁移到 Offscreen API 的完整指南

3. **`API_ANALYSIS_GUIDE.md`** ✅
   如何分析 Boss 直聘 API 接口的详细步骤

4. **`README_SUMMARY.md`** (本文件) ✅
   所有方案的总结

---

## 🚀 快速开始

### 立即使用 Offscreen API 方案

#### 步骤 1: 确认文件已创建

检查以下文件是否存在：
```bash
ls -la src/offscreen/
ls -la src/content/scraper/deep-scraper-offscreen.js
```

#### 步骤 2: 加载扩展

1. 打开 `chrome://extensions/`
2. 开启"开发者模式"
3. 点击"加载已解压的扩展程序"
4. 选择项目目录

#### 步骤 3: 测试 Offscreen API

打开 Service Worker 控制台（在扩展卡片上点击"Service Worker"）：

```javascript
// 测试创建 Offscreen Document
chrome.offscreen.createDocument({
  url: chrome.runtime.getURL('src/offscreen/offscreen.html'),
  reasons: ['DOM_SCRAPING'],
  justification: '测试'
});

// 验证是否创建成功
chrome.runtime.getContexts({
  contextTypes: ['OFFSCREEN_DOCUMENT']
}).then(contexts => console.log('Offscreen contexts:', contexts));
```

#### 步骤 4: 使用新版深度采集

修改你的调用代码，使用 `DeepScraperOffscreen` 替代 `DeepScraper`：

```javascript
// 旧版
// const scraper = new DeepScraper(jobs, config);

// 新版
const scraper = new DeepScraperOffscreen(jobs, config);
await scraper.start();
```

或者在 `manifest.json` 中同时加载两个版本，然后动态选择：

```json
"content_scripts": [{
  "js": [
    "src/content/selector/index.js",
    "src/content/scraper/index.js",
    "src/content/scraper/deep-scraper.js",           // 旧版
    "src/content/scraper/deep-scraper-offscreen.js", // 新版
    "src/content/index.js"
  ]
}]
```

---

## 🔍 进一步调研

### 调研 Boss 直聘 API 接口

按照 **[API_ANALYSIS_GUIDE.md](./API_ANALYSIS_GUIDE.md)** 的步骤：

1. 打开 Boss 直聘职位详情页
2. 打开 Chrome DevTools → Network 面板
3. 筛选 XHR/Fetch 请求
4. 查找 API 接口（如 `/wapi/`, `/api/`, `/json/`）
5. 分析请求参数和响应数据
6. 实现 API 调用逻辑

### 可能的 API 模式

```javascript
// 示例 1: 直接调用 API
GET https://www.zhipin.com/wapi/zpgeek/job/detail.json?id={jobId}

// 示例 2: 从 HTML 中提取嵌入的 JSON
<script>
  window.__INITIAL_STATE__ = {
    jobInfo: { ... },
    companyInfo: { ... }
  };
</script>
```

---

## 📊 性能对比

| 方案 | 平均耗时 | 成功率 | 资源消耗 | 用户感知 |
|------|----------|--------|----------|----------|
| **window.open** | ~3秒/个 | 85% | 高（加载完整页面） | ❌ 可见标签页 |
| **Offscreen API** | ~2秒/个 | 95% | 中（后台渲染） | ✅ 完全隐藏 |
| **API 直调** | ~0.5秒/个 | 90% | 低（仅 JSON） | ✅ 完全隐藏 |
| **混合方案** | ~1秒/个 | 98% | 中 | ✅ 完全隐藏 |

*以上数据为估算值，实际效果取决于网络速度和 Boss 直聘的反爬策略*

---

## ❗ 常见问题

### Q1: Chrome 版本不支持 Offscreen API

**解决**: 升级到 Chrome 109+ 版本

检查版本：
```javascript
chrome://version/
```

---

### Q2: Offscreen 中 iframe 无法加载页面（X-Frame-Options）

**现象**: 在 Offscreen 控制台看到 `Refused to display ... in a frame`

**解决**:

方法 1: 使用 `declarativeNetRequest` API 移除 `X-Frame-Options` 头

```json
// manifest.json
{
  "permissions": ["declarativeNetRequest"],
  "declarative_net_request": {
    "rule_resources": [{
      "id": "remove_x_frame_options",
      "enabled": true,
      "path": "rules.json"
    }]
  }
}
```

```json
// rules.json
[{
  "id": 1,
  "priority": 1,
  "action": {
    "type": "modifyHeaders",
    "responseHeaders": [
      { "header": "X-Frame-Options", "operation": "remove" },
      { "header": "Content-Security-Policy", "operation": "remove" }
    ]
  },
  "condition": {
    "urlFilter": "https://www.zhipin.com/*",
    "resourceTypes": ["sub_frame"]
  }
}]
```

方法 2: 回退到 API 直调或 window.open 方式

---

### Q3: 提取不到数据

**检查**:

1. 选择器是否正确？
   - 在 Offscreen Document 控制台中打印 `iframe.contentDocument`
   - 检查 DOM 结构是否与预期一致

2. 页面是否完全渲染？
   - 增加 `waitForContent` 的等待时间
   - 检查是否有关键元素加载完成

3. 是否有数据验证逻辑拒绝了数据？
   - 检查 AI 验证或正则验证的日志
   - 临时关闭验证测试

---

### Q4: 速度太慢

**优化**:

1. 减少等待时间
   ```javascript
   const maxWait = 3000; // 从 5秒 减少到 3秒
   ```

2. 优先使用 API 直调方式

3. 并发抓取（高级）
   ```javascript
   // 同时创建多个 iframe
   const results = await Promise.all([
     scrapeJobDetail(url1),
     scrapeJobDetail(url2),
     scrapeJobDetail(url3)
   ]);
   ```

---

## 🎯 下一步行动

### 立即可做

1. ✅ **测试 Offscreen API 方案**
   - 加载扩展
   - 测试是否能创建 Offscreen Document
   - 测试是否能抓取详情页数据

2. ✅ **分析 Boss 直聘 API**
   - 打开 DevTools Network 面板
   - 查找数据接口
   - 尝试调用 API

### 短期优化

1. 🔧 **实现混合方案**
   - API 直调 + Offscreen API 回退
   - 提高速度和成功率

2. 🔧 **添加错误处理**
   - 网络错误重试
   - 频率限制检测

### 长期优化

1. 🚀 **并发抓取**
   - 使用队列控制并发数
   - 避免频率限制

2. 🚀 **智能延迟**
   - 根据成功率动态调整延迟
   - 检测到限制时自动增加延迟

---

## 📞 需要帮助？

如果遇到问题，请检查：

1. Chrome 版本是否 >= 109
2. 三个地方的控制台日志：
   - Service Worker 控制台
   - Offscreen Document 控制台
   - Content Script 控制台
3. 选择器配置是否正确
4. Boss 直聘是否允许 iframe 加载

---

## 📚 相关文档

- 📘 **[SOLUTION_ANALYSIS.md](./SOLUTION_ANALYSIS.md)** - 详细方案分析
- 📘 **[MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md)** - 迁移指南
- 📘 **[API_ANALYSIS_GUIDE.md](./API_ANALYSIS_GUIDE.md)** - API 分析指南

---

## ✅ 验收标准

迁移成功的标志：

- [x] 扩展能正常加载
- [ ] 深度采集**不会打开新标签页**
- [ ] 能成功提取详情页数据
- [ ] 在侧边栏能看到实时进度
- [ ] Service Worker 控制台有 Offscreen 相关日志
- [ ] 采集速度和成功率达到预期

---

## 🎉 总结

通过本次改进：

1. ✅ **完全后台运行** - Offscreen API 方案
2. ✅ **大幅提升速度** - API 直调方案（如果可行）
3. ✅ **智能回退机制** - 混合方案
4. ✅ **符合官方规范** - Manifest V3 最佳实践

**推荐路径**:

1. **立即实施** Offscreen API 方案（已完成代码）
2. **同步调研** Boss 直聘 API 接口
3. **最终实现** 混合方案（API + Offscreen 回退）

Good luck! 🚀
