# 更新说明 - AI验证增强 & 滚动随机延迟

## 📅 更新日期
2024年

## ✨ 更新内容

### 1. AI 智能验证增强

#### 新增验证字段
- ✅ **公司规模** (companySize) - 已有
- ✅ **所属行业** (industry) - **新增**

#### 验证逻辑
```javascript
// 支持的验证字段
shouldUseAIValidation(field) {
  if (!this.enableAIValidation) {
    return false;
  }

  // 对公司规模和所属行业字段使用 AI 验证
  return field === 'companySize' || field === 'industry';
}
```

#### 所属行业验证规则
AI 会判断提取的文本是否为真实的行业信息：

**合法行业示例**：
- ✅ 互联网
- ✅ 电子商务
- ✅ 金融科技
- ✅ 企业服务
- ✅ 教育培训
- ✅ 医疗健康

**非法内容（会被过滤）**：
- ❌ 融资信息（如"A轮"、"B轮"）
- ❌ 公司规模（如"100-500人"）
- ❌ 其他无关信息

#### AI Prompt
```
请判断以下文本是否是"所属行业"信息。
所属行业通常是行业类别，如"互联网"、"电子商务"、"金融科技"、"企业服务"、"教育培训"等。

如果是所属行业信息，请直接返回原文。
如果不是所属行业信息（比如融资信息、公司规模等），请只返回"INVALID"。

文本：${value}

回答：
```

---

### 2. 列表页滚动随机延迟

#### 变更说明
之前只有深度采集（详情页）支持随机延迟，现在**列表页滚动加载**也支持随机延迟。

#### 默认行为
- **默认开启** - `randomDelay` 默认值为 `true`
- 用户可以在设置中关闭

#### 实现逻辑

**AutoScroller 构造函数**：
```javascript
constructor(config = {}) {
  this.scrollDelay = config.scrollDelay || 1000;
  this.randomDelay = config.randomDelay !== false; // 默认开启
  this.maxRetries = config.maxRetries || 3;
  // ...
}
```

**延迟计算**：
```javascript
getActualScrollDelay() {
  let delay = this.scrollDelay;

  if (this.randomDelay) {
    // 在基础延迟上 ±30% 随机
    const randomFactor = 0.7 + Math.random() * 0.6; // 0.7 到 1.3
    delay = Math.floor(delay * randomFactor);
  }

  return delay;
}
```

**示例**：
- 基础延迟设置为 1000ms
- 实际延迟范围：**700ms ~ 1300ms**
- 每次滚动都会随机计算

---

## 🎯 修改的文件

### 1. src/content/scraper/deep-scraper.js
- ✅ `shouldUseAIValidation()` - 增加 `industry` 字段
- ✅ `validateWithAI()` - 增加所属行业的 prompt

### 2. src/content/scraper/deep-scraper-offscreen.js
- ✅ `validateWithAI()` - 同步修改，保持一致性
- ✅ AI验证逻辑 - 同时验证 companySize 和 industry

### 3. src/content/scraper/index.js
- ✅ `AutoScroller` 构造函数 - 增加 `randomDelay` 参数
- ✅ `scrollToLoadAll()` - 使用 `getActualScrollDelay()` 计算延迟
- ✅ `getActualScrollDelay()` - 新增方法，计算随机延迟
- ✅ `JobScraper` 构造函数 - 传递 `randomDelay` 参数

---

## 📊 功能对比

| 功能 | 修改前 | 修改后 |
|------|--------|--------|
| **AI验证字段** | 公司规模 | 公司规模 + 所属行业 |
| **列表页滚动延迟** | 固定延迟 | 随机延迟（默认开启）|
| **深度采集延迟** | 随机延迟（可选） | 随机延迟（默认开启）|

---

## 🚀 使用方式

### 用户视角
**无需任何操作** - 默认即可享受以下增强：

1. **AI 验证自动过滤**
   - 公司规模字段错误数据自动过滤
   - 所属行业字段错误数据自动过滤
   - 只保留真实有效的信息

2. **更自然的采集行为**
   - 列表页滚动不再是固定间隔
   - 每次滚动延迟随机变化
   - 更像人工操作，降低被检测风险

### 开发者视角

**关闭随机延迟**（如果需要）：
```javascript
const config = {
  scrollDelay: 1000,
  randomDelay: false  // 显式关闭
};

const scraper = new JobScraper(selector, config);
```

**关闭AI验证**（如果需要）：
```javascript
const config = {
  enableAIValidation: false
};

const deepScraper = new DeepScraper(jobs, config);
```

---

## 💡 技术细节

### AI 验证流程
```
1. 提取字段值
   ↓
2. 判断是否需要AI验证（companySize/industry）
   ↓
3. 调用本地 Copilot API（http://localhost:4141）
   ↓
4. AI判断数据合理性
   ↓
5. 返回结果：
   - 合理 → 保留原值或AI清洗后的值
   - 不合理 → 返回 null（过滤）
   ↓
6. 失败回退 → 使用正则基础验证
```

### 随机延迟算法
```javascript
// 公式
actualDelay = baseDelay × randomFactor

// 其中
randomFactor = 0.7 + Math.random() × 0.6
             = 0.7 ~ 1.3

// 示例
baseDelay = 1000ms
actualDelay = 1000 × (0.7 ~ 1.3)
            = 700 ~ 1300ms
```

---

## ⚠️ 注意事项

### AI 验证
1. **需要本地 Copilot API**
   - 地址：`http://localhost:4141/v1/chat/completions`
   - 如果 API 不可用，会自动回退到正则验证

2. **验证失败处理**
   - AI 验证失败 → 回退到正则验证
   - 正则验证失败 → 字段被过滤（不显示）

3. **性能影响**
   - 每个字段多一次 API 调用
   - 平均耗时：100-500ms
   - 可通过 `enableAIValidation: false` 关闭

### 随机延迟
1. **默认开启**
   - 列表页滚动：默认开启
   - 深度采集：默认开启

2. **延迟范围**
   - 基于基础延迟的 70% ~ 130%
   - 如基础 1000ms → 实际 700-1300ms

3. **关闭方式**
   - 通过配置 `randomDelay: false` 关闭

---

## 🎉 预期效果

### AI 验证效果
**修改前**：
```
公司规模：已上市（错误）
所属行业：A轮（错误）
```

**修改后**：
```
公司规模：（AI验证失败，已过滤）
所属行业：（AI验证失败，已过滤）
```

### 随机延迟效果
**修改前**：
```
滚动1：等待 1000ms
滚动2：等待 1000ms
滚动3：等待 1000ms
（规律明显，容易被检测）
```

**修改后**：
```
滚动1：等待 873ms
滚动2：等待 1142ms
滚动3：等待 956ms
（随机变化，更像人工）
```

---

## 📝 测试建议

### AI 验证测试
1. 找一个所属行业字段配置错误的职位
2. 开启 AI 验证
3. 执行深度采集
4. 查看调试日志，确认 AI 过滤了错误数据

### 随机延迟测试
1. 打开 Boss 直聘职位列表
2. 打开浏览器控制台
3. 执行基础采集
4. 观察日志中的延迟时间，确认每次都不同

---

## 🔄 版本兼容性

- ✅ 向后兼容
- ✅ 不影响现有配置
- ✅ 默认行为更优

---

**修改完成！重新加载扩展即可使用。** 🚀
