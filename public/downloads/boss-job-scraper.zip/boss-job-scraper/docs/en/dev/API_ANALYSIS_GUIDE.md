# Boss 直聘 API 接口分析指南

## 🎯 目标

分析 Boss 直聘是否提供了可以直接调用的数据接口，如果有，则可以绕过页面渲染，直接获取数据，速度会大幅提升。

---

## 🔍 分析步骤

### 步骤 1: 打开 Chrome DevTools 网络面板

1. 访问 Boss 直聘职位详情页
   - 例如: `https://www.zhipin.com/job_detail/xxxxx.html`

2. 打开 Chrome DevTools (F12)

3. 切换到 **Network** (网络) 面板

4. 勾选 **Preserve log** (保留日志)

5. 刷新页面 (F5)

---

### 步骤 2: 筛选 XHR/Fetch 请求

1. 在 Network 面板中，点击 **Fetch/XHR** 过滤器

2. 查找可疑的 API 请求，特征：
   - URL 包含 `/api/`, `/wapi/`, `/ajax/`, `/json/` 等
   - 响应类型为 `application/json`
   - 响应内容包含职位数据（薪资、描述、公司规模等）

3. 常见的 Boss 直聘 API 模式：
   ```
   https://www.zhipin.com/wapi/zpgeek/job/detail.json?id=xxxxx
   https://www.zhipin.com/wapi/zpgeek/job/card.json?securityId=xxxxx
   ```

---

### 步骤 3: 分析 API 请求

点击找到的 API 请求，查看：

#### 1. 请求头 (Request Headers)

```http
GET /wapi/zpgeek/job/detail.json?id=xxxxx HTTP/1.1
Host: www.zhipin.com
User-Agent: Mozilla/5.0 ...
Referer: https://www.zhipin.com/job_detail/xxxxx.html
Cookie: __zp_stoken__=xxxxx; ...
X-Requested-With: XMLHttpRequest
```

**关键字段**:
- `Cookie` - 是否需要登录态？
- `Referer` - 是否需要来源验证？
- `X-Requested-With` - 是否需要 AJAX 标记？

#### 2. 请求参数 (Query String Parameters)

```
id: xxxxx
securityId: xxxxx
lid: xxxxx
sessionId: xxxxx
```

**问题**:
- 这些参数从哪里来？
- 是从 URL 提取还是从页面 HTML 中提取？
- 是否有加密签名？

#### 3. 响应内容 (Response)

```json
{
  "code": 0,
  "message": "Success",
  "zpData": {
    "jobInfo": {
      "jobName": "前端工程师",
      "salaryDesc": "20-40K·14薪",
      "jobLabels": ["五险一金", "带薪年假"],
      "postDescription": "职位描述内容..."
    },
    "bossInfo": {
      "activeTimeDesc": "本周活跃"
    },
    "brandComInfo": {
      "brandName": "阿里巴巴",
      "brandScaleName": "10000人以上",
      "brandIndustry": "互联网"
    }
  }
}
```

**检查**:
- 数据结构是否完整？
- 是否包含所有需要的字段？

---

### 步骤 4: 提取必要参数

#### 方法 1: 从 URL 中提取

如果参数可以从职位详情页 URL 中提取：

```javascript
// 示例 URL: https://www.zhipin.com/job_detail/abc123xyz.html
const url = 'https://www.zhipin.com/job_detail/abc123xyz.html';
const jobId = url.match(/job_detail\/(.+?)\.html/)?.[1];

// 构建 API 请求
const apiUrl = `https://www.zhipin.com/wapi/zpgeek/job/detail.json?id=${jobId}`;
```

#### 方法 2: 从页面 HTML 中提取

如果参数嵌入在页面 HTML 中：

```javascript
// 使用 fetch 获取 HTML
const response = await fetch(url);
const html = await response.text();
const parser = new DOMParser();
const doc = parser.parseFromString(html, 'text/html');

// 方法 2.1: 从 script 标签中提取 JSON
const scriptTags = doc.querySelectorAll('script');
for (const script of scriptTags) {
  const content = script.textContent;

  // 查找嵌入的 JSON 数据
  if (content.includes('window.__INITIAL_STATE__')) {
    const match = content.match(/window\.__INITIAL_STATE__\s*=\s*({.+?});/);
    if (match) {
      const data = JSON.parse(match[1]);
      console.log('找到嵌入数据:', data);
      return data;
    }
  }

  // 或者查找其他变量
  if (content.includes('window.jobDetailData')) {
    const match = content.match(/window\.jobDetailData\s*=\s*({.+?});/);
    if (match) {
      const data = JSON.parse(match[1]);
      return data;
    }
  }
}

// 方法 2.2: 从 data-* 属性中提取
const jobElement = doc.querySelector('[data-job-id]');
if (jobElement) {
  const jobId = jobElement.getAttribute('data-job-id');
  const securityId = jobElement.getAttribute('data-security-id');
  console.log('找到参数:', { jobId, securityId });
}
```

---

### 步骤 5: 测试 API 调用

#### 方法 1: 在浏览器控制台中测试

在 Boss 直聘页面的 DevTools 控制台中：

```javascript
// 测试 API 调用
fetch('https://www.zhipin.com/wapi/zpgeek/job/detail.json?id=xxxxx', {
  method: 'GET',
  headers: {
    'X-Requested-With': 'XMLHttpRequest',
    'Referer': 'https://www.zhipin.com/job_detail/xxxxx.html'
  },
  credentials: 'include' // 带上 Cookie
})
  .then(res => res.json())
  .then(data => console.log('API 返回数据:', data))
  .catch(err => console.error('API 调用失败:', err));
```

#### 方法 2: 在 Chrome 扩展中测试

在 background.js 中添加测试函数：

```javascript
async function testBossAPI(jobId) {
  try {
    const response = await fetch(
      `https://www.zhipin.com/wapi/zpgeek/job/detail.json?id=${jobId}`,
      {
        method: 'GET',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'Referer': `https://www.zhipin.com/job_detail/${jobId}.html`,
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        },
        credentials: 'include'
      }
    );

    if (!response.ok) {
      console.error('API 返回错误:', response.status, response.statusText);
      return null;
    }

    const data = await response.json();
    console.log('API 返回数据:', data);
    return data;

  } catch (error) {
    console.error('API 调用失败:', error);
    return null;
  }
}

// 在 Service Worker 控制台中调用
testBossAPI('abc123xyz');
```

---

## 🔐 处理反爬虫机制

### 情况 1: 需要 Cookie (登录态)

**解决方案**:
- 使用 `credentials: 'include'` 自动带上 Cookie
- 确保用户已登录 Boss 直聘

```javascript
fetch(url, {
  credentials: 'include' // 自动带上当前域的 Cookie
});
```

---

### 情况 2: 需要 Referer 验证

**解决方案**:
- 在请求头中添加正确的 `Referer`

```javascript
headers: {
  'Referer': 'https://www.zhipin.com/job_detail/xxxxx.html'
}
```

---

### 情况 3: 有签名验证 (如 timestamp + signature)

**特征**:
```
https://www.zhipin.com/wapi/zpgeek/job/detail.json?
  id=xxxxx
  &timestamp=1234567890
  &signature=abc123def456
```

**分析步骤**:

1. 在 Network 面板中找到请求，复制为 cURL

2. 在页面中搜索 `signature` 或 `sign` 关键词，找到签名生成逻辑

3. 常见签名算法：
   - MD5(id + timestamp + secret)
   - HMAC-SHA256(params, secret)

4. 如果签名逻辑在压缩后的 JS 中，可以：
   - 使用 Chrome DevTools 的 Sources 面板格式化代码
   - 设置断点，查看签名生成过程
   - 或者直接复制签名逻辑到扩展中

---

### 情况 4: 有频率限制

**特征**:
- 返回 429 Too Many Requests
- 返回 "访问频繁，请稍后再试"

**解决方案**:
- 添加延迟（1-3秒）
- 使用随机延迟
- 控制并发数

```javascript
// 在深度采集中添加延迟
async delayWithRandom() {
  const delay = 2000 + Math.random() * 1000; // 2-3秒随机延迟
  await this.sleep(delay);
}
```

---

## 📝 实现示例

假设分析出 Boss 直聘的 API 接口为：

```
GET https://www.zhipin.com/wapi/zpgeek/job/detail.json?id={jobId}
```

参数可以从 URL 中提取：

```
https://www.zhipin.com/job_detail/abc123xyz.html
→ jobId = abc123xyz
```

### 实现代码

创建 `src/content/scraper/boss-api.js`:

```javascript
/**
 * Boss 直聘 API 调用类
 */
class BossAPI {
  /**
   * 从职位详情页 URL 中提取 jobId
   * @param {string} url - 职位详情页 URL
   * @returns {string|null} jobId
   */
  static extractJobId(url) {
    const match = url.match(/job_detail\/(.+?)\.html/);
    return match ? match[1] : null;
  }

  /**
   * 调用 Boss 直聘的职位详情 API
   * @param {string} jobId - 职位 ID
   * @returns {Promise<object|null>} 职位详情数据
   */
  static async fetchJobDetail(jobId) {
    try {
      const apiUrl = `https://www.zhipin.com/wapi/zpgeek/job/detail.json?id=${jobId}`;

      console.log('[Boss API] 调用接口:', apiUrl);

      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'Referer': `https://www.zhipin.com/job_detail/${jobId}.html`,
          'User-Agent': navigator.userAgent
        },
        credentials: 'include' // 带上 Cookie
      });

      if (!response.ok) {
        console.error('[Boss API] 请求失败:', response.status, response.statusText);
        return null;
      }

      const data = await response.json();

      if (data.code !== 0) {
        console.error('[Boss API] 接口返回错误:', data.message);
        return null;
      }

      console.log('[Boss API] 接口返回数据:', data);
      return data.zpData; // 或者 data.data，根据实际情况

    } catch (error) {
      console.error('[Boss API] 调用失败:', error);
      return null;
    }
  }

  /**
   * 从 API 数据中提取字段
   * @param {object} apiData - API 返回的数据
   * @returns {object} 提取的字段
   */
  static extractFields(apiData) {
    if (!apiData) return {};

    try {
      const jobInfo = apiData.jobInfo || {};
      const bossInfo = apiData.bossInfo || {};
      const companyInfo = apiData.brandComInfo || {};

      return {
        salary: jobInfo.salaryDesc || '',
        description: jobInfo.postDescription || '',
        welfare: jobInfo.jobLabels || [],
        hrActivity: bossInfo.activeTimeDesc || '',
        companySize: companyInfo.brandScaleName || '',
        industry: companyInfo.brandIndustry || ''
      };

    } catch (error) {
      console.error('[Boss API] 提取字段失败:', error);
      return {};
    }
  }

  /**
   * 获取职位详情（完整流程）
   * @param {string} jobUrl - 职位详情页 URL
   * @returns {Promise<object|null>} 提取的字段
   */
  static async getJobDetail(jobUrl) {
    const jobId = this.extractJobId(jobUrl);

    if (!jobId) {
      console.error('[Boss API] 无法从 URL 中提取 jobId:', jobUrl);
      return null;
    }

    const apiData = await this.fetchJobDetail(jobId);

    if (!apiData) {
      return null;
    }

    return this.extractFields(apiData);
  }
}

// 导出为全局变量
window.BossAPI = BossAPI;
```

### 使用 API 方式的深度采集

修改 `deep-scraper.js`，添加 API 调用方式：

```javascript
// 采集单个职位详情
async scrapeJobDetail(job) {
  try {
    if (!job.jobUrl) {
      console.warn('[Deep Scraper] 职位没有链接:', job.title);
      return false;
    }

    console.log('[Deep Scraper] 访问详情页:', job.jobUrl);

    this.sendProgress(this.currentIndex + 1, this.jobs.length, job, null);

    // 优先尝试使用 API 方式
    let detailData = null;

    if (window.BossAPI) {
      console.log('[Deep Scraper] 尝试使用 API 方式');
      detailData = await BossAPI.getJobDetail(job.jobUrl);
    }

    // 如果 API 失败，回退到 Offscreen 方式
    if (!detailData && window.chrome?.runtime) {
      console.log('[Deep Scraper] API 失败，回退到 Offscreen 方式');
      detailData = await this.fetchJobDetailViaOffscreen(job.jobUrl);
    }

    // 如果 Offscreen 也失败，回退到 window.open 方式
    if (!detailData) {
      console.log('[Deep Scraper] Offscreen 失败，回退到 window.open 方式');
      detailData = await this.fetchJobDetailInNewTab(job.jobUrl);
    }

    if (detailData) {
      // 更新职位数据
      if (detailData.salary) job.salary = detailData.salary;
      if (detailData.description) job.description = detailData.description;
      if (detailData.welfare) job.welfare = detailData.welfare;
      if (detailData.hrActivity) job.hrActivity = detailData.hrActivity;
      if (detailData.companySize) job.companySize = detailData.companySize;
      if (detailData.industry) job.industry = detailData.industry;

      this.sendDebugLog('success', `✓ ${job.title}`);
      return true;
    } else {
      this.sendDebugLog('error', `✗ ${job.title} - 所有方法均失败`);
      return false;
    }

  } catch (error) {
    console.error('[Deep Scraper] 提取详情失败:', error);
    this.sendDebugLog('error', `✗ ${job.title} - ${error.message}`);
    return false;
  }
}
```

---

## 📊 方案对比

| 方案 | 速度 | 成功率 | 反爬能力 | 复杂度 |
|------|------|--------|----------|--------|
| **API 直调** | ⭐⭐⭐⭐⭐ 最快 | ⭐⭐⭐⭐ 较高 | ⭐⭐⭐ 中等 | ⭐⭐ 简单 |
| **Offscreen API** | ⭐⭐⭐ 中等 | ⭐⭐⭐⭐⭐ 最高 | ⭐⭐⭐⭐⭐ 最强 | ⭐⭐⭐ 中等 |
| **window.open** | ⭐⭐⭐⭐ 较快 | ⭐⭐⭐ 中等 | ⭐⭐ 较弱 | ⭐ 最简单 |
| **fetch + DOMParser** | ⭐⭐⭐⭐⭐ 最快 | ⭐⭐ 较低 | ⭐⭐⭐ 中等 | ⭐ 最简单 |

---

## 🎯 最佳实践

### 智能回退策略

```javascript
// 依次尝试多种方案
async function scrapeJobDetailSmart(jobUrl) {
  // 1. 优先尝试 API 直调（最快）
  try {
    const data = await BossAPI.getJobDetail(jobUrl);
    if (data) return { success: true, data, method: 'API' };
  } catch (error) {
    console.warn('API 方式失败:', error);
  }

  // 2. 尝试 Offscreen API（最稳定）
  try {
    const data = await fetchJobDetailViaOffscreen(jobUrl);
    if (data) return { success: true, data, method: 'Offscreen' };
  } catch (error) {
    console.warn('Offscreen 方式失败:', error);
  }

  // 3. 回退到 window.open（兜底方案）
  try {
    const data = await fetchJobDetailInNewTab(jobUrl);
    if (data) return { success: true, data, method: 'NewTab' };
  } catch (error) {
    console.warn('NewTab 方式失败:', error);
  }

  // 4. 所有方法均失败
  return { success: false, error: '所有方法均失败' };
}
```

---

## ✅ 检查清单

在实施 API 方案前，确认以下事项：

- [ ] 已找到 Boss 直聘的职位详情 API 接口
- [ ] 已确认 API 需要的参数（jobId, securityId 等）
- [ ] 已确认参数的获取方式（URL 提取或 HTML 解析）
- [ ] 已测试 API 调用是否成功
- [ ] 已确认 API 返回的数据结构
- [ ] 已实现字段提取逻辑
- [ ] 已处理反爬虫机制（Cookie, Referer, 签名等）
- [ ] 已添加错误处理和回退机制
- [ ] 已添加延迟避免频率限制

---

## 📞 总结

通过分析 Boss 直聘的 API 接口，可以：

1. ✅ **大幅提升速度** - 无需等待页面渲染
2. ✅ **降低资源消耗** - 不需要加载完整页面
3. ✅ **提高成功率** - 避免页面加载失败

但需要注意：

- ⚠️ API 接口可能随时变化
- ⚠️ 可能有签名验证，需要逆向分析
- ⚠️ 可能有频率限制

**最佳方案**: **API 直调 + Offscreen API 混合**
- 优先使用 API 直调（速度快）
- 失败时回退到 Offscreen API（成功率高）
- 提供 window.open 作为最终兜底方案
