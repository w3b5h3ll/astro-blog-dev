# 迁移到 Offscreen API 方案指南

## 📋 概述

本指南介绍如何从当前的 `window.open()` 方式迁移到 **Offscreen API** 方式进行职位详情页抓取。

---

## 🎯 改进效果

### 之前（window.open 方式）
- ❌ 打开可见的新标签页，干扰用户
- ❌ 可能遇到跨域问题
- ❌ 容易被反爬检测

### 之后（Offscreen API 方式）
- ✅ **完全后台运行**，用户无感知
- ✅ 真实浏览器环境，支持 JavaScript 渲染
- ✅ 绕过反爬检测
- ✅ Chrome 官方推荐方案

---

## 📁 新增文件

```
boss-job-scraper/
├── manifest.json (已修改：添加 offscreen 权限)
├── src/
│   ├── background/
│   │   └── index.js (已修改：添加 Offscreen 管理逻辑)
│   ├── offscreen/
│   │   ├── offscreen.html (新建)
│   │   └── offscreen.js (新建)
│   └── content/
│       └── scraper/
│           ├── deep-scraper.js (保留旧版)
│           └── deep-scraper-offscreen.js (新建)
```

---

## 🔧 修改清单

### 1. manifest.json

**已完成** ✅

添加了 `offscreen` 权限：

```json
{
  "permissions": [
    "activeTab",
    "storage",
    "scripting",
    "sidePanel",
    "offscreen"  // ← 新增
  ]
}
```

---

### 2. src/offscreen/offscreen.html

**已完成** ✅

创建了 Offscreen Document 的 HTML 页面，包含：
- 一个隐藏的 iframe 用于加载职位详情页
- 引入 offscreen.js 脚本

---

### 3. src/offscreen/offscreen.js

**已完成** ✅

实现了以下功能：
- 监听来自 background 的抓取请求
- 在 iframe 中加载职位详情页
- 等待页面内容渲染完成
- 使用配置的选择器提取数据
- 返回数据给 background

核心流程：
```
[Background] 发送消息 scrapeJobDetail
    ↓
[Offscreen] 接收消息，加载 iframe
    ↓
[Iframe] 加载详情页，执行 JS
    ↓
[Offscreen] 等待内容渲染完成
    ↓
[Offscreen] 提取数据
    ↓
[Background] 返回数据给 Content Script
```

---

### 4. src/background/index.js

**已完成** ✅

新增了以下功能：

#### a) Offscreen Document 管理

```javascript
// 确保 Offscreen Document 已创建（如果不存在则创建）
async function ensureOffscreenDocument()

// 在 Offscreen Document 中抓取职位详情
async function scrapeJobDetailInOffscreen(url, selectors)
```

#### b) 消息处理

新增了以下消息类型的处理：
- `scrapeJobDetailRequest` - 处理详情页抓取请求
- `deepScrapeComplete` - 处理深度采集完成
- `debugLog` - 转发调试日志
- `deepScrapeProgress` - 转发深度采集进度

---

### 5. src/content/scraper/deep-scraper-offscreen.js

**已完成** ✅

创建了新版深度采集类 `DeepScraperOffscreen`，与旧版的主要区别：

```javascript
// 旧版：直接打开新标签页
const newTab = window.open(url, '_blank');

// 新版：通过 background 调用 Offscreen API
const detailData = await this.fetchJobDetailViaOffscreen(job.jobUrl);
```

核心方法：
- `fetchJobDetailViaOffscreen(url)` - 向 background 发送消息请求抓取
- 其他方法与旧版保持一致

---

## 🚀 如何使用

### 方式 1: 在 manifest.json 中切换（推荐）

修改 `manifest.json`，将新版本加入 content_scripts：

```json
"content_scripts": [{
  "matches": ["https://www.zhipin.com/*"],
  "js": [
    "src/content/selector/index.js",
    "src/content/scraper/index.js",
    "src/content/scraper/deep-scraper.js",           // 保留旧版
    "src/content/scraper/deep-scraper-offscreen.js", // 新增新版
    "src/content/index.js"
  ],
  "css": ["src/content/styles/content.css"],
  "run_at": "document_idle"
}]
```

然后在调用时选择使用哪个类：

```javascript
// 使用旧版（window.open 方式）
const scraper = new DeepScraper(jobs, config);

// 使用新版（Offscreen API 方式）
const scraper = new DeepScraperOffscreen(jobs, config);
```

---

### 方式 2: 直接替换旧版

如果确认新版可以正常工作，可以直接替换：

```bash
# 备份旧版
mv src/content/scraper/deep-scraper.js src/content/scraper/deep-scraper-old.js

# 替换为新版
cp src/content/scraper/deep-scraper-offscreen.js src/content/scraper/deep-scraper.js
```

然后将 `deep-scraper.js` 中的类名改为 `DeepScraper`。

---

## 🧪 测试步骤

### 1. 加载扩展

1. 打开 Chrome 扩展管理页面 `chrome://extensions/`
2. 开启"开发者模式"
3. 点击"加载已解压的扩展程序"
4. 选择项目目录

### 2. 测试 Offscreen API

打开 Chrome DevTools 的 Service Worker 控制台：

1. 在扩展管理页面，点击扩展的"Service Worker"链接
2. 在控制台中输入：

```javascript
// 测试创建 Offscreen Document
chrome.offscreen.createDocument({
  url: chrome.runtime.getURL('src/offscreen/offscreen.html'),
  reasons: ['DOM_SCRAPING'],
  justification: '测试'
});

// 检查是否创建成功
chrome.runtime.getContexts({
  contextTypes: ['OFFSCREEN_DOCUMENT']
}).then(contexts => console.log('Offscreen contexts:', contexts));
```

### 3. 测试抓取功能

1. 访问 Boss 直聘职位列表页
2. 打开扩展侧边栏
3. 配置选择器（如果还没配置）
4. 点击"开始采集"进行基础采集
5. 基础采集完成后，点击"深度采集"
6. 观察是否：
   - ✅ 没有打开新标签页
   - ✅ 能正常提取详情数据
   - ✅ 在侧边栏看到进度更新

### 4. 查看日志

在以下三个地方查看日志：

1. **Service Worker 控制台** - 查看 background 日志
   - 应该看到 `[Background] Offscreen document 已创建`
   - 应该看到 `[Background] 发送抓取请求到 Offscreen`

2. **Offscreen Document 控制台** - 查看 offscreen 日志
   - 在 Service Worker 控制台中输入：
     ```javascript
     chrome.runtime.getContexts({
       contextTypes: ['OFFSCREEN_DOCUMENT']
     }).then(contexts => {
       console.log('Offscreen URL:', contexts[0].documentUrl);
     });
     ```
   - 复制 URL 并在新标签页打开，打开 DevTools
   - 应该看到 `[Offscreen] 等待接收抓取任务...`
   - 抓取时应该看到 `[Offscreen] 开始加载: https://...`

3. **Content Script 控制台** - 查看 content 日志
   - 在 Boss 直聘页面打开 DevTools
   - 应该看到 `[Deep Scraper Offscreen] 开始深度采集`

---

## ❗ 常见问题

### Q1: 提示"Cannot create offscreen document"

**原因**: Chrome 版本太低

**解决**: 升级到 Chrome 109+ 版本

---

### Q2: Offscreen 中 iframe 无法加载页面

**原因**: Boss 直聘可能设置了 `X-Frame-Options: DENY`

**解决**: 尝试以下方法：

1. **方法 1**: 检查响应头

```javascript
// 在 offscreen.js 中添加日志
iframe.onerror = (error) => {
  console.error('[Offscreen] iframe 加载失败:', error);
  console.log('[Offscreen] 可能是 X-Frame-Options 限制');
};
```

2. **方法 2**: 使用 webRequest API 拦截并修改响应头

需要在 `manifest.json` 中添加：

```json
{
  "permissions": [
    "webRequest",
    "webRequestBlocking"
  ]
}
```

然后在 `background.js` 中：

```javascript
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const headers = details.responseHeaders.filter(
      h => h.name.toLowerCase() !== 'x-frame-options'
    );
    return { responseHeaders: headers };
  },
  { urls: ["https://www.zhipin.com/*"] },
  ["blocking", "responseHeaders"]
);
```

**注意**: Manifest V3 中 `webRequestBlocking` 已被弃用，建议使用 `declarativeNetRequest` API。

---

### Q3: 提取不到数据

**原因**: 选择器配置不正确，或页面结构变化

**解决**:

1. 在 Offscreen Document 控制台中检查 iframe 的 DOM 结构：

```javascript
// 在 offscreen.js 中添加调试代码
console.log('iframe document:', iframe.contentDocument);
console.log('iframe body:', iframe.contentDocument.body.innerHTML);
```

2. 检查选择器是否正确：

```javascript
// 在提取数据前打印 DOM
Object.entries(selectors).forEach(([field, selector]) => {
  const el = doc.querySelector(selector);
  console.log(`[${field}] ${selector} =>`, el);
});
```

---

### Q4: 性能问题（太慢）

**原因**: 每次都要等待页面完全加载

**优化建议**:

1. **减少等待时间**

```javascript
// 在 offscreen.js 中调整超时时间
const maxWait = 3000; // 从5秒减少到3秒
```

2. **并发抓取** (高级)

创建多个 iframe 同时抓取：

```javascript
// 在 offscreen.html 中创建多个 iframe
<iframe id="scraper-iframe-1"></iframe>
<iframe id="scraper-iframe-2"></iframe>
<iframe id="scraper-iframe-3"></iframe>
```

---

### Q5: 仍然想要可见的调试模式

**解决**: 添加一个开关，让用户选择：

```javascript
// 在配置中添加
const config = {
  useOffscreen: true, // true: Offscreen API, false: window.open
  // ...
};

// 在 deep-scraper 中判断
if (config.useOffscreen) {
  scraper = new DeepScraperOffscreen(jobs, config);
} else {
  scraper = new DeepScraper(jobs, config);
}
```

---

## 📊 性能对比

| 方式 | 用户体验 | 成功率 | 速度 | 反爬能力 |
|------|----------|--------|------|----------|
| window.open | ⭐⭐ 打扰用户 | ⭐⭐⭐ 中等 | ⭐⭐⭐⭐ 较快 | ⭐⭐ 易被检测 |
| Offscreen API | ⭐⭐⭐⭐⭐ 无感知 | ⭐⭐⭐⭐ 较高 | ⭐⭐⭐ 中等 | ⭐⭐⭐⭐ 不易检测 |
| Fetch + DOMParser | ⭐⭐⭐⭐⭐ 无感知 | ⭐⭐ 较低 | ⭐⭐⭐⭐⭐ 最快 | ⭐⭐⭐ 中等 |

---

## 🔜 下一步改进

1. **API 接口分析**
   - 使用 Chrome DevTools 抓包分析 Boss 直聘的数据接口
   - 如果发现可以直接调用 API，则完全不需要渲染页面
   - 速度会大幅提升

2. **智能回退机制**
   - 如果 Offscreen 失败，自动回退到 window.open
   - 如果都失败，尝试 fetch + 解析嵌入 JSON

3. **并发优化**
   - 使用多个 iframe 并发抓取
   - 或者使用队列机制控制并发数

---

## 📞 需要帮助？

如果遇到问题，请：

1. 检查 Chrome 版本是否 >= 109
2. 查看三个地方的控制台日志（Service Worker / Offscreen / Content Script）
3. 确认选择器配置是否正确
4. 测试 Boss 直聘是否允许 iframe 加载（X-Frame-Options）

---

## ✅ 验收标准

以下功能都能正常工作，即表示迁移成功：

- [x] 扩展能正常加载，没有错误
- [ ] 点击"深度采集"后，**不会打开新标签页**
- [ ] 能够成功提取详情页数据（薪资、描述、福利等）
- [ ] 在侧边栏能看到实时进度更新
- [ ] 采集完成后，数据中包含详情页字段
- [ ] 在 Service Worker 控制台看到 Offscreen 相关日志

---

## 📝 总结

通过迁移到 Offscreen API：

1. ✅ **完全后台运行** - 用户体验大幅提升
2. ✅ **官方推荐方案** - 符合 Manifest V3 最佳实践
3. ✅ **绕过反爬检测** - 使用真实浏览器环境
4. ✅ **保持兼容性** - 保留旧版作为备选方案

下一步可以进一步优化：
- 分析 Boss 直聘的 API 接口
- 实现并发抓取
- 添加智能回退机制
