# Boss 直聘静默抓取方案改进分析

## 当前方案问题

### 使用 `window.open()` 的缺陷
```javascript
// 当前代码 (deep-scraper.js:127)
const newTab = window.open(url, '_blank');
```

**问题：**
1. 打开可见标签页，用户体验差
2. 跨域访问限制（第208行报错）
3. 容易被反爬检测
4. 需要等待页面完全加载（15秒超时）

---

## 改进方案对比

### 方案 1: Chrome Offscreen API ⭐⭐⭐⭐⭐

#### 工作原理
```
[Background Worker]
    ↓ chrome.offscreen.createDocument()
[Offscreen Document] (隐藏的 HTML 页面)
    ↓ iframe.src = jobUrl
[Job Detail Page] (在 iframe 中渲染)
    ↓ 执行页面 JS，等待渲染完成
[Extract Data] 提取数据
    ↓ chrome.runtime.sendMessage()
[Background Worker] 返回数据
```

#### 核心代码结构

**1. manifest.json 配置**
```json
{
  "permissions": [
    "offscreen",
    "storage",
    "scripting"
  ],
  "background": {
    "service_worker": "src/background/index.js"
  }
}
```

**2. Offscreen Document (offscreen.html)**
```html
<!DOCTYPE html>
<html>
<head>
  <title>Offscreen Document</title>
</head>
<body>
  <iframe id="scraper-iframe" style="display:none;"></iframe>
  <script src="offscreen.js"></script>
</body>
</html>
```

**3. Offscreen Script (offscreen.js)**
```javascript
// 监听来自 background 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'scrapeJobDetail') {
    scrapeJobDetailInIframe(message.url)
      .then(data => sendResponse({ success: true, data }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // 保持消息通道
  }
});

async function scrapeJobDetailInIframe(url) {
  const iframe = document.getElementById('scraper-iframe');

  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error('页面加载超时'));
    }, 15000);

    iframe.onload = async () => {
      clearTimeout(timeout);

      try {
        // 等待动态内容渲染
        await waitForContent(iframe.contentDocument);

        // 提取数据
        const data = extractDataFromDocument(iframe.contentDocument);
        resolve(data);
      } catch (error) {
        reject(error);
      }
    };

    iframe.onerror = () => {
      clearTimeout(timeout);
      reject(new Error('页面加载失败'));
    };

    iframe.src = url;
  });
}

async function waitForContent(doc) {
  const maxWait = 5000;
  const startTime = Date.now();

  while (Date.now() - startTime < maxWait) {
    // 检查关键元素是否存在
    if (doc.querySelector('.job-detail') || doc.querySelector('.job-primary')) {
      await new Promise(resolve => setTimeout(resolve, 1000)); // 再等1秒
      return true;
    }
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  return false;
}

function extractDataFromDocument(doc) {
  // 与现有的 extractDetailDataFromDocument 逻辑相同
  const data = {};

  // 示例：提取薪资
  const salaryEl = doc.querySelector('.salary');
  if (salaryEl) data.salary = salaryEl.textContent.trim();

  // 提取描述
  const descEl = doc.querySelector('.job-sec .text');
  if (descEl) data.description = descEl.textContent.trim();

  // 提取福利待遇
  const welfareEls = doc.querySelectorAll('.job-tags .tag-list li');
  if (welfareEls.length > 0) {
    data.welfare = Array.from(welfareEls).map(el => el.textContent.trim());
  }

  // HR活跃状态
  const hrActivityEl = doc.querySelector('.boss-active-time');
  if (hrActivityEl) data.hrActivity = hrActivityEl.textContent.trim();

  return data;
}
```

**4. Background Worker 调用**
```javascript
// 创建 offscreen document
async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT']
  });

  if (existingContexts.length > 0) {
    return; // 已存在
  }

  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['DOM_SCRAPING'],
    justification: '需要在后台 iframe 中加载职位详情页并提取数据'
  });
}

// 在 background 中调用
async function scrapeJobDetail(url) {
  await ensureOffscreenDocument();

  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { action: 'scrapeJobDetail', url },
      (response) => {
        if (response.success) {
          resolve(response.data);
        } else {
          reject(new Error(response.error));
        }
      }
    );
  });
}
```

#### 优势详解

1. **完全后台运行** - Offscreen document 不可见，用户无感知
2. **真实浏览器环境** - 可以执行 Boss 直聘的 JavaScript 代码
3. **绕过反爬检测** - 使用真实的浏览器渲染引擎
4. **避免跨域问题** - iframe 加载的页面与扩展同源
5. **官方推荐** - Chrome Manifest V3 官方方案

#### 限制

- ⚠️ 需要 Chrome 109+ 版本
- ⚠️ Offscreen document 有数量限制（通常只能创建1个）
- ⚠️ 需要在 manifest.json 中声明 `offscreen` 权限

---

### 方案 2: 改进请求头 + Fetch ⭐⭐⭐

#### 工作原理
```javascript
async function fetchWithHeaders(url) {
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Referer': 'https://www.zhipin.com/web/geek/job',
      'DNT': '1',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'same-origin',
      'Cache-Control': 'max-age=0'
    },
    credentials: 'include', // 带上 Cookie
    mode: 'cors'
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const html = await response.text();
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');

  return doc;
}
```

#### 问题

- ❌ **无法执行 JavaScript** - DOMParser 只能解析静态 HTML
- ❌ **Boss 直聘使用前端渲染** - 关键数据可能在 JS 中动态加载
- ❌ **反爬检测升级** - 仅靠请求头可能不够

#### 可能的改进

如果 Boss 直聘的数据是通过 API 接口加载的，可以：

1. **抓包分析 API 接口**
```javascript
// 示例：直接调用 Boss 的数据接口
async function fetchJobDetailAPI(jobId) {
  const response = await fetch(`https://www.zhipin.com/wapi/zpgeek/job/detail.json?id=${jobId}`, {
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Referer': `https://www.zhipin.com/job_detail/${jobId}.html`
    },
    credentials: 'include'
  });

  const data = await response.json();
  return data;
}
```

2. **从 HTML 中提取嵌入的 JSON 数据**
```javascript
// 有些网站会在 HTML 中嵌入 JSON
const scriptTags = doc.querySelectorAll('script');
for (const script of scriptTags) {
  const content = script.textContent;
  if (content.includes('__INITIAL_STATE__')) {
    const match = content.match(/window\.__INITIAL_STATE__\s*=\s*({.+?});/);
    if (match) {
      const data = JSON.parse(match[1]);
      return data;
    }
  }
}
```

---

### 方案 3: 使用 iframe 在 Content Script 中 ⭐⭐⭐⭐

#### 工作原理
```javascript
// 在 content script 中创建隐藏 iframe
async function scrapeJobDetailInContentIframe(url) {
  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  iframe.style.position = 'absolute';
  iframe.style.width = '0';
  iframe.style.height = '0';
  document.body.appendChild(iframe);

  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      document.body.removeChild(iframe);
      reject(new Error('加载超时'));
    }, 15000);

    iframe.onload = async () => {
      clearTimeout(timeout);

      try {
        // 等待内容渲染
        await waitForContent(iframe.contentDocument);

        // 提取数据
        const data = extractDataFromDocument(iframe.contentDocument);

        // 清理
        document.body.removeChild(iframe);

        resolve(data);
      } catch (error) {
        document.body.removeChild(iframe);
        reject(error);
      }
    };

    iframe.onerror = () => {
      clearTimeout(timeout);
      document.body.removeChild(iframe);
      reject(new Error('加载失败'));
    };

    iframe.src = url;
  });
}
```

#### 优势
- ✅ 不打开新标签页
- ✅ 可以执行 JavaScript
- ✅ 实现相对简单

#### 限制
- ⚠️ 可能遇到 X-Frame-Options 限制（Boss 直聘可能禁止 iframe）
- ⚠️ 同源策略限制（但扩展有 host_permissions 应该可以绕过）
- ⚠️ 页面可能检测到 iframe 环境并拒绝渲染

---

### 方案 4: 使用 chrome.tabs API 创建隐藏标签页 ⭐⭐

#### 工作原理
```javascript
// 在 background worker 中
async function scrapeJobDetailInHiddenTab(url) {
  // 创建标签页（但不激活）
  const tab = await chrome.tabs.create({
    url: url,
    active: false // 不激活，保持在后台
  });

  return new Promise((resolve, reject) => {
    const timeout = setTimeout(async () => {
      await chrome.tabs.remove(tab.id);
      reject(new Error('超时'));
    }, 15000);

    // 监听标签页加载完成
    chrome.tabs.onUpdated.addListener(async function listener(tabId, changeInfo) {
      if (tabId === tab.id && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        clearTimeout(timeout);

        try {
          // 注入脚本提取数据
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: extractDataFromDocument
          });

          const data = results[0].result;

          // 关闭标签页
          await chrome.tabs.remove(tab.id);

          resolve(data);
        } catch (error) {
          await chrome.tabs.remove(tab.id);
          reject(error);
        }
      }
    });
  });
}
```

#### 问题
- ❌ 仍然会创建可见标签页（即使不激活）
- ❌ 用户可能看到标签栏有新标签出现

---

## 🎯 最终推荐方案

### **首选：Offscreen API + iframe 混合方案**

结合方案 1 和方案 3 的优势：

1. **使用 Offscreen API** 创建后台文档
2. **在 Offscreen 中使用 iframe** 加载详情页
3. **等待 JS 渲染完成** 后提取数据
4. **如果遇到 iframe 限制**，回退到改进的 fetch 方案

### 实现步骤

1. **修改 manifest.json**
   - 添加 `offscreen` 权限
   - 添加 `web_accessible_resources` 配置

2. **创建 offscreen.html 和 offscreen.js**
   - 创建隐藏 iframe
   - 监听 background 消息
   - 加载详情页并提取数据

3. **修改 background/index.js**
   - 添加创建 offscreen document 的逻辑
   - 添加与 offscreen 通信的接口

4. **修改 deep-scraper.js**
   - 移除 `window.open()` 方法
   - 改为向 background 发送消息请求抓取
   - background 转发给 offscreen 处理

### 备选方案

如果 Boss 直聘有强力的 iframe 防护（X-Frame-Options），则：

1. **尝试分析 API 接口** - 使用 Chrome DevTools 抓包
2. **直接调用 Boss 的数据接口** - 绕过页面渲染
3. **如果 API 有签名验证** - 仍然使用 Offscreen API，但改为分析页面中的嵌入 JSON

---

## 📋 实施优先级

1. **立即实施**: Offscreen API 方案（最可靠）
2. **同步调研**: Boss 直聘的 API 接口（可能最简单）
3. **备用方案**: 改进 fetch 请求头 + 解析嵌入 JSON

---

## 🔍 需要进一步调研

1. **Boss 直聘是否允许 iframe 加载？**
   - 检查 `X-Frame-Options` 响应头
   - 测试在 iframe 中能否正常加载

2. **Boss 直聘的数据加载方式？**
   - 是服务端渲染还是客户端渲染？
   - 数据是通过 API 接口加载还是嵌入在 HTML 中？

3. **是否有反爬虫验证？**
   - 是否需要 Cookie/Token？
   - 是否有频率限制？

---

## 代码示例文件清单

需要创建/修改的文件：

```
boss-job-scraper/
├── manifest.json (修改：添加 offscreen 权限)
├── src/
│   ├── background/
│   │   └── index.js (修改：添加 offscreen 管理)
│   ├── offscreen/
│   │   ├── offscreen.html (新建)
│   │   └── offscreen.js (新建)
│   └── content/
│       └── scraper/
│           └── deep-scraper.js (修改：改为消息通信)
```

---

## 总结

**最佳方案**: Offscreen API + iframe
- ✅ 完全后台运行
- ✅ 支持 JS 渲染
- ✅ 官方推荐
- ✅ 最稳定可靠

**次优方案**: API 接口直接调用
- ✅ 最简单
- ✅ 最快速
- ⚠️ 需要逆向分析

**备用方案**: 改进 fetch + 解析嵌入数据
- ⚠️ 可能无法获取动态数据
- ⚠️ 依赖网站实现方式
