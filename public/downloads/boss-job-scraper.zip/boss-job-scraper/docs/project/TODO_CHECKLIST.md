# ✅ Boss 直聘 Offscreen API 迁移 - TODO 清单

## 📋 阶段 1: 立即验证（必须）

### 1.1 验证环境

- [ ] **检查 Chrome 版本**
  ```bash
  # 在地址栏输入
  chrome://version/
  # 确认版本 >= 109
  ```

- [ ] **检查文件是否已创建**
  ```bash
  ls -la src/offscreen/
  # 应该看到: offscreen.html, offscreen.js

  ls -la src/content/scraper/deep-scraper-offscreen.js
  # 应该存在
  ```

- [ ] **检查 manifest.json**
  ```bash
  grep -A 5 '"permissions"' manifest.json
  # 应该包含 "offscreen"
  ```

---

### 1.2 测试 Offscreen API

- [ ] **加载扩展**
  1. 打开 `chrome://extensions/`
  2. 开启"开发者模式"
  3. 点击"加载已解压的扩展程序"
  4. 选择项目目录
  5. 确认无错误

- [ ] **测试创建 Offscreen Document**
  ```javascript
  // 在 Service Worker 控制台执行
  chrome.offscreen.createDocument({
    url: chrome.runtime.getURL('src/offscreen/offscreen.html'),
    reasons: ['DOM_SCRAPING'],
    justification: '测试'
  }).then(() => console.log('✅ Offscreen API 可用'))
    .catch(err => console.error('❌ 创建失败:', err));
  ```

- [ ] **验证 Offscreen Document 已创建**
  ```javascript
  // 在 Service Worker 控制台执行
  chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT']
  }).then(contexts => {
    if (contexts.length > 0) {
      console.log('✅ Offscreen Document 已创建:', contexts[0].documentUrl);
    } else {
      console.log('❌ Offscreen Document 未创建');
    }
  });
  ```

---

### 1.3 首次测试抓取

- [ ] **访问 Boss 直聘职位列表页**
  - 例如: `https://www.zhipin.com/web/geek/job`

- [ ] **打开扩展侧边栏**
  - 点击扩展图标

- [ ] **进行基础采集**
  - 确保选择器已配置
  - 点击"开始采集"
  - 等待完成

- [ ] **测试深度采集（关键）**
  - 点击"深度采集"按钮
  - **观察是否打开新标签页** ⭐⭐⭐
    - ✅ 如果没有打开新标签页 → 成功！
    - ❌ 如果打开了新标签页 → 检查是否使用了新版深度采集类

---

### 1.4 检查日志输出

- [ ] **Service Worker 日志**
  ```
  应该看到:
  [Background] Offscreen document 已创建
  [Background] 发送抓取请求到 Offscreen: https://...
  [Background] Offscreen 抓取成功: {...}
  ```

- [ ] **Offscreen Document 日志**
  ```javascript
  // 先获取 Offscreen URL
  chrome.runtime.getContexts({contextTypes: ['OFFSCREEN_DOCUMENT']})
    .then(c => console.log(c[0].documentUrl));

  // 复制 URL，在新标签页打开，打开 DevTools
  // 应该看到:
  [Offscreen] Offscreen document 已加载
  [Offscreen] 等待接收抓取任务...
  [Offscreen] 收到消息: scrapeJobDetail
  [Offscreen] 开始加载: https://...
  [Offscreen] iframe 加载完成
  [Offscreen] 提取完成，数据: {...}
  ```

- [ ] **Content Script 日志**
  ```
  // 在 Boss 直聘页面的 DevTools 控制台
  应该看到:
  [Deep Scraper Offscreen] 开始深度采集，总数: X
  [Deep Scraper Offscreen] 访问详情页: https://...
  [Deep Scraper Offscreen] 深度采集完成
  ```

---

## 📋 阶段 2: 问题排查（如果阶段 1 失败）

### 2.1 无法创建 Offscreen Document

**问题**: `Cannot create offscreen document`

- [ ] **检查 Chrome 版本**
  - 必须 >= 109
  - 升级 Chrome

- [ ] **检查文件路径**
  ```bash
  ls -la src/offscreen/offscreen.html
  # 确认文件存在
  ```

- [ ] **检查 manifest.json**
  ```bash
  grep "offscreen" manifest.json
  # 确认有 offscreen 权限
  ```

---

### 2.2 仍然打开新标签页

**问题**: 深度采集时还是打开了新标签页

- [ ] **检查是否使用了新版深度采集类**
  ```javascript
  // 搜索调用代码，应该是：
  const scraper = new DeepScraperOffscreen(jobs, config);

  // 而不是：
  const scraper = new DeepScraper(jobs, config);
  ```

- [ ] **检查 manifest.json 是否加载了新版文件**
  ```json
  "content_scripts": [{
    "js": [
      "src/content/scraper/deep-scraper-offscreen.js",  // ← 应该包含
      // ...
    ]
  }]
  ```

- [ ] **检查是否有多个深度采集实例**
  - 搜索代码中的 `new DeepScraper`
  - 确保都改为 `new DeepScraperOffscreen`

---

### 2.3 Offscreen 无响应

**问题**: 发送消息后没有响应

- [ ] **检查 Offscreen Document 是否已创建**
  ```javascript
  chrome.runtime.getContexts({contextTypes: ['OFFSCREEN_DOCUMENT']})
    .then(c => console.log('Contexts:', c));
  ```

- [ ] **检查 offscreen.js 是否有错误**
  - 打开 Offscreen Document 控制台（见上文）
  - 查看是否有报错

- [ ] **检查消息格式是否正确**
  ```javascript
  // 应该是：
  {
    action: 'scrapeJobDetailRequest',
    url: '...',
    selectors: {...}
  }
  ```

---

### 2.4 iframe 加载失败

**问题**: `Refused to display ... in a frame`

- [ ] **确认 Boss 直聘是否设置了 X-Frame-Options**
  ```javascript
  // 在 Offscreen 控制台查看错误信息
  // 如果看到 X-Frame-Options 相关错误，说明被阻止了
  ```

- [ ] **尝试使用 declarativeNetRequest 移除响应头**
  - 见 [迁移指南 Q2](./MIGRATION_GUIDE.md#q2-offscreen-中-iframe-无法加载页面x-frame-options)

- [ ] **备选方案：回退到 API 直调或 window.open**

---

### 2.5 提取不到数据

**问题**: 抓取成功，但数据为空

- [ ] **检查选择器配置**
  ```javascript
  // 在 Offscreen 控制台
  console.log('配置的选择器:', selectors);
  console.log('DOM 结构:', iframe.contentDocument.body.innerHTML);
  ```

- [ ] **检查页面是否完全渲染**
  ```javascript
  // 增加等待时间
  const maxWait = 5000; // 默认值，可以增加
  ```

- [ ] **检查是否有验证逻辑拒绝了数据**
  - 查看 AI 验证或正则验证的日志
  - 临时关闭验证进行测试

---

## 📋 阶段 3: 性能优化（可选）

### 3.1 分析 Boss 直聘 API

- [ ] **打开 Boss 直聘详情页**

- [ ] **打开 Chrome DevTools → Network → Fetch/XHR**

- [ ] **刷新页面，查找 API 请求**
  - 查找包含 `/api/`, `/wapi/`, `/json/` 的请求
  - 查看响应数据是否包含职位信息

- [ ] **记录 API 接口信息**
  ```
  URL: _______________
  参数: _______________
  需要 Cookie: 是 / 否
  需要签名: 是 / 否
  ```

---

### 3.2 实现 API 直调方式

- [ ] **创建 `src/content/scraper/boss-api.js`**
  - 见 [API 分析指南](./API_ANALYSIS_GUIDE.md)

- [ ] **实现 `extractJobId(url)` 方法**
  - 从 URL 中提取 jobId

- [ ] **实现 `fetchJobDetail(jobId)` 方法**
  - 调用 Boss 直聘 API

- [ ] **测试 API 调用是否成功**
  ```javascript
  BossAPI.getJobDetail('https://www.zhipin.com/job_detail/xxx.html')
    .then(data => console.log('API 返回数据:', data));
  ```

---

### 3.3 实现混合方案

- [ ] **修改深度采集逻辑**
  ```javascript
  // 优先 API，失败回退到 Offscreen
  async scrapeJobDetail(job) {
    // 1. 尝试 API
    let data = await BossAPI.getJobDetail(job.jobUrl);

    // 2. 失败时回退到 Offscreen
    if (!data) {
      data = await this.fetchJobDetailViaOffscreen(job.jobUrl);
    }

    // 3. 最后回退到 window.open
    if (!data) {
      data = await this.fetchJobDetailInNewTab(job.jobUrl);
    }

    return data;
  }
  ```

- [ ] **测试混合方案**
  - 验证优先使用 API
  - 验证 API 失败时回退到 Offscreen
  - 查看日志中的 method 字段（API / Offscreen / NewTab）

---

### 3.4 性能调优

- [ ] **调整延迟参数**
  ```javascript
  config = {
    detailDelay: 1500,  // 从 2000 减少到 1500
    randomDelay: true   // 启用随机延迟
  };
  ```

- [ ] **调整等待时间**
  ```javascript
  // 在 offscreen.js 中
  const maxWait = 3000; // 从 5000 减少到 3000
  ```

- [ ] **性能测试**
  - 记录平均每个职位的抓取时间
  - 记录成功率
  - 对比不同方案的性能

---

## 📋 阶段 4: 最终验收（必须）

### 4.1 功能验收

- [ ] **基础功能**
  - [ ] 扩展能正常加载，无错误
  - [ ] 能进行基础采集
  - [ ] 能进行深度采集

- [ ] **核心改进 ⭐⭐⭐**
  - [ ] **深度采集不会打开新标签页**
  - [ ] 完全后台运行，用户无感知

- [ ] **数据准确性**
  - [ ] 能成功提取详情页数据（薪资、描述、福利等）
  - [ ] 数据字段完整
  - [ ] 数据内容正确

- [ ] **用户体验**
  - [ ] 侧边栏有实时进度显示
  - [ ] 有调试日志输出
  - [ ] 采集完成有提示

---

### 4.2 性能验收

- [ ] **速度要求**
  - [ ] 平均每个职位抓取时间 <= 3秒（Offscreen 方式）
  - [ ] 平均每个职位抓取时间 <= 1秒（API 方式）

- [ ] **成功率要求**
  - [ ] 成功率 >= 90%

- [ ] **稳定性要求**
  - [ ] 连续抓取 50 个职位无崩溃
  - [ ] 无内存泄漏

---

### 4.3 日志验收

- [ ] **Service Worker 日志**
  - [ ] 有 Offscreen 创建日志
  - [ ] 有抓取请求日志
  - [ ] 有抓取结果日志

- [ ] **Offscreen Document 日志**
  - [ ] 有初始化日志
  - [ ] 有 iframe 加载日志
  - [ ] 有数据提取日志

- [ ] **Content Script 日志**
  - [ ] 有深度采集开始日志
  - [ ] 有进度日志
  - [ ] 有完成日志

---

## 📊 进度追踪

### 当前状态

- [x] 代码已实现
- [x] 文档已完成
- [ ] 功能测试
- [ ] 性能测试
- [ ] 最终验收

### 完成情况

- **阶段 1**: ⬜ 0/4 完成
- **阶段 2**: ⬜ 待定（如果阶段 1 失败）
- **阶段 3**: ⬜ 0/4 完成（可选）
- **阶段 4**: ⬜ 0/3 完成

### 预计时间

- **阶段 1**: 30 分钟
- **阶段 2**: 1 小时（如果需要）
- **阶段 3**: 2 小时（可选）
- **阶段 4**: 30 分钟

**总计**: 约 1-4 小时（取决于是否遇到问题和是否进行性能优化）

---

## 📞 需要帮助？

遇到问题时，按以下顺序查找：

1. **查看本 TODO 清单的"问题排查"章节**
2. **查看 [快速参考 - 故障排除](./QUICK_REFERENCE.md#🔧-故障排除速查)**
3. **查看 [迁移指南 - 常见问题](./MIGRATION_GUIDE.md#❗-常见问题)**
4. **查看三个控制台的日志输出**

---

## ✅ 完成标志

当以下所有项目都完成时，表示迁移成功：

- ✅ Chrome 版本 >= 109
- ✅ 所有新文件已创建
- ✅ manifest.json 已正确配置
- ✅ Offscreen Document 能成功创建
- ✅ **深度采集不打开新标签页** ⭐⭐⭐
- ✅ 能成功提取详情数据
- ✅ 日志输出正确
- ✅ 成功率 >= 90%

---

**开始你的迁移之旅吧！🚀**

记得按照阶段顺序逐步完成，遇到问题及时查看文档。
