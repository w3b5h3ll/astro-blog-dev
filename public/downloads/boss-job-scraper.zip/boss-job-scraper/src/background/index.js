// Background Service Worker
console.log('[Boss Scraper] Background service worker 已加载');

// ===========================
// Offscreen Document 管理
// ===========================

/**
 * 确保 Offscreen Document 已创建
 * @returns {Promise<void>}
 */
async function ensureOffscreenDocument() {
  // 检查是否已存在 offscreen document
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT']
  });

  if (existingContexts.length > 0) {
    console.log('[Background] Offscreen document 已存在');
    return;
  }

  // 创建新的 offscreen document
  try {
    await chrome.offscreen.createDocument({
      url: chrome.runtime.getURL('src/offscreen/offscreen.html'),
      reasons: ['DOM_SCRAPING'],
      justification: '需要在后台 iframe 中加载职位详情页并提取数据，避免打开可见的新标签页'
    });
    console.log('[Background] Offscreen document 已创建');
  } catch (error) {
    console.error('[Background] 创建 Offscreen document 失败:', error);
    throw error;
  }
}

/**
 * 在 Offscreen Document 中抓取职位详情
 * @param {string} url - 职位详情页 URL
 * @param {object} selectors - 字段选择器配置
 * @returns {Promise<object>} 提取的数据
 */
async function scrapeJobDetailInOffscreen(url, selectors) {
  // 确保 offscreen document 已创建
  await ensureOffscreenDocument();

  console.log('[Background] 发送抓取请求到 Offscreen:', url);

  // 向 offscreen document 发送消息
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      {
        action: 'scrapeJobDetail',
        url: url,
        selectors: selectors
      },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error('[Background] 通信失败:', chrome.runtime.lastError);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        if (!response) {
          reject(new Error('Offscreen document 无响应'));
          return;
        }

        if (response.success) {
          console.log('[Background] Offscreen 抓取成功:', response.data);
          resolve(response.data);
        } else {
          console.error('[Background] Offscreen 抓取失败:', response.error);
          reject(new Error(response.error));
        }
      }
    );
  });
}

// ===========================
// 扩展生命周期
// ===========================

// 监听扩展安装事件
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[Boss Scraper] 扩展已安装/更新:', details.reason);

  if (details.reason === 'install') {
    // 首次安装，初始化存储
    chrome.storage.local.set({
      selectedSelector: null,
      scrapedJobs: [],
      config: {
        autoDedupe: true,
        scrollDelay: 1000
      }
    });

    // 打开欢迎页面（可选）
    // chrome.tabs.create({ url: 'https://www.zhipin.com' });
  }
});

// 监听扩展图标点击事件，打开侧边栏
chrome.action.onClicked.addListener(async (tab) => {
  // 打开侧边栏
  await chrome.sidePanel.open({ windowId: tab.windowId });
});

// 监听来自 content script 和 popup 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Background] 收到消息:', message.action, 'from:', sender.tab ? 'content' : 'popup');

  switch (message.action) {
    case 'selectorConfirmed':
      handleSelectorConfirmed(message, sender);
      break;

    case 'selectorCancelled':
      handleSelectorCancelled(sender);
      break;

    case 'updateProgress':
      forwardToPopup(message);
      break;

    case 'scrapingComplete':
      handleScrapingComplete(message);
      break;

    case 'scrapingError':
      forwardToPopup(message);
      break;

    case 'scrapeJobDetailRequest':
      // 新增：处理详情页抓取请求
      handleScrapeJobDetailRequest(message, sendResponse);
      return true; // 保持消息通道开放（异步响应）

    case 'debugLog':
      // 转发调试日志到 popup
      forwardToPopup(message);
      break;

    case 'deepScrapeProgress':
      // 转发深度采集进度
      forwardToPopup(message);
      break;

    case 'deepScrapeComplete':
      // 转发深度采集完成消息
      handleDeepScrapeComplete(message);
      break;

    case 'deepScrapeError':
      // 转发深度采集错误
      forwardToPopup(message);
      break;
  }

  return true; // 保持消息通道开放
});

// 处理详情页抓取请求
async function handleScrapeJobDetailRequest(message, sendResponse) {
  console.log('[Background] 处理详情页抓取请求:', message.url);

  try {
    const data = await scrapeJobDetailInOffscreen(message.url, message.selectors);

    sendResponse({
      success: true,
      data: data
    });

  } catch (error) {
    console.error('[Background] 详情页抓取失败:', error);

    sendResponse({
      success: false,
      error: error.message
    });
  }
}

// 处理深度采集完成
function handleDeepScrapeComplete(message) {
  console.log('[Background] 深度采集完成，更新存储');

  // 更新存储中的数据
  chrome.storage.local.set({
    scrapedJobs: message.jobs,
    lastDeepScrapeAt: new Date().toISOString()
  });

  // 转发到 popup
  forwardToPopup(message);

  // 显示通知
  showNotification(
    '深度采集完成',
    `成功: ${message.successCount}，失败: ${message.failCount}`
  );
}

// 处理选择器确认
function handleSelectorConfirmed(message, sender) {
  console.log('[Background] 保存选择器:', message.selector);

  // 保存到存储
  chrome.storage.local.set({
    selectedSelector: message.selector
  });

  // 转发到 popup（如果打开）
  forwardToPopup(message);
}

// 处理选择器取消
function handleSelectorCancelled(sender) {
  console.log('[Background] 选择器已取消');
  forwardToPopup({ action: 'selectorCancelled' });
}

// 处理采集完成
function handleScrapingComplete(message) {
  console.log('[Background] 采集完成，保存数据:', message.count, '条');

  // 保存数据到存储
  chrome.storage.local.set({
    scrapedJobs: message.jobs,
    lastScrapedAt: new Date().toISOString()
  });

  // 转发到 popup
  forwardToPopup(message);

  // 显示通知
  showNotification('采集完成', `成功采集 ${message.count} 条职位信息`);
}

// 转发消息到 popup
function forwardToPopup(message) {
  chrome.runtime.sendMessage(message).catch(err => {
    // Popup 可能未打开，忽略错误
    console.log('[Background] Popup 未打开，消息未转发');
  });
}

// 显示系统通知
function showNotification(title, message) {
  // Chrome Extensions 不再需要 notifications 权限即可显示基础通知
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: title,
      message: message,
      priority: 2
    }).catch(err => {
      console.log('[Background] 通知权限未授予或不支持');
    });
  } catch (error) {
    console.log('[Background] 通知功能不可用');
  }
}

// 监听存储变化（用于调试）
chrome.storage.onChanged.addListener((changes, areaName) => {
  console.log('[Background] 存储已更新:', Object.keys(changes));
});
