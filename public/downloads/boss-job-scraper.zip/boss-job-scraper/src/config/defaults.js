// 默认配置

export const DEFAULT_CONFIG = {
  // 采集配置
  autoDedupe: true,           // 自动去重
  scrollDelay: 1000,          // 滚动延迟(ms)
  randomDelay: true,          // 随机延迟
  detailDelay: 2000,          // 详情页延迟(ms)

  // 限制配置
  enableLimit: false,         // 启用数量限制
  limitNumber: 10,           // 限制数量

  // 验证配置
  enableAIValidation: true,   // 启用AI验证
  enableBasicValidation: false, // 启用基础验证

  // UI配置
  showDebugPanel: false,      // 显示调试面板
  autoHideProgress: true,     // 自动隐藏进度条
  progressHideDelay: 3000    // 进度条隐藏延迟(ms)
};

// 字段配置
export const FIELD_CONFIG = {
  // 详情页字段
  detailFields: [
    { key: 'salary', name: '薪资范围', required: false },
    { key: 'description', name: '职位描述', required: false },
    { key: 'welfare', name: '福利待遇', required: false },
    { key: 'hrActivity', name: 'HR活跃状态', required: false },
    { key: 'companySize', name: '公司规模', required: false },
    { key: 'industry', name: '所属行业', required: false }
  ],

  // 列表页字段
  listFields: [
    { key: 'title', name: '职位名称', required: true },
    { key: 'company', name: '公司名称', required: true },
    { key: 'salary', name: '薪资范围', required: false },
    { key: 'location', name: '工作地点', required: false },
    { key: 'experience', name: '工作经验', required: false },
    { key: 'education', name: '学历要求', required: false }
  ]
};
