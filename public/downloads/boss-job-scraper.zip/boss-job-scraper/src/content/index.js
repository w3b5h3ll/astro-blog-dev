// Content Script 主入口
(function() {
  'use strict';

  console.log('[Boss Scraper] Content script 已加载');

  let elementSelector = null;
  let jobScraper = null;
  let deepScraper = null;
  let currentSelector = null;

  // 初始化
  function init() {
    elementSelector = new window.BossElementSelector();
  }

  // 监听来自 popup 的消息
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[Boss Scraper] 收到消息:', message.action);

    switch (message.action) {
      case 'activateSelector':
        handleActivateSelector();
        sendResponse({ success: true });
        break;

      case 'startScraping':
        handleStartScraping(message.config);
        sendResponse({ success: true });
        break;

      case 'stopScraping':
        handleStopScraping();
        sendResponse({ success: true });
        break;

      case 'startDeepScraping':
        handleStartDeepScraping(message.config);
        sendResponse({ success: true });
        break;

      case 'pauseDeepScraping':
        handlePauseDeepScraping();
        sendResponse({ success: true });
        break;

      case 'resumeDeepScraping':
        handleResumeDeepScraping();
        sendResponse({ success: true });
        break;

      case 'configureDetailField':
        handleConfigureDetailField(message.field, message.fieldName);
        sendResponse({ success: true });
        break;

      case 'configureListField':
        handleConfigureListField(message.field, message.fieldName);
        sendResponse({ success: true });
        break;

      case 'testDetailConfig':
        handleTestDetailConfig(message.selectors);
        sendResponse({ success: true });
        break;

      case 'testListConfig':
        handleTestListConfig(message.selectors, message.listSelector);
        sendResponse({ success: true });
        break;

      case 'ping':
        sendResponse({ success: true });
        break;

      default:
        sendResponse({ success: false, error: '未知操作' });
    }

    return true; // 保持消息通道开放
  });

  // 处理激活选择器
  function handleActivateSelector() {
    console.log('[Boss Scraper] 激活元素选择器');
    elementSelector.activate();
  }

  // 处理开始采集
  function handleStartScraping(config) {
    console.log('[Boss Scraper] 开始采集，配置:', config);

    // 从存储中获取选择器
    chrome.storage.local.get(['selectedSelector'], (result) => {
      if (!result.selectedSelector) {
        chrome.runtime.sendMessage({
          action: 'scrapingError',
          error: '未找到选择器配置'
        });
        return;
      }

      currentSelector = result.selectedSelector;
      console.log('[Boss Scraper] 使用选择器:', currentSelector);

      // 创建采集器并开始采集
      jobScraper = new window.BossJobScraper(currentSelector, config);
      jobScraper.start();
    });
  }

  // 处理停止采集
  function handleStopScraping() {
    console.log('[Boss Scraper] 停止采集');

    if (jobScraper) {
      jobScraper.stop();
    } else {
      console.warn('[Boss Scraper] 没有正在运行的采集任务');
      chrome.runtime.sendMessage({
        action: 'scrapingStopped',
        jobs: [],
        count: 0,
        progress: 0
      });
    }
  }

  // 处理开始深度采集
  function handleStartDeepScraping(config) {
    console.log('[Boss Scraper] 开始深度采集（真实标签页模式），配置:', config);

    if (!config.jobs || config.jobs.length === 0) {
      chrome.runtime.sendMessage({
        action: 'deepScrapeError',
        error: '没有可深度采集的职位'
      });
      return;
    }

    // 使用稳定的真实标签页方案（window.open）
    deepScraper = new window.DeepScraper(config.jobs, config);
    deepScraper.start();
  }

  // 处理暂停深度采集
  function handlePauseDeepScraping() {
    console.log('[Boss Scraper] 暂停深度采集');

    if (deepScraper) {
      deepScraper.pause();
    }
  }

  // 处理继续深度采集
  function handleResumeDeepScraping() {
    console.log('[Boss Scraper] 继续深度采集');

    if (deepScraper) {
      deepScraper.resume();
    }
  }

  // 处理配置详情页字段
  function handleConfigureDetailField(field, fieldName) {
    console.log('[Boss Scraper] 配置字段:', field, fieldName);

    if (!elementSelector) {
      elementSelector = new window.BossElementSelector();
    }

    // 激活选择器，并传入字段信息
    elementSelector.activateForDetailField(field, fieldName);
  }

  // 处理配置列表页字段
  function handleConfigureListField(field, fieldName) {
    console.log('[Boss Scraper] 配置列表字段:', field, fieldName);

    if (!elementSelector) {
      elementSelector = new window.BossElementSelector();
    }

    // 激活选择器，并传入字段信息
    elementSelector.activateForListField(field, fieldName);
  }

  // 处理测试详情页配置
  function handleTestDetailConfig(selectors) {
    console.log('[Boss Scraper] 测试配置:', selectors);

    const results = {};

    Object.entries(selectors).forEach(([field, selector]) => {
      try {
        const element = document.querySelector(selector);
        if (element) {
          // 如果是列表类型（福利待遇）
          if (field === 'welfare') {
            const items = element.querySelectorAll('*');
            results[field] = Array.from(items).map(el => el.textContent.trim()).filter(t => t.length > 0 && t.length < 50);
          } else {
            results[field] = element.textContent.trim();
          }
        } else {
          results[field] = '';
        }
      } catch (error) {
        console.error('[Boss Scraper] 测试提取失败:', field, error);
        results[field] = '';
      }
    });

    // 发送测试结果
    chrome.runtime.sendMessage({
      action: 'testConfigResult',
      results: results
    });
  }

  // 处理测试列表页配置
  function handleTestListConfig(selectors, listSelector) {
    console.log('[Boss Scraper] 测试列表配置:', selectors, listSelector);

    const results = {};

    // 找到列表容器
    const container = document.querySelector(listSelector);
    if (!container) {
      console.error('[Boss Scraper] 未找到列表容器');
      chrome.runtime.sendMessage({
        action: 'testListConfigResult',
        results: {}
      });
      return;
    }

    // 找到第一个职位卡片
    const jobCard = container.children[0];
    if (!jobCard) {
      console.error('[Boss Scraper] 列表容器中没有职位卡片');
      chrome.runtime.sendMessage({
        action: 'testListConfigResult',
        results: {}
      });
      return;
    }

    // 在第一个职位卡片中测试选择器
    Object.entries(selectors).forEach(([field, selector]) => {
      try {
        const element = jobCard.querySelector(selector);
        if (element) {
          results[field] = element.textContent.trim();
        } else {
          results[field] = '';
        }
      } catch (error) {
        console.error('[Boss Scraper] 测试列表字段提取失败:', field, error);
        results[field] = '';
      }
    });

    // 发送测试结果
    chrome.runtime.sendMessage({
      action: 'testListConfigResult',
      results: results
    });
  }

  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
