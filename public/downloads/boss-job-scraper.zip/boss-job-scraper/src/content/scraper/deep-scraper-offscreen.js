// 深度采集类 - 使用 Offscreen API 在后台抓取职位详情页
class DeepScraperOffscreen {
  constructor(jobs, config = {}) {
    this.jobs = jobs; // 基础采集的职位列表
    this.config = config;
    this.currentIndex = 0;
    this.successCount = 0;
    this.failCount = 0;
    this.paused = false;
    this.stopped = false;
    this.detailSelectors = config.detailSelectors || {}; // 详情页字段选择器
    this.enableAIValidation = config.enableAIValidation !== false; // 默认启用 AI 验证
    this.enableBasicValidation = config.enableBasicValidation || false; // 默认关闭基础验证
  }

  // 开始深度采集
  async start() {
    console.log('[Deep Scraper Offscreen] 开始深度采集，总数:', this.jobs.length);
    this.sendDebugLog('info', `开始深度采集 ${this.jobs.length} 个职位 (Offscreen 模式)`);

    this.currentIndex = 0;
    this.successCount = 0;
    this.failCount = 0;
    this.paused = false;
    this.stopped = false;

    try {
      for (let i = 0; i < this.jobs.length; i++) {
        // 检查是否停止
        if (this.stopped) {
          console.log('[Deep Scraper Offscreen] 用户停止了深度采集');
          break;
        }

        // 检查是否暂停
        while (this.paused && !this.stopped) {
          await this.sleep(500);
        }

        if (this.stopped) break;

        this.currentIndex = i;
        const job = this.jobs[i];

        // 访问详情页并提取
        const success = await this.scrapeJobDetail(job);

        if (success) {
          this.successCount++;
        } else {
          this.failCount++;
        }

        // 延迟（防止被检测）
        if (i < this.jobs.length - 1) {
          await this.delayWithRandom();
        }
      }

      // 发送完成消息
      chrome.runtime.sendMessage({
        action: 'deepScrapeComplete',
        jobs: this.jobs,
        count: this.jobs.length,
        successCount: this.successCount,
        failCount: this.failCount
      });

      console.log('[Deep Scraper Offscreen] 深度采集完成，成功:', this.successCount, '失败:', this.failCount);

    } catch (error) {
      console.error('[Deep Scraper Offscreen] 深度采集失败:', error);
      chrome.runtime.sendMessage({
        action: 'deepScrapeError',
        error: error.message
      });
    }
  }

  // 采集单个职位详情
  async scrapeJobDetail(job) {
    try {
      if (!job.jobUrl) {
        console.warn('[Deep Scraper Offscreen] 职位没有链接:', job.title);
        this.sendDebugLog('warning', `跳过 ${job.title}：无链接`);
        return false;
      }

      console.log('[Deep Scraper Offscreen] 访问详情页:', job.jobUrl);

      // 发送开始采集的进度（显示当前正在采集的职位）
      this.sendProgress(this.currentIndex + 1, this.jobs.length, job, null);

      // 通过 background worker 使用 Offscreen API 抓取
      const detailData = await this.fetchJobDetailViaOffscreen(job.jobUrl);

      if (detailData) {
        // 更新职位数据（只更新详情页特有的字段，不覆盖列表页的字段）
        if (detailData.salary) job.salary = detailData.salary;
        if (detailData.description) job.description = detailData.description;
        if (detailData.welfare) job.welfare = detailData.welfare;
        if (detailData.hrActivity) job.hrActivity = detailData.hrActivity;
        if (detailData.companySize) job.companySize = detailData.companySize;
        if (detailData.industry) job.industry = detailData.industry;

        // AI 验证（如果启用）
        if (this.enableAIValidation && (detailData.companySize || detailData.industry)) {
          // 验证公司规模
          if (detailData.companySize) {
            const validatedSize = await this.validateWithAI('companySize', detailData.companySize);
            if (validatedSize) {
              job.companySize = validatedSize;
            } else {
              console.warn('[Deep Scraper Offscreen] AI验证失败，公司规模字段已忽略');
              this.sendDebugLog('warning', `AI验证: companySize 不合理 - "${detailData.companySize}"`);
              delete job.companySize;
            }
          }

          // 验证所属行业
          if (detailData.industry) {
            const validatedIndustry = await this.validateWithAI('industry', detailData.industry);
            if (validatedIndustry) {
              job.industry = validatedIndustry;
            } else {
              console.warn('[Deep Scraper Offscreen] AI验证失败，所属行业字段已忽略');
              this.sendDebugLog('warning', `AI验证: industry 不合理 - "${detailData.industry}"`);
              delete job.industry;
            }
          }
        }

        const hrActivity = detailData.hrActivity || '未知';
        this.sendDebugLog('success', `✓ ${job.title} - 活跃: ${hrActivity}`);
        return true;
      } else {
        this.sendDebugLog('error', `✗ ${job.title} - 提取失败`);
        return false;
      }

    } catch (error) {
      console.error('[Deep Scraper Offscreen] 提取详情失败:', error);
      this.sendDebugLog('error', `✗ ${job.title} - ${error.message}`);
      return false;
    }
  }

  // 通过 Offscreen API 获取职位详情（带重试）
  async fetchJobDetailViaOffscreen(url) {
    const maxRetries = 2; // 最多重试 2 次
    let lastError = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        if (attempt > 0) {
          console.log(`[Deep Scraper Offscreen] 重试第 ${attempt} 次...`);
          // 重试前等待更长时间
          await this.sleep(3000 + Math.random() * 2000);
        }

        const data = await new Promise((resolve, reject) => {
          // 向 background worker 发送消息，请求抓取详情
          chrome.runtime.sendMessage(
            {
              action: 'scrapeJobDetailRequest',
              url: url,
              selectors: this.detailSelectors
            },
            (response) => {
              if (chrome.runtime.lastError) {
                console.error('[Deep Scraper Offscreen] 通信失败:', chrome.runtime.lastError);
                reject(new Error(chrome.runtime.lastError.message));
                return;
              }

              if (!response) {
                reject(new Error('Background worker 无响应'));
                return;
              }

              if (response.success) {
                resolve(response.data);
              } else {
                reject(new Error(response.error));
              }
            }
          );
        });

        // 成功获取数据
        if (attempt > 0) {
          this.sendDebugLog('success', `重试成功 (第 ${attempt} 次)`);
        }
        return data;

      } catch (error) {
        lastError = error;
        console.warn(`[Deep Scraper Offscreen] 尝试 ${attempt + 1} 失败:`, error.message);

        if (attempt === maxRetries) {
          // 所有重试都失败了
          this.sendDebugLog('error', `Offscreen 抓取失败（已重试 ${maxRetries} 次）: ${error.message}`);
          throw lastError;
        }
      }
    }

    throw lastError;
  }

  // 使用 AI 验证字段值
  async validateWithAI(field, value) {
    try {
      // 构建验证提示词（针对不同字段）
      let prompt = '';

      if (field === 'companySize') {
        prompt = `请判断以下文本是否是"公司规模"信息。公司规模通常是人数范围，如"100-500人"、"1000人以上"、"少于50人"等。
如果是公司规模信息，请直接返回原文。
如果不是公司规模信息（比如融资信息、行业信息等），请只返回"INVALID"。

文本：${value}

回答：`;
      } else if (field === 'industry') {
        prompt = `请判断以下文本是否是"所属行业"信息。所属行业通常是行业类别，如"互联网"、"电子商务"、"金融科技"、"企业服务"、"教育培训"等。
如果是所属行业信息，请直接返回原文。
如果不是所属行业信息（比如融资信息、公司规模等），请只返回"INVALID"。

文本：${value}

回答：`;
      } else {
        // 其他字段暂不支持AI验证
        return value;
      }

      // 调用本地 Copilot API
      const response = await fetch('http://localhost:4141/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.1,
          max_tokens: 100
        })
      });

      if (!response.ok) {
        console.warn('[Deep Scraper Offscreen] AI API 调用失败，跳过验证');
        return value; // 失败时返回原值
      }

      const result = await response.json();
      const answer = result.choices?.[0]?.message?.content?.trim();

      if (!answer) {
        console.warn('[Deep Scraper Offscreen] AI 返回空结果');
        return value;
      }

      // 如果 AI 返回 INVALID，则拒绝该值
      if (answer === 'INVALID' || answer.includes('INVALID')) {
        console.log(`[Deep Scraper Offscreen] AI 判断 ${field} 不合理: "${value}"`);
        return null;
      }

      // AI 认为合理，返回原值（或 AI 清洗后的值）
      console.log(`[Deep Scraper Offscreen] AI 验证通过 ${field}: "${value}"`);
      this.sendDebugLog('success', `AI验证✓ ${field}: "${value}"`);
      return answer;

    } catch (error) {
      console.error('[Deep Scraper Offscreen] AI 验证出错:', error);
      // AI 验证失败，返回原值
      return value;
    }
  }

  // 延迟（带随机）
  async delayWithRandom() {
    let delay = this.config.detailDelay || 3000; // 默认增加到 3 秒

    if (this.config.randomDelay) {
      // 增加随机范围：0.8 到 1.5 倍
      const randomFactor = 0.8 + Math.random() * 0.7; // 0.8 到 1.5
      delay = Math.floor(delay * randomFactor);
    }

    // 每 5 个请求后，额外增加长延迟（防止频率限制）
    if (this.currentIndex > 0 && this.currentIndex % 5 === 0) {
      const extraDelay = 2000 + Math.random() * 3000; // 额外 2-5 秒
      console.log('[Deep Scraper Offscreen] 第', this.currentIndex, '个，添加额外延迟:', Math.floor(extraDelay), 'ms');
      delay += extraDelay;
    }

    console.log('[Deep Scraper Offscreen] 延迟:', delay, 'ms');
    await this.sleep(delay);
  }

  // 暂停
  pause() {
    this.paused = true;
    console.log('[Deep Scraper Offscreen] 已暂停');
    this.sendDebugLog('warning', '深度采集已暂停');
  }

  // 继续
  resume() {
    this.paused = false;
    console.log('[Deep Scraper Offscreen] 已继续');
    this.sendDebugLog('info', '深度采集已继续');
  }

  // 停止
  stop() {
    this.stopped = true;
    console.log('[Deep Scraper Offscreen] 已停止');
    this.sendDebugLog('warning', '深度采集已停止');
  }

  // 发送进度
  sendProgress(current, total, job, updatedJob = null) {
    const progress = Math.floor((current / total) * 100);
    const message = {
      action: 'deepScrapeProgress',
      current,
      total,
      progress,
      job: { title: job.title, company: job.company },
      updatedJob: updatedJob
    };
    console.log('[Deep Scraper Offscreen] 发送进度:', message);
    chrome.runtime.sendMessage(message);
  }

  // 发送调试日志
  sendDebugLog(type, message) {
    try {
      chrome.runtime.sendMessage({
        action: 'debugLog',
        logType: type,
        logMessage: message
      });
    } catch (error) {
      // 忽略
    }
  }

  // 延迟函数
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// 导出为全局变量
window.DeepScraperOffscreen = DeepScraperOffscreen;
