// 深度采集类 - 使用新标签页访问职位详情页
class DeepScraper {
  constructor(jobs, config = {}) {
    this.jobs = jobs; // 基础采集的职位列表
    this.config = config;
    this.currentIndex = 0;
    this.successCount = 0;
    this.failCount = 0;
    this.paused = false;
    this.stopped = false;
    this.detailSelectors = config.detailSelectors || {}; // 详情页字段选择器
    this.enableAIValidation = config.enableAIValidation !== false; // 默认启用 AI 验证
    this.enableBasicValidation = config.enableBasicValidation || false; // 默认关闭基础验证
  }

  // 开始深度采集
  async start() {
    console.log('[Deep Scraper] 开始深度采集，总数:', this.jobs.length);
    this.sendDebugLog('info', `开始深度采集 ${this.jobs.length} 个职位`);

    this.currentIndex = 0;
    this.successCount = 0;
    this.failCount = 0;
    this.paused = false;
    this.stopped = false;

    try {
      for (let i = 0; i < this.jobs.length; i++) {
        // 检查是否停止
        if (this.stopped) {
          console.log('[Deep Scraper] 用户停止了深度采集');
          break;
        }

        // 检查是否暂停
        while (this.paused && !this.stopped) {
          await this.sleep(500);
        }

        if (this.stopped) break;

        this.currentIndex = i;
        const job = this.jobs[i];

        // 访问详情页并提取
        const success = await this.scrapeJobDetail(job);

        if (success) {
          this.successCount++;
        } else {
          this.failCount++;
        }

        // 延迟（防止被检测）
        if (i < this.jobs.length - 1) {
          await this.delayWithRandom();
        }
      }

      // 发送完成消息
      chrome.runtime.sendMessage({
        action: 'deepScrapeComplete',
        jobs: this.jobs,
        count: this.jobs.length,
        successCount: this.successCount,
        failCount: this.failCount
      });

      console.log('[Deep Scraper] 深度采集完成，成功:', this.successCount, '失败:', this.failCount);

    } catch (error) {
      console.error('[Deep Scraper] 深度采集失败:', error);
      chrome.runtime.sendMessage({
        action: 'deepScrapeError',
        error: error.message
      });
    }
  }

  // 采集单个职位详情
  async scrapeJobDetail(job) {
    try {
      if (!job.jobUrl) {
        console.warn('[Deep Scraper] 职位没有链接:', job.title);
        this.sendDebugLog('warning', `跳过 ${job.title}：无链接`);
        return false;
      }

      console.log('[Deep Scraper] 访问详情页:', job.jobUrl);

      // 发送开始采集的进度（显示当前正在采集的职位）
      this.sendProgress(this.currentIndex + 1, this.jobs.length, job, null);

      // 在新标签页打开详情页
      const detailData = await this.fetchJobDetailInNewTab(job.jobUrl);

      if (detailData) {
        // 更新职位数据（只更新详情页特有的字段，不覆盖列表页的字段）
        // 详情页特有字段：salary, description, welfare, hrActivity, companySize, industry
        // 列表页字段（不覆盖）：title, company, location, experience, education
        if (detailData.salary) job.salary = detailData.salary;
        if (detailData.description) job.description = detailData.description;
        if (detailData.welfare) job.welfare = detailData.welfare;
        if (detailData.hrActivity) job.hrActivity = detailData.hrActivity;
        if (detailData.companySize) job.companySize = detailData.companySize;
        if (detailData.industry) job.industry = detailData.industry;

        const hrActivity = detailData.hrActivity || '未知';
        this.sendDebugLog('success', `✓ ${job.title} - 活跃: ${hrActivity}`);
        return true;
      } else {
        this.sendDebugLog('error', `✗ ${job.title} - 提取失败`);
        return false;
      }

    } catch (error) {
      console.error('[Deep Scraper] 提取详情失败:', error);
      this.sendDebugLog('error', `✗ ${job.title} - ${error.message}`);
      return false;
    }
  }

  // 在新标签页中获取职位详情
  async fetchJobDetailInNewTab(url) {
    return new Promise((resolve) => {
      // 打开新标签页
      const newTab = window.open(url, '_blank');

      if (!newTab) {
        console.error('[Deep Scraper] 无法打开新标签页，可能被浏览器阻止');
        this.sendDebugLog('error', '无法打开新标签页，请允许弹窗');
        resolve(null);
        return;
      }

      let resolved = false;
      let checkCount = 0;
      const maxChecks = 30; // 最多检查30次（15秒）

      const timeout = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          console.warn('[Deep Scraper] 页面加载超时 (15秒)');
          this.sendDebugLog('warning', '页面加载超时，跳过此职位');
          try {
            newTab.close();
          } catch (e) {}
          resolve(null);
        }
      }, 15000); // 15秒超时

      // 等待新标签页加载完成
      const checkInterval = setInterval(async () => {
        checkCount++;

        try {
          // 检查标签页是否加载完成
          if (newTab.document && newTab.document.readyState === 'complete') {
            clearInterval(checkInterval);

            if (!resolved) {
              console.log('[Deep Scraper] 页面加载完成，等待内容渲染...');

              // 页面加载完成后，额外等待一段时间确保动态内容渲染
              await this.sleep(1000);

              // 再次检查关键元素是否存在
              const hasContent = await this.waitForContent(newTab.document);

              if (!hasContent) {
                console.warn('[Deep Scraper] 页面内容未完全加载');
                this.sendDebugLog('warning', '页面内容加载不完整');
              }

              console.log('[Deep Scraper] 开始提取数据');

              // 提取数据
              const detailData = await this.extractDetailDataFromDocument(newTab.document);

              resolved = true;
              clearTimeout(timeout);

              // 关闭标签页
              setTimeout(() => {
                try {
                  newTab.close();
                } catch (e) {}
              }, 500);

              resolve(detailData);
            }
          } else if (checkCount >= maxChecks) {
            // 超过最大检查次数，放弃
            clearInterval(checkInterval);
            if (!resolved) {
              resolved = true;
              clearTimeout(timeout);
              console.warn('[Deep Scraper] 超过最大检查次数，页面可能未加载');
              this.sendDebugLog('warning', '页面检查超时');
              try {
                newTab.close();
              } catch (e) {}
              resolve(null);
            }
          }
        } catch (error) {
          // 可能是跨域问题或标签页已关闭
          console.warn('[Deep Scraper] 访问页面时出错:', error.message);

          // 如果是严重错误，停止检查
          if (checkCount > 5) {
            clearInterval(checkInterval);
            if (!resolved) {
              resolved = true;
              clearTimeout(timeout);
              this.sendDebugLog('error', `访问页面失败: ${error.message}`);
              try {
                newTab.close();
              } catch (e) {}
              resolve(null);
            }
          }
        }
      }, 500);

    });
  }

  // 等待页面内容加载
  async waitForContent(doc) {
    try {
      // 检查是否有配置的选择器对应的元素
      const selectors = Object.values(this.detailSelectors);

      if (selectors.length === 0) {
        return true; // 没有配置选择器，直接返回
      }

      // 最多等待3秒
      const maxWait = 3000;
      const startTime = Date.now();

      while (Date.now() - startTime < maxWait) {
        // 检查是否至少有一个选择器找到了元素
        let foundAny = false;
        for (const selector of selectors) {
          if (doc.querySelector(selector)) {
            foundAny = true;
            break;
          }
        }

        if (foundAny) {
          console.log('[Deep Scraper] 检测到页面内容已加载');
          return true;
        }

        // 等待100ms再检查
        await this.sleep(100);
      }

      console.warn('[Deep Scraper] 等待内容超时，继续提取');
      return false;

    } catch (error) {
      console.error('[Deep Scraper] 等待内容时出错:', error);
      return false;
    }
  }

  // 从文档中提取详情数据
  async extractDetailDataFromDocument(doc) {
    try {
      const data = {};

      // 使用配置的选择器提取字段
      for (const [field, selector] of Object.entries(this.detailSelectors)) {
        try {
          const element = doc.querySelector(selector);
          if (element) {
            // 如果是福利待遇（可能是列表）
            if (field === 'welfare') {
              const items = element.querySelectorAll('*');
              const texts = Array.from(items)
                .map(el => el.textContent.trim())
                .filter(t => t.length > 0 && t.length < 50);
              data[field] = texts.length > 0 ? texts : [element.textContent.trim()];
            } else {
              const value = element.textContent.trim();

              // 对关键字段使用 AI 验证
              if (this.shouldUseAIValidation(field)) {
                const validatedValue = await this.validateWithAI(field, value);
                if (validatedValue) {
                  data[field] = validatedValue;
                } else {
                  console.warn(`[Deep Scraper] AI验证失败，字段 ${field} 已忽略: "${value}"`);
                  this.sendDebugLog('warning', `AI验证: ${field} 不合理 - "${value.substring(0, 30)}..."`);
                }
              } else if (this.enableBasicValidation) {
                // 只有启用基础验证时才使用正则验证
                if (this.isValidFieldValue(field, value)) {
                  data[field] = value;
                } else {
                  console.warn(`[Deep Scraper] 字段 ${field} 的值不合理，已忽略: "${value}"`);
                  this.sendDebugLog('warning', `正则验证: ${field} 不合理 - "${value.substring(0, 30)}..."`);
                }
              } else {
                // 不验证，直接使用
                data[field] = value;
              }
            }
          } else {
            // 选择器没有找到元素
            console.warn(`[Deep Scraper] 字段 ${field} 的选择器未找到元素: ${selector}`);
            this.sendDebugLog('warning', `${field} 选择器无匹配: ${selector.substring(0, 30)}...`);
          }
        } catch (error) {
          console.error('[Deep Scraper] 提取字段失败:', field, error);
          this.sendDebugLog('error', `${field} 提取异常: ${error.message}`);
        }
      }

      console.log('[Deep Scraper] 提取的详情数据:', data);
      return data;

    } catch (error) {
      console.error('[Deep Scraper] 提取详情数据失败:', error);
      return null;
    }
  }

  // 判断是否需要使用 AI 验证
  shouldUseAIValidation(field) {
    // 只有启用了 AI 验证才使用
    if (!this.enableAIValidation) {
      return false;
    }

    // 对公司规模和所属行业字段使用 AI 验证
    return field === 'companySize' || field === 'industry';
  }

  // 使用 AI 验证字段值
  async validateWithAI(field, value) {
    try {
      // 构建验证提示词（针对不同字段）
      let prompt = '';

      if (field === 'companySize') {
        prompt = `请判断以下文本是否是"公司规模"信息。公司规模通常是人数范围，如"100-500人"、"1000人以上"、"少于50人"等。
如果是公司规模信息，请直接返回原文。
如果不是公司规模信息（比如融资信息、行业信息等），请只返回"INVALID"。

文本：${value}

回答：`;
      } else if (field === 'industry') {
        prompt = `请判断以下文本是否是"所属行业"信息。所属行业通常是行业类别，如"互联网"、"电子商务"、"金融科技"、"企业服务"、"教育培训"等。
如果是所属行业信息，请直接返回原文。
如果不是所属行业信息（比如融资信息、公司规模等），请只返回"INVALID"。

文本：${value}

回答：`;
      } else {
        // 其他字段暂不支持AI验证
        return value;
      }

      // 调用本地 Copilot API
      const response = await fetch('http://localhost:4141/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.1,
          max_tokens: 100
        })
      });

      if (!response.ok) {
        console.warn('[Deep Scraper] AI API 调用失败，使用基础验证');
        return this.isValidFieldValue(field, value) ? value : null;
      }

      const result = await response.json();
      const answer = result.choices?.[0]?.message?.content?.trim();

      if (!answer) {
        console.warn('[Deep Scraper] AI 返回空结果');
        return this.isValidFieldValue(field, value) ? value : null;
      }

      // 如果 AI 返回 INVALID，则拒绝该值
      if (answer === 'INVALID' || answer.includes('INVALID')) {
        console.log(`[Deep Scraper] AI 判断 ${field} 不合理: "${value}"`);
        return null;
      }

      // AI 认为合理，返回原值（或 AI 清洗后的值）
      console.log(`[Deep Scraper] AI 验证通过 ${field}: "${value}"`);
      this.sendDebugLog('success', `AI验证✓ ${field}: "${value}"`);
      return answer;

    } catch (error) {
      console.error('[Deep Scraper] AI 验证出错:', error);
      // AI 验证失败，回退到基础验证
      return this.isValidFieldValue(field, value) ? value : null;
    }
  }

  // 验证字段值是否合理
  isValidFieldValue(field, value) {
    if (!value || value.length === 0) {
      return false;
    }

    // 基础检查：长度不能太长（可能提取到了整个容器）
    if (value.length > 500) {
      return false;
    }

    // 针对不同字段的特定验证
    switch(field) {
      case 'companySize':
        // 公司规模通常包含：人、员工、少于、以下、以上等关键词
        // 或者是数字范围格式：100-500人、1000人以上、少于50人
        const sizePatterns = [
          /\d+[-~]\d+人/,           // 100-500人
          /\d+人以上/,              // 1000人以上
          /\d+人以下/,              // 50人以下
          /少于\d+人/,              // 少于50人
          /不需要融资/,             // 排除融资信息
          /未融资/,                 // 排除融资信息
        ];

        // 如果包含"融资"关键词，大概率是错误的
        if (value.includes('融资') || value.includes('轮')) {
          return false;
        }

        // 必须匹配公司规模的常见格式
        const hasValidPattern = sizePatterns.some(pattern => pattern.test(value));
        if (!hasValidPattern && !value.includes('人')) {
          return false;
        }

        // 长度检查：公司规模通常很短（5-20字符）
        if (value.length > 30) {
          return false;
        }

        return true;

      case 'industry':
        // 所属行业：通常较短，不应该包含"融资"等关键词
        if (value.includes('融资') || value.includes('轮')) {
          return false;
        }

        // 长度检查：行业名称通常较短（2-30字符）
        if (value.length < 2 || value.length > 30) {
          return false;
        }

        return true;

      case 'salary':
        // 薪资范围：必须包含数字和K/k
        const salaryPatterns = [
          /\d+[-~·]\d+[Kk]/,        // 15-25K
          /\d+[Kk]以上/,            // 30K以上
          /\d+[Kk]\/月/,            // 20K/月
        ];

        const hasValidSalary = salaryPatterns.some(pattern => pattern.test(value));
        if (!hasValidSalary) {
          return false;
        }

        // 长度检查：薪资信息通常较短
        if (value.length > 50) {
          return false;
        }

        return true;

      case 'hrActivity':
        // HR活跃状态：通常包含"活跃"、"在线"、"小时"、"天"等关键词
        const activityKeywords = ['活跃', '在线', '小时', '天', '刚刚', '分钟'];
        const hasActivityKeyword = activityKeywords.some(keyword => value.includes(keyword));

        if (!hasActivityKeyword) {
          return false;
        }

        // 长度检查：活跃状态通常很短（5-30字符）
        if (value.length > 50) {
          return false;
        }

        return true;

      case 'description':
        // 职位描述：应该有一定长度，不能太短
        if (value.length < 10) {
          return false;
        }

        return true;

      default:
        // 其他字段：基础验证
        return value.length > 0 && value.length < 500;
    }
  }

  // 延迟（带随机）
  async delayWithRandom() {
    let delay = this.config.detailDelay || 2000;

    if (this.config.randomDelay) {
      // 在基础延迟上 ±30% 随机
      const randomFactor = 0.7 + Math.random() * 0.6; // 0.7 到 1.3
      delay = Math.floor(delay * randomFactor);
    }

    console.log('[Deep Scraper] 延迟:', delay, 'ms');
    await this.sleep(delay);
  }

  // 暂停
  pause() {
    this.paused = true;
    console.log('[Deep Scraper] 已暂停');
    this.sendDebugLog('warning', '深度采集已暂停');
  }

  // 继续
  resume() {
    this.paused = false;
    console.log('[Deep Scraper] 已继续');
    this.sendDebugLog('info', '深度采集已继续');
  }

  // 停止
  stop() {
    this.stopped = true;
    console.log('[Deep Scraper] 已停止');
    this.sendDebugLog('warning', '深度采集已停止');
  }

  // 发送进度
  sendProgress(current, total, job, updatedJob = null) {
    const progress = Math.floor((current / total) * 100);
    const message = {
      action: 'deepScrapeProgress',
      current,
      total,
      progress,
      job: { title: job.title, company: job.company },
      updatedJob: updatedJob
    };
    console.log('[Deep Scraper] 发送进度:', message);
    chrome.runtime.sendMessage(message);
  }

  // 发送调试日志
  sendDebugLog(type, message) {
    try {
      chrome.runtime.sendMessage({
        action: 'debugLog',
        logType: type,
        logMessage: message
      });
    } catch (error) {
      // 忽略
    }
  }

  // 延迟函数
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// 导出为全局变量
window.DeepScraper = DeepScraper;
