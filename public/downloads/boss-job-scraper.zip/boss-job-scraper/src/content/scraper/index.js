// 自动滚动加载类
class AutoScroller {
  constructor(config = {}) {
    this.scrollDelay = config.scrollDelay || 1000;
    this.randomDelay = config.randomDelay !== false; // 默认开启随机延迟
    this.maxRetries = config.maxRetries || 3;
    this.observer = null;
    this.stopped = false; // 添加停止标志
    this.listSelector = null; // 添加列表选择器，用于数量检查
  }

  // 设置列表选择器
  setListSelector(selector) {
    this.listSelector = selector;
  }

  // 停止滚动
  stop() {
    this.stopped = true;
    console.log('[Boss Scraper] 收到停止信号');
  }

  // 重置状态
  reset() {
    this.stopped = false;
  }

  // 主滚动逻辑：滚动到加载所有数据
  async scrollToLoadAll(onProgress, limitNumber = null) {
    let lastHeight = 0;
    let noChangeCount = 0;
    let progress = 0;
    let scrollCount = 0;

    console.log('[Boss Scraper] 开始自动滚动加载...');
    if (limitNumber) {
      console.log(`[Boss Scraper] 目标数量: ${limitNumber}`);
    }

    while (noChangeCount < this.maxRetries && !this.stopped) {
      // 检查是否被停止
      if (this.stopped) {
        console.log('[Boss Scraper] 滚动已停止');
        return { stopped: true, progress };
      }

      // 如果启用了数量限制，检查当前职位数量
      if (limitNumber) {
        const currentCount = this.getCurrentJobCount();
        console.log(`[Boss Scraper] 当前已加载职位数: ${currentCount}, 目标: ${limitNumber}`);

        if (currentCount >= limitNumber) {
          console.log(`[Boss Scraper] 已达到目标数量 ${limitNumber}，停止滚动`);
          return { stopped: false, progress: 100 };
        }
      }

      // 滚动到底部
      const scrollHeight = document.documentElement.scrollHeight;
      window.scrollTo({
        top: scrollHeight,
        behavior: 'smooth'
      });

      scrollCount++;
      console.log(`[Boss Scraper] 第 ${scrollCount} 次滚动，页面高度: ${scrollHeight}`);

      // 等待延迟（带随机）
      const actualDelay = this.getActualScrollDelay();
      console.log(`[Boss Scraper] 等待 ${actualDelay}ms`);
      await this.sleep(actualDelay);

      // 再次检查是否被停止
      if (this.stopped) {
        console.log('[Boss Scraper] 滚动已停止');
        return { stopped: true, progress };
      }

      // 等待 DOM 变化
      const hasChange = await this.waitForDOMChange(2000);

      const currentHeight = document.documentElement.scrollHeight;

      if (currentHeight === lastHeight) {
        noChangeCount++;
        console.log(`[Boss Scraper] 高度未变化 (${noChangeCount}/${this.maxRetries})`);
      } else {
        noChangeCount = 0;
        progress = Math.min(progress + 15, 90);
        if (onProgress) onProgress(progress);
        console.log(`[Boss Scraper] 加载了新内容，进度: ${progress}%`);
      }

      lastHeight = currentHeight;

      // 检查是否有"没有更多"提示
      if (this.detectNoMoreData()) {
        console.log('[Boss Scraper] 检测到"没有更多数据"提示');
        break;
      }
    }

    if (onProgress) onProgress(100);
    console.log('[Boss Scraper] 滚动加载完成');
    return { stopped: false, progress: 100 };
  }

  // 等待 DOM 变化
  waitForDOMChange(timeout) {
    return new Promise((resolve) => {
      let resolved = false;

      const observer = new MutationObserver(() => {
        if (!resolved) {
          resolved = true;
          observer.disconnect();
          resolve(true);
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });

      setTimeout(() => {
        if (!resolved) {
          resolved = true;
          observer.disconnect();
          resolve(false);
        }
      }, timeout);
    });
  }

  // 检测是否到达底部（没有更多数据）
  detectNoMoreData() {
    const indicators = [
      '没有更多了',
      '已经到底了',
      '暂无更多',
      'no more',
      '加载完毕'
    ];

    const bodyText = document.body.innerText.toLowerCase();
    return indicators.some(text => bodyText.includes(text.toLowerCase()));
  }

  // 获取当前已加载的职位数量
  getCurrentJobCount() {
    try {
      if (!this.listSelector) {
        return 0;
      }

      const container = document.querySelector(this.listSelector);
      if (!container) {
        return 0;
      }

      // 尝试不同的选择器
      const jobSelectors = [
        '.job-card-wrapper',
        'li.job-card-box',
        '[class*="job-card"]',
        'li[ka*="job"]'
      ];

      for (const selector of jobSelectors) {
        const jobElements = container.querySelectorAll(selector);
        if (jobElements.length > 0) {
          return jobElements.length;
        }
      }

      // 如果找不到，尝试直接用子元素
      return Array.from(container.children).filter(el => {
        return el.tagName === 'LI' || el.tagName === 'DIV';
      }).length;

    } catch (error) {
      console.error('[Boss Scraper] 获取职位数量失败:', error);
      return 0;
    }
  }

  // 计算实际的滚动延迟（带随机）
  getActualScrollDelay() {
    let delay = this.scrollDelay;

    if (this.randomDelay) {
      // 在基础延迟上 ±30% 随机
      const randomFactor = 0.7 + Math.random() * 0.6; // 0.7 到 1.3
      delay = Math.floor(delay * randomFactor);
    }

    return delay;
  }

  // 延迟函数
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// 职位数据采集类
class JobScraper {
  constructor(listSelector, config = {}) {
    this.listSelector = listSelector;
    this.jobs = [];
    this.config = config;
    this.listFieldSelectors = config.listFieldSelectors || {}; // 列表字段选择器
    this.scroller = new AutoScroller({
      scrollDelay: config.scrollDelay || 1000,
      randomDelay: config.randomDelay !== false, // 默认开启随机延迟
      maxRetries: 3
    });
    this.scroller.setListSelector(listSelector); // 设置列表选择器
    this.scroller.listSelector = listSelector; // 也直接设置
    this.stopped = false; // 添加停止标志
    this.enableLimit = config.enableLimit || false; // 是否启用数量限制
    this.limitNumber = config.limitNumber || 10; // 限制数量
  }

  // 停止采集
  stop() {
    this.stopped = true;
    this.scroller.stop();
    console.log('[Boss Scraper] 采集已停止');
  }

  // 发送调试日志到侧边栏
  sendDebugLog(type, message) {
    try {
      chrome.runtime.sendMessage({
        action: 'debugLog',
        logType: type,
        logMessage: message
      });
    } catch (error) {
      // 忽略发送失败的错误
    }
  }

  // 开始采集
  async start() {
    console.log('[Boss Scraper] 开始采集流程...');
    this.stopped = false;
    this.scroller.reset();

    // 清空之前的数据
    this.jobs = [];
    console.log('[Boss Scraper] 已清空旧数据');
    this.sendDebugLog('info', '开始采集流程，已清空旧数据');

    if (this.enableLimit) {
      console.log(`[Boss Scraper] 启用数量限制: ${this.limitNumber}`);
      this.sendDebugLog('info', `启用数量限制: ${this.limitNumber} 条`);
    }

    try {
      // 1. 自动滚动加载数据（如果启用了数量限制，则滚动到足够的数量）
      const scrollResult = await this.scroller.scrollToLoadAll((progress) => {
        chrome.runtime.sendMessage({
          action: 'updateProgress',
          progress: progress,
          status: '正在滚动加载数据...'
        });
      }, this.enableLimit ? this.limitNumber : null); // 传递限制数量

      // 检查是否被停止
      if (scrollResult.stopped || this.stopped) {
        console.log('[Boss Scraper] 采集被用户停止');
        this.sendDebugLog('warning', '用户停止了采集');

        // 提取当前已加载的职位
        chrome.runtime.sendMessage({
          action: 'updateProgress',
          progress: scrollResult.progress,
          status: '正在提取已加载的数据...'
        });

        this.sendDebugLog('info', '开始提取已加载的数据...');
        this.extractAllJobs();

        console.log(`[Boss Scraper] 停止时提取到 ${this.jobs.length} 条职位`);
        this.sendDebugLog('info', `提取到 ${this.jobs.length} 条职位数据`);

        // 去重（如果启用）
        if (this.config.autoDedupe !== false) {
          const beforeCount = this.jobs.length;
          this.deduplicateJobs();
          const afterCount = this.jobs.length;
          console.log(`[Boss Scraper] 去重后剩余 ${afterCount} 条职位`);
          this.sendDebugLog('info', `去重: ${beforeCount} → ${afterCount} 条`);
        }

        // 发送停止结果
        chrome.runtime.sendMessage({
          action: 'scrapingStopped',
          jobs: this.jobs,
          count: this.jobs.length,
          progress: scrollResult.progress
        });

        return;
      }

      // 2. 提取所有职位
      chrome.runtime.sendMessage({
        action: 'updateProgress',
        progress: 95,
        status: '正在提取职位数据...'
      });

      this.extractAllJobs();

      // 如果启用了数量限制，只保留指定数量
      if (this.enableLimit && this.jobs.length > this.limitNumber) {
        console.log(`[Boss Scraper] 截取前 ${this.limitNumber} 条数据`);
        this.sendDebugLog('info', `截取前 ${this.limitNumber} 条数据`);
        this.jobs = this.jobs.slice(0, this.limitNumber);
      }

      // 3. 去重（如果启用）
      if (this.config.autoDedupe !== false) {
        const originalCount = this.jobs.length;
        this.deduplicateJobs();
        const removedCount = originalCount - this.jobs.length;
        console.log(`[Boss Scraper] 去重完成，移除 ${removedCount} 条重复数据`);
      }

      // 4. 发送结果
      chrome.runtime.sendMessage({
        action: 'scrapingComplete',
        jobs: this.jobs,
        count: this.jobs.length
      });

      console.log(`[Boss Scraper] 采集完成，共 ${this.jobs.length} 条职位`);

    } catch (error) {
      console.error('[Boss Scraper] 采集失败:', error);
      chrome.runtime.sendMessage({
        action: 'scrapingError',
        error: error.message
      });
    }
  }

  // 提取所有职位
  extractAllJobs() {
    try {
      console.log('[Boss Scraper] 开始提取职位，当前选择器:', this.listSelector);
      this.sendDebugLog('info', `选择器: ${this.listSelector}`);

      const container = document.querySelector(this.listSelector);
      if (!container) {
        console.error('[Boss Scraper] 未找到职位列表容器:', this.listSelector);
        this.sendDebugLog('error', '未找到职位列表容器');
        throw new Error('未找到职位列表容器');
      }

      console.log('[Boss Scraper] 找到容器元素:', container.tagName, container.className);
      this.sendDebugLog('success', `找到容器: ${container.tagName} ${container.className || ''}`);

      // Boss 直聘的职位卡片选择器
      const jobSelectors = [
        '.job-card-wrapper',
        'li.job-card-box',
        '[class*="job-card"]',
        'li[ka*="job"]'
      ];

      let jobElements = [];

      // 尝试不同的选择器
      for (const selector of jobSelectors) {
        jobElements = container.querySelectorAll(selector);
        if (jobElements.length > 0) {
          console.log(`[Boss Scraper] 使用选择器 "${selector}" 找到 ${jobElements.length} 个职位`);
          this.sendDebugLog('success', `找到 ${jobElements.length} 个职位 (选择器: ${selector})`);
          break;
        }
      }

      if (jobElements.length === 0) {
        // 如果找不到，尝试直接用用户选择的容器的子元素
        jobElements = Array.from(container.children).filter(el => {
          return el.tagName === 'LI' || el.tagName === 'DIV';
        });
        console.log(`[Boss Scraper] 使用容器子元素，找到 ${jobElements.length} 个元素`);
        this.sendDebugLog('warning', `使用容器子元素，找到 ${jobElements.length} 个`);
      }

      if (jobElements.length === 0) {
        console.warn('[Boss Scraper] 警告：没有找到任何职位元素！');
        this.sendDebugLog('error', '没有找到任何职位元素！');
      }

      let successCount = 0;
      let failCount = 0;

      // 如果找到职位元素，先诊断第一个元素
      if (jobElements.length > 0) {
        const firstElement = jobElements[0];
        console.log('[Boss Scraper] 诊断第一个职位元素:');
        console.log('  HTML:', firstElement.innerHTML.substring(0, 500));
        console.log('  所有类名:', this.getAllClassNames(firstElement));

        // 发送诊断信息到日志面板
        const classList = this.getAllClassNames(firstElement);
        this.sendDebugLog('info', `第一个职位的类名: ${classList.slice(0, 5).join(', ')}`);
      }

      jobElements.forEach((element, index) => {
        const job = this.extractJobData(element);
        if (job) {
          this.jobs.push(job);
          successCount++;
        } else {
          failCount++;
          // 只记录前3个失败的，增加更多调试信息
          if (failCount <= 3) {
            console.log(`[Boss Scraper] 失败的元素 #${index + 1}:`);
            console.log('  文本内容:', element.textContent.substring(0, 200));
            console.log('  链接数量:', element.querySelectorAll('a').length);
            console.log('  第一个链接:', element.querySelector('a')?.textContent.trim() || '无');

            // 发送到日志面板
            this.sendDebugLog('error', `失败 #${index + 1}: ${element.textContent.substring(0, 50)}...`);

            const links = element.querySelectorAll('a');
            if (links.length > 0) {
              this.sendDebugLog('info', `  链接1: ${links[0]?.textContent.trim()}`);
            }
            if (links.length > 1) {
              this.sendDebugLog('info', `  链接2: ${links[1]?.textContent.trim()}`);
            }
          }
        }
      });

      console.log(`[Boss Scraper] 提取完成 - 成功: ${successCount}, 失败: ${failCount}, 总计: ${this.jobs.length} 条职位数据`);
      this.sendDebugLog('success', `提取完成 - 成功: ${successCount}, 失败: ${failCount}`);

    } catch (error) {
      console.error('[Boss Scraper] 提取职位失败:', error);
      this.sendDebugLog('error', '提取失败: ' + error.message);
      throw error;
    }
  }

  // 提取单个职位数据
  extractJobData(element) {
    try {
      let title = '';
      let company = '';
      let location = '';
      let experience = '';
      let education = '';
      let jobUrl = '';

      // 优先使用配置的选择器
      if (Object.keys(this.listFieldSelectors).length > 0) {
        console.log('[Boss Scraper] 使用配置的选择器提取数据');

        Object.entries(this.listFieldSelectors).forEach(([field, selector]) => {
          try {
            const fieldElement = element.querySelector(selector);
            if (fieldElement) {
              const value = fieldElement.textContent.trim();

              switch(field) {
                case 'title':
                  title = value;
                  jobUrl = fieldElement.href || '';
                  break;
                case 'company':
                  company = value;
                  break;
                case 'location':
                  location = value;
                  break;
                case 'experience':
                  experience = value;
                  break;
                case 'education':
                  education = value;
                  break;
              }
            }
          } catch (error) {
            console.warn(`[Boss Scraper] 配置选择器提取失败 (${field}):`, error);
          }
        });
      }

      // 如果配置的选择器没有提取到数据，使用默认方法
      if (!title || !company) {
        console.log('[Boss Scraper] 配置选择器未能提取关键字段，使用默认方法');

        // 先尝试用链接直接提取（最可靠的方法）
        const links = element.querySelectorAll('a');

        // 第一个链接通常是职位标题
        if (!title && links[0]) {
          title = links[0].textContent.trim();
          jobUrl = links[0].href || '';
        }

        // 第二个链接通常是公司名称
        if (!company && links[1]) {
          company = links[1].textContent.trim();
        }

        // 如果链接提取失败，再尝试 CSS 选择器
        if (!title) {
          title = this.extractText(element, [
            '.job-title',
            'a.job-title',
            '.job-info .job-title',
            '.job-name',
            '[class*="job-title"]',
            'span.job-name'
          ]);
        }

        if (!company) {
          company = this.extractText(element, [
            '.company-name',
            '.company-info .name',
            'a.company-name',
            '[class*="company-name"]'
          ]);
        }
      }

      const job = {
        title: title || '',
        company: company || '',
        location: location || this.extractText(element, [
          '.job-area',
          '.area',
          '.job-info .area'
        ]),
        experience: experience || this.extractText(element, [
          '.experience',
          '.job-limit .experience'
        ]),
        education: education || this.extractText(element, [
          '.education',
          '.job-limit .education'
        ]),

        jobUrl: jobUrl,
        scrapedAt: new Date().toISOString(),
        jobId: this.generateJobId(element)
      };

      // 验证必要字段
      if (!job.title && !job.company) {
        return null;
      }

      return job;

    } catch (error) {
      console.error('[Boss Scraper] 提取单个职位失败:', error);
      return null;
    }
  }

  // 从文本中智能提取数据（备用方案）
  extractFromText(element, fullText) {
    try {
      console.log('[Boss Scraper] 尝试文本提取，全文长度:', fullText.length);

      // 查找所有 <a> 标签
      const links = element.querySelectorAll('a');
      console.log('[Boss Scraper] 找到链接数量:', links.length);

      let title = '';
      let company = '';
      let jobUrl = '';

      // 第一个链接通常是职位标题
      if (links[0]) {
        title = links[0].textContent.trim();
        jobUrl = links[0].href || '';
        console.log('[Boss Scraper] 链接1 (职位):', title);
      }

      // 第二个链接通常是公司名称
      if (links[1]) {
        company = links[1].textContent.trim();
        console.log('[Boss Scraper] 链接2 (公司):', company);
      }

      // 如果没有两个链接，尝试其他方法
      if (!title && links.length > 0) {
        // 可能只有一个链接，看看是职位还是公司
        const firstLinkText = links[0].textContent.trim();
        console.log('[Boss Scraper] 只有一个链接:', firstLinkText);

        // 如果文本很长，可能是职位标题
        if (firstLinkText.length > 5 && firstLinkText.length < 50) {
          title = firstLinkText;
        }
      }

      // 查找薪资（通常包含 K 或 k）
      const salaryMatch = fullText.match(/(\d+[-~]\d+[Kk]|\d+[Kk]以上|\d+[Kk]-\d+[Kk])/);
      const salary = salaryMatch ? salaryMatch[0] : '';
      console.log('[Boss Scraper] 薪资匹配:', salary);

      if (title || company) {
        console.log('[Boss Scraper] 文本提取成功!');
        this.sendDebugLog('success', `文本提取: ${title} - ${company} - ${salary}`);

        return {
          title: title || '',
          company: company || '',
          location: '',
          experience: '',
          education: '',
          jobUrl: jobUrl,
          scrapedAt: new Date().toISOString(),
          jobId: this.generateJobId(element)
        };
      }

      console.log('[Boss Scraper] 文本提取也失败了');
      return null;
    } catch (error) {
      console.error('[Boss Scraper] 文本提取失败:', error);
      return null;
    }
  }

  // 辅助方法：提取文本内容
  extractText(element, selectors) {
    for (const selector of selectors) {
      const el = element.querySelector(selector);
      if (el && el.textContent) {
        return el.textContent.trim();
      }
    }
    return '';
  }

  // 获取元素及其子元素的所有类名
  getAllClassNames(element) {
    const classNames = new Set();

    // 递归获取所有子元素的类名
    const collectClasses = (el) => {
      if (el.className && typeof el.className === 'string') {
        el.className.split(' ').forEach(cls => {
          if (cls.trim()) classNames.add(cls.trim());
        });
      }

      // 只遍历前几层子元素
      if (el.children && el.children.length > 0) {
        Array.from(el.children).slice(0, 10).forEach(child => {
          collectClasses(child);
        });
      }
    };

    collectClasses(element);
    return Array.from(classNames);
  }

  // 辅助方法：提取数组内容
  extractArray(element, selectors) {
    for (const selector of selectors) {
      const elements = element.querySelectorAll(selector);
      if (elements.length > 0) {
        return Array.from(elements).map(el => el.textContent.trim());
      }
    }
    return [];
  }

  // 辅助方法：提取链接
  extractLink(element) {
    const link = element.querySelector('a[href]');
    if (link) {
      const href = link.getAttribute('href');
      // 确保是完整 URL
      if (href.startsWith('http')) {
        return href;
      } else if (href.startsWith('/')) {
        return `https://www.zhipin.com${href}`;
      }
    }
    return '';
  }

  // 生成职位唯一 ID
  generateJobId(element) {
    // 尝试获取 data-job-id
    const dataId = element.getAttribute('data-job-id') ||
                   element.getAttribute('data-jid') ||
                   element.getAttribute('lid');

    if (dataId) {
      return dataId;
    }

    // 使用链接中的 ID
    const link = element.querySelector('a[href]');
    if (link) {
      const href = link.getAttribute('href');
      const match = href.match(/job_detail\/(\w+)/);
      if (match) {
        return match[1];
      }
    }

    // 使用职位名 + 公司名生成 ID
    const title = this.extractText(element, ['.job-title', '.job-name']);
    const company = this.extractText(element, ['.company-name']);
    return `${company}_${title}`.replace(/[\s\/]/g, '_').substring(0, 50);
  }

  // 去重
  deduplicateJobs() {
    const seen = new Set();
    this.jobs = this.jobs.filter(job => {
      if (seen.has(job.jobId)) {
        return false;
      }
      seen.add(job.jobId);
      return true;
    });
  }
}

// 导出为全局变量
window.BossJobScraper = JobScraper;
