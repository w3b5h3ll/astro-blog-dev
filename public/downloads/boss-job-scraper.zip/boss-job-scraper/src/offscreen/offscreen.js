// Offscreen Document Script
// 用于在后台 iframe 中加载职位详情页并提取数据

console.log('[Offscreen] Offscreen document 已加载');

// 监听来自 background worker 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Offscreen] 收到消息:', message.action);

  if (message.action === 'scrapeJobDetail') {
    // 在 iframe 中加载职位详情页并提取数据
    scrapeJobDetailInIframe(message.url, message.selectors)
      .then(data => {
        console.log('[Offscreen] 提取成功:', data);
        sendResponse({ success: true, data });
      })
      .catch(error => {
        console.error('[Offscreen] 提取失败:', error);
        sendResponse({ success: false, error: error.message });
      });

    return true; // 保持消息通道开放（异步响应）
  }

  if (message.action === 'ping') {
    sendResponse({ success: true, message: 'pong' });
    return true;
  }
});

/**
 * 在 iframe 中加载职位详情页并提取数据
 * @param {string} url - 职位详情页 URL
 * @param {object} selectors - 字段选择器配置
 * @returns {Promise<object>} 提取的数据
 */
async function scrapeJobDetailInIframe(url, selectors = {}) {
  const iframe = document.getElementById('scraper-iframe');

  return new Promise((resolve, reject) => {
    let resolved = false;

    // 15秒超时
    const timeout = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        iframe.src = 'about:blank'; // 停止加载
        reject(new Error('页面加载超时 (15秒)'));
      }
    }, 15000);

    // 监听加载完成
    iframe.onload = async () => {
      if (resolved) return;

      console.log('[Offscreen] iframe 加载完成，等待内容渲染...');

      try {
        // 等待动态内容渲染（最多5秒）
        const hasContent = await waitForContent(iframe.contentDocument, selectors);

        if (!hasContent) {
          console.warn('[Offscreen] 页面内容加载不完整');
        }

        // 提取数据
        const data = extractDataFromDocument(iframe.contentDocument, selectors);

        // 清理
        clearTimeout(timeout);
        resolved = true;
        iframe.src = 'about:blank';

        resolve(data);

      } catch (error) {
        clearTimeout(timeout);
        resolved = true;
        iframe.src = 'about:blank';
        reject(error);
      }
    };

    // 监听加载错误
    iframe.onerror = (error) => {
      if (resolved) return;

      clearTimeout(timeout);
      resolved = true;
      iframe.src = 'about:blank';
      reject(new Error('页面加载失败: ' + error.message));
    };

    // 开始加载
    console.log('[Offscreen] 开始加载:', url);
    iframe.src = url;
  });
}

/**
 * 等待页面内容渲染完成
 * @param {Document} doc - iframe 的 document
 * @param {object} selectors - 字段选择器配置
 * @returns {Promise<boolean>} 是否成功检测到内容
 */
async function waitForContent(doc, selectors) {
  const maxWait = 5000; // 最多等待5秒
  const startTime = Date.now();

  // 如果没有配置选择器，直接等待1秒后返回
  if (!selectors || Object.keys(selectors).length === 0) {
    await sleep(1000);
    return true;
  }

  // 提取所有选择器值
  const selectorList = Object.values(selectors).filter(s => s && s.length > 0);

  if (selectorList.length === 0) {
    await sleep(1000);
    return true;
  }

  // 轮询检查是否有至少一个选择器匹配到了元素
  while (Date.now() - startTime < maxWait) {
    let foundAny = false;

    for (const selector of selectorList) {
      try {
        const element = doc.querySelector(selector);
        if (element && element.textContent.trim().length > 0) {
          foundAny = true;
          break;
        }
      } catch (error) {
        // 选择器可能无效，忽略
        console.warn('[Offscreen] 选择器无效:', selector);
      }
    }

    if (foundAny) {
      console.log('[Offscreen] 检测到页面内容已加载');
      // 再等待1秒确保完全渲染
      await sleep(1000);
      return true;
    }

    // 等待100ms后再检查
    await sleep(100);
  }

  console.warn('[Offscreen] 等待内容超时，继续提取');
  return false;
}

/**
 * 从文档中提取数据
 * @param {Document} doc - iframe 的 document
 * @param {object} selectors - 字段选择器配置
 * @returns {object} 提取的数据
 */
function extractDataFromDocument(doc, selectors) {
  const data = {};

  console.log('[Offscreen] 开始提取数据，选择器配置:', selectors);

  // 使用配置的选择器提取字段
  for (const [field, selector] of Object.entries(selectors)) {
    if (!selector || selector.length === 0) {
      continue;
    }

    try {
      const element = doc.querySelector(selector);

      if (!element) {
        console.warn(`[Offscreen] 字段 ${field} 的选择器未找到元素: ${selector}`);
        continue;
      }

      // 特殊处理：福利待遇（可能是列表）
      if (field === 'welfare') {
        // 尝试获取子元素列表
        const items = element.querySelectorAll('*');
        if (items.length > 0) {
          const texts = Array.from(items)
            .map(el => el.textContent.trim())
            .filter(t => t.length > 0 && t.length < 50);

          if (texts.length > 0) {
            data[field] = texts;
          } else {
            data[field] = [element.textContent.trim()];
          }
        } else {
          data[field] = [element.textContent.trim()];
        }
      }
      // 普通字段：直接提取文本
      else {
        const value = element.textContent.trim();

        if (value.length > 0) {
          data[field] = value;
        } else {
          console.warn(`[Offscreen] 字段 ${field} 的值为空`);
        }
      }

      console.log(`[Offscreen] 提取字段 ${field}:`, data[field]);

    } catch (error) {
      console.error(`[Offscreen] 提取字段 ${field} 失败:`, error);
    }
  }

  console.log('[Offscreen] 提取完成，数据:', data);
  return data;
}

/**
 * 延迟函数
 * @param {number} ms - 延迟毫秒数
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

console.log('[Offscreen] 等待接收抓取任务...');
