/**
 * 控制组件模块
 * 处理所有按钮控制逻辑
 */

import { state, setSelectedSelector, resetScrapingState, resetDeepScrapingState, setConfiguringField } from '../state/index.js';
import { saveSelectedSelector } from '../services/storage.js';
import {
  activateSelector,
  startScraping,
  stopScraping,
  startDeepScraping,
  pauseDeepScraping,
  resumeDeepScraping,
  configureDetailField,
  configureListField,
  testDetailConfig,
  testListConfig
} from '../services/scraping.js';
import { validateScrapingConfig, validateDeepScrapingConfig } from '../services/validation.js';

// DOM 元素引用
let elements = {};

/**
 * 初始化控制组件
 */
export function initControls(domElements) {
  elements = domElements;
  bindControlEvents();
}

/**
 * 绑定控制按钮事件
 */
function bindControlEvents() {
  elements.selectBtn.addEventListener('click', handleSelectClick);
  elements.startBtn.addEventListener('click', handleStartClick);
  elements.stopBtn.addEventListener('click', handleStopClick);
  elements.deepScrapeBtn.addEventListener('click', handleDeepScrapeClick);
  elements.pauseDeepBtn.addEventListener('click', handlePauseDeepClick);

  // 绑定详情页配置按钮
  document.querySelectorAll('.btn-config').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const field = e.target.getAttribute('data-field');
      handleConfigureField(field);
    });
  });

  document.querySelectorAll('.btn-clear').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const field = e.target.getAttribute('data-field');
      handleClearFieldConfig(field);
    });
  });

  document.getElementById('test-config-btn')?.addEventListener('click', handleTestConfig);

  // 绑定列表页配置按钮
  document.querySelectorAll('.btn-config-list').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const field = e.target.getAttribute('data-field');
      handleConfigureListField(field);
    });
  });

  document.querySelectorAll('.btn-clear-list').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const field = e.target.getAttribute('data-field');
      handleClearListFieldConfig(field);
    });
  });

  document.getElementById('test-list-config-btn')?.addEventListener('click', handleTestListConfig);
}

/**
 * 处理选择按钮点击
 */
async function handleSelectClick() {
  console.log('[Controls] 点击选择按钮');

  // 动态导入调试组件
  const { addLog } = await import('../components/debug.js');
  addLog('info', '准备激活元素选择器...');

  try {
    const response = await activateSelector();
    console.log('[Controls] 收到响应:', response);
    addLog('success', '选择器已激活，请在页面上选择元素');
    elements.statusText.textContent = '请在页面上选择元素...';
  } catch (error) {
    console.error('[Controls] 激活选择器失败:', error);
    addLog('error', '激活选择器失败: ' + error.message);
    alert('激活选择器失败，请刷新页面后重试\n\n错误信息: ' + error.message);
  }
}

/**
 * 处理开始采集按钮点击
 */
async function handleStartClick() {
  console.log('[Controls] 点击开始采集');

  const { addLog } = await import('../components/debug.js');
  const { updateProgress } = await import('../components/progress.js');

  addLog('info', '开始采集...');

  if (state.isScraping) {
    return;
  }

  // 获取配置
  const config = getScrapingConfig();

  // 验证配置
  const validation = validateScrapingConfig(config);
  if (!validation.isValid) {
    alert('配置错误:\n' + validation.errors.join('\n'));
    return;
  }

  // 更新UI状态
  updateScrapingUI(true);
  updateProgress(0, '准备采集...');

  if (config.enableLimit) {
    addLog('info', `配置: 去重=${config.autoDedupe}, 延迟=${config.scrollDelay}ms, 限制数量=${config.limitNumber}`);
  } else {
    addLog('info', `配置: 去重=${config.autoDedupe}, 延迟=${config.scrollDelay}ms, 无限制`);
  }

  try {
    await startScraping(config);
    elements.statusText.textContent = '正在采集...';
  } catch (error) {
    console.error('[Controls] 开始采集失败:', error);
    addLog('error', '开始采集失败: ' + error.message);
    alert('开始采集失败: ' + error.message);
    resetScrapingUI();
  }
}

/**
 * 处理停止采集按钮点击
 */
async function handleStopClick() {
  console.log('[Controls] 点击停止采集');

  const { addLog } = await import('../components/debug.js');
  addLog('warning', '用户请求停止采集');

  try {
    await stopScraping();
    elements.statusText.textContent = '正在停止...';
    elements.stopBtn.disabled = true;
  } catch (error) {
    console.error('[Controls] 停止采集失败:', error);
    addLog('error', '停止采集失败: ' + error.message);
    alert('停止采集失败: ' + error.message);
  }
}

/**
 * 处理深度采集按钮点击
 */
async function handleDeepScrapeClick() {
  console.log('[Controls] 点击深度采集');

  const { addLog } = await import('../components/debug.js');
  const { updateProgress } = await import('../components/progress.js');
  const { getDetailFieldName } = await import('../state/index.js');

  addLog('info', '开始深度采集详情页...');

  if (state.scrapedJobs.length === 0) {
    alert('请先完成基础采集');
    return;
  }

  // 检查是否配置了字段
  if (Object.keys(state.detailFieldSelectors).length === 0) {
    const confirmed = confirm('您还没有配置详情页字段！\n\n是否继续？（将只更新已配置的字段）');
    if (!confirmed) return;
  }

  // 获取配置
  const config = getDeepScrapingConfig();

  // 验证配置
  const validation = validateDeepScrapingConfig(config);
  if (!validation.isValid) {
    alert('配置错误:\n' + validation.errors.join('\n'));
    return;
  }

  // 更新UI状态
  updateDeepScrapingUI(true);
  updateProgress(0, '准备深度采集...');

  const configuredFields = Object.keys(state.detailFieldSelectors).map(getDetailFieldName).join(', ');
  addLog('info', `深度采集配置: 随机延迟=${config.randomDelay}, AI验证=${config.enableAIValidation}, 正则验证=${config.enableBasicValidation}, 基础延迟=${config.detailDelay}ms, 职位数=${config.jobs.length}`);
  if (configuredFields) {
    addLog('info', `已配置字段: ${configuredFields}`);
  }

  try {
    await startDeepScraping(config);
    elements.statusText.textContent = '正在深度采集...';
  } catch (error) {
    console.error('[Controls] 深度采集失败:', error);
    addLog('error', '深度采集失败: ' + error.message);
    alert('深度采集失败: ' + error.message);
    resetDeepScrapingUI();
  }
}

/**
 * 处理暂停/继续深度采集
 */
async function handlePauseDeepClick() {
  const { addLog } = await import('../components/debug.js');

  try {
    if (state.deepScrapePaused) {
      // 继续
      addLog('info', '继续深度采集');
      await resumeDeepScraping();
      state.deepScrapePaused = false;
      elements.pauseDeepBtn.innerHTML = '<span class="btn-icon">⏸</span><span>暂停深度采集</span>';
    } else {
      // 暂停
      addLog('warning', '暂停深度采集');
      await pauseDeepScraping();
      state.deepScrapePaused = true;
      elements.pauseDeepBtn.innerHTML = '<span class="btn-icon">▶</span><span>继续深度采集</span>';
    }
  } catch (error) {
    console.error('[Controls] 暂停/继续失败:', error);
    addLog('error', '操作失败: ' + error.message);
  }
}

/**
 * 处理字段配置
 */
async function handleConfigureField(field) {
  console.log('[Controls] 配置字段:', field);

  const { addLog } = await import('../components/debug.js');
  const { getDetailFieldName } = await import('../state/index.js');

  addLog('info', `开始配置: ${getDetailFieldName(field)}`);

  const fieldNames = {
    salary: '薪资范围',
    description: '职位描述',
    welfare: '福利待遇',
    hrActivity: 'HR活跃状态',
    companySize: '公司规模',
    industry: '所属行业'
  };

  try {
    setConfiguringField(field);
    await configureDetailField(field, fieldNames[field]);
    elements.statusText.textContent = `配置中: ${fieldNames[field]}...`;
  } catch (error) {
    console.error('[Controls] 配置字段失败:', error);
    addLog('error', '配置失败: ' + error.message);
    alert('配置失败: ' + error.message);
  }
}

/**
 * 处理清除字段配置
 */
async function handleClearFieldConfig(field) {
  const { getDetailFieldName, removeDetailFieldSelector } = await import('../state/index.js');
  const { saveDetailFieldSelectors } = await import('../services/storage.js');
  const { addLog } = await import('../components/debug.js');
  const { updateFieldConfigUI } = await import('../components/settings.js');

  if (confirm(`确定要清除 ${getDetailFieldName(field)} 的配置吗？`)) {
    removeDetailFieldSelector(field);
    await saveDetailFieldSelectors(state.detailFieldSelectors);
    updateFieldConfigUI();
    addLog('warning', `已清除: ${getDetailFieldName(field)}`);
  }
}

/**
 * 处理测试配置
 */
async function handleTestConfig() {
  console.log('[Controls] 测试配置');

  const { addLog } = await import('../components/debug.js');
  addLog('info', '测试当前配置...');

  if (Object.keys(state.detailFieldSelectors).length === 0) {
    alert('请先配置至少一个字段！');
    return;
  }

  try {
    await testDetailConfig(state.detailFieldSelectors);
  } catch (error) {
    console.error('[Controls] 测试失败:', error);
    addLog('error', '测试失败: ' + error.message);
    alert('测试失败: ' + error.message);
  }
}

/**
 * 处理列表页字段配置
 */
async function handleConfigureListField(field) {
  console.log('[Controls] 配置列表页字段:', field);

  const { addLog } = await import('../components/debug.js');
  const { getListFieldName } = await import('../state/index.js');

  addLog('info', `开始配置列表字段: ${getListFieldName(field)}`);

  const fieldNames = {
    title: '职位名称',
    company: '公司名称',
    salary: '薪资范围',
    location: '工作地点',
    experience: '工作经验',
    education: '学历要求'
  };

  try {
    await configureListField(field, fieldNames[field]);
    elements.statusText.textContent = `配置列表字段: ${fieldNames[field]}...`;
  } catch (error) {
    console.error('[Controls] 配置列表字段失败:', error);
    addLog('error', '配置失败: ' + error.message);
    alert('配置失败: ' + error.message);
  }
}

/**
 * 处理清除列表页字段配置
 */
async function handleClearListFieldConfig(field) {
  const { getListFieldName, removeListFieldSelector } = await import('../state/index.js');
  const { saveListFieldSelectors } = await import('../services/storage.js');
  const { addLog } = await import('../components/debug.js');
  const { updateListFieldConfigUI } = await import('../components/settings.js');

  if (confirm(`确定要清除 ${getListFieldName(field)} 的配置吗？`)) {
    removeListFieldSelector(field);
    await saveListFieldSelectors(state.listFieldSelectors);
    updateListFieldConfigUI();
    addLog('warning', `已清除列表字段: ${getListFieldName(field)}`);
  }
}

/**
 * 处理测试列表页配置
 */
async function handleTestListConfig() {
  console.log('[Controls] 测试列表页配置');

  const { addLog } = await import('../components/debug.js');
  addLog('info', '测试列表页配置...');

  if (Object.keys(state.listFieldSelectors).length === 0) {
    alert('请先配置至少一个列表字段！');
    return;
  }

  try {
    await testListConfig(state.listFieldSelectors, state.selectedSelector);
  } catch (error) {
    console.error('[Controls] 测试失败:', error);
    addLog('error', '测试失败: ' + error.message);
    alert('测试失败: ' + error.message);
  }
}

/**
 * 获取采集配置
 */
function getScrapingConfig() {
  return {
    autoDedupe: elements.autoDedupe.checked,
    scrollDelay: parseInt(elements.scrollDelay.value) || 1000,
    listFieldSelectors: state.listFieldSelectors,
    enableLimit: elements.enableLimit?.checked || false,
    limitNumber: parseInt(elements.limitNumber?.value) || 10
  };
}

/**
 * 获取深度采集配置
 */
function getDeepScrapingConfig() {
  return {
    randomDelay: elements.randomDelay.checked,
    enableAIValidation: elements.enableAIValidation?.checked !== false,
    enableBasicValidation: elements.enableBasicValidation?.checked || false,
    detailDelay: parseInt(elements.detailDelay.value) || 2000,
    jobs: state.scrapedJobs,
    detailSelectors: state.detailFieldSelectors
  };
}

/**
 * 更新采集UI状态
 */
function updateScrapingUI(isScraping) {
  state.isScraping = isScraping;
  elements.startBtn.disabled = isScraping;
  elements.startBtn.style.display = isScraping ? 'none' : 'inline-flex';
  elements.stopBtn.style.display = isScraping ? 'inline-flex' : 'none';
  elements.exportBtn.disabled = isScraping;

  if (isScraping) {
    elements.progressSection.style.display = 'block';
  }
}

/**
 * 重置采集UI状态
 */
function resetScrapingUI() {
  resetScrapingState();
  updateScrapingUI(false);
  elements.stopBtn.disabled = false;
  elements.progressSection.style.display = 'none';

  if (state.scrapedJobs.length === 0) {
    elements.statusText.textContent = '采集失败';
  }
}

/**
 * 更新深度采集UI状态
 */
function updateDeepScrapingUI(isDeepScraping) {
  state.isDeepScraping = isDeepScraping;
  state.deepScrapePaused = false;
  elements.deepScrapeBtn.disabled = isDeepScraping;
  elements.deepScrapeBtn.style.display = isDeepScraping ? 'none' : 'inline-flex';
  elements.pauseDeepBtn.style.display = isDeepScraping ? 'inline-flex' : 'none';
  elements.pauseDeepBtn.textContent = '⏸ 暂停深度采集';
  elements.exportBtn.disabled = isDeepScraping;

  if (isDeepScraping) {
    elements.progressSection.style.display = 'block';
  }
}

/**
 * 重置深度采集UI状态
 */
function resetDeepScrapingUI() {
  resetDeepScrapingState();
  updateDeepScrapingUI(false);
}

/**
 * 更新选择器状态
 */
export function updateSelectorStatus(selector, count) {
  elements.statusText.textContent = '已选择区域';
  elements.selectorInfo.textContent = `选择器: ${selector.substring(0, 50)}${selector.length > 50 ? '...' : ''}`;

  if (count) {
    elements.selectorInfo.textContent += ` (${count} 个元素)`;
  }
}

/**
 * 处理选择器确认
 */
export async function handleSelectorConfirmed(message) {
  console.log('[Controls] 选择器已确认:', message.selector);

  setSelectedSelector(message.selector);
  await saveSelectedSelector(message.selector);
  updateSelectorStatus(message.selector, message.elementsCount);
  elements.startBtn.disabled = false;
}

/**
 * 处理选择器取消
 */
export function handleSelectorCancelled() {
  console.log('[Controls] 选择器已取消');
  elements.statusText.textContent = '已取消选择';
}