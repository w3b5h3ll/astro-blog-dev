/**
 * 调试组件模块
 * 处理调试面板逻辑、日志添加和显示
 */

// DOM 元素引用
let elements = {};

// 调试日志数组
let debugLogs = [];

// 日志类型配置
const LOG_TYPES = {
  info: { color: '#4299e1', icon: 'ℹ️' },
  success: { color: '#48bb78', icon: '✅' },
  warning: { color: '#ed8936', icon: '⚠️' },
  error: { color: '#f56565', icon: '❌' }
};

// 最大日志条数
const MAX_LOGS = 100;

/**
 * 初始化调试组件
 */
export function initDebug(domElements) {
  elements = domElements;
  bindDebugEvents();
}

/**
 * 绑定调试相关事件
 */
function bindDebugEvents() {
  if (elements.toggleDebug) {
    elements.toggleDebug.addEventListener('click', toggleDebugPanel);
  }

  // 可以添加其他调试相关的事件监听
  // 例如：清除日志、导出日志等
}

/**
 * 添加调试日志
 */
export function addLog(type, message) {
  const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  const log = {
    type: type || 'info',
    message: message || '',
    time: time,
    timestamp: Date.now()
  };

  debugLogs.push(log);

  // 限制日志数量
  if (debugLogs.length > MAX_LOGS) {
    debugLogs.shift();
  }

  // 更新显示
  updateDebugDisplay();

  // 同时输出到控制台
  logToConsole(log);
}

/**
 * 输出日志到控制台
 */
function logToConsole(log) {
  const message = `[${log.time}] ${log.message}`;

  switch (log.type) {
    case 'error':
      console.error(message);
      break;
    case 'warning':
      console.warn(message);
      break;
    case 'success':
      console.log(`%c${message}`, 'color: #48bb78');
      break;
    case 'info':
    default:
      console.log(message);
      break;
  }
}

/**
 * 更新调试面板显示
 */
export function updateDebugDisplay() {
  if (!elements.debugLogs || elements.debugLogs.style.display === 'none') {
    return; // 如果面板是隐藏的，不更新
  }

  elements.debugLogs.innerHTML = debugLogs.map(log => {
    const logConfig = LOG_TYPES[log.type] || LOG_TYPES.info;
    return `<div class="debug-log-item" data-type="${log.type}">
      <span class="log-time">[${log.time}]</span>
      <span class="log-icon" style="color: ${logConfig.color}">${logConfig.icon}</span>
      <span class="log-message log-${log.type}" style="color: ${logConfig.color}">${log.message}</span>
    </div>`;
  }).join('');

  // 自动滚动到底部
  elements.debugLogs.scrollTop = elements.debugLogs.scrollHeight;
}

/**
 * 切换调试面板
 */
export function toggleDebugPanel() {
  if (!elements.debugLogs || !elements.toggleDebug) {
    return;
  }

  if (elements.debugLogs.style.display === 'none') {
    showDebugPanel();
  } else {
    hideDebugPanel();
  }
}

/**
 * 显示调试面板
 */
export function showDebugPanel() {
  if (elements.debugLogs && elements.toggleDebug) {
    elements.debugLogs.style.display = 'block';
    elements.toggleDebug.textContent = '收起';
    updateDebugDisplay();
  }
}

/**
 * 隐藏调试面板
 */
export function hideDebugPanel() {
  if (elements.debugLogs && elements.toggleDebug) {
    elements.debugLogs.style.display = 'none';
    elements.toggleDebug.textContent = '展开';
  }
}

/**
 * 清除所有日志
 */
export function clearLogs() {
  debugLogs = [];
  updateDebugDisplay();
  addLog('info', '日志已清除');
}

/**
 * 获取所有日志
 */
export function getLogs() {
  return [...debugLogs];
}

/**
 * 按类型获取日志
 */
export function getLogsByType(type) {
  return debugLogs.filter(log => log.type === type);
}

/**
 * 获取最近的日志
 */
export function getRecentLogs(count = 10) {
  return debugLogs.slice(-count);
}

/**
 * 导出日志到文本文件
 */
export function exportLogs() {
  try {
    const logText = debugLogs.map(log =>
      `[${log.time}] [${log.type.toUpperCase()}] ${log.message}`
    ).join('\n');

    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `boss-scraper-logs-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    URL.revokeObjectURL(url);

    addLog('success', '日志已导出到文件');
  } catch (error) {
    addLog('error', '导出日志失败: ' + error.message);
  }
}

/**
 * 设置日志级别过滤
 */
export function setLogLevelFilter(levels) {
  const logItems = elements.debugLogs?.querySelectorAll('.debug-log-item');
  if (!logItems) return;

  logItems.forEach(item => {
    const type = item.getAttribute('data-type');
    if (levels.includes(type)) {
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  });
}

/**
 * 搜索日志
 */
export function searchLogs(query) {
  if (!query) {
    updateDebugDisplay();
    return;
  }

  const filteredLogs = debugLogs.filter(log =>
    log.message.toLowerCase().includes(query.toLowerCase()) ||
    log.type.toLowerCase().includes(query.toLowerCase())
  );

  if (elements.debugLogs) {
    elements.debugLogs.innerHTML = filteredLogs.map(log => {
      const logConfig = LOG_TYPES[log.type] || LOG_TYPES.info;
      const highlightedMessage = log.message.replace(
        new RegExp(query, 'gi'),
        `<mark>$&</mark>`
      );

      return `<div class="debug-log-item" data-type="${log.type}">
        <span class="log-time">[${log.time}]</span>
        <span class="log-icon" style="color: ${logConfig.color}">${logConfig.icon}</span>
        <span class="log-message log-${log.type}" style="color: ${logConfig.color}">${highlightedMessage}</span>
      </div>`;
    }).join('');
  }
}

/**
 * 获取日志统计
 */
export function getLogStats() {
  const stats = {
    total: debugLogs.length,
    info: 0,
    success: 0,
    warning: 0,
    error: 0
  };

  debugLogs.forEach(log => {
    if (stats.hasOwnProperty(log.type)) {
      stats[log.type]++;
    }
  });

  return stats;
}

/**
 * 处理来自 content script 的日志消息
 */
export function handleRemoteLog(message) {
  if (message.logType && message.logMessage) {
    addLog(message.logType, message.logMessage);
  }
}