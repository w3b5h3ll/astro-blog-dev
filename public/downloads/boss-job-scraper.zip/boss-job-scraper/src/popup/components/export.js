/**
 * 导出组件模块
 * 包含 ExcelExporter 类及相关导出逻辑
 */

import { state } from '../state/index.js';
import { validateExportData } from '../services/validation.js';

// DOM 元素引用
let elements = {};

/**
 * 初始化导出组件
 */
export function initExport(domElements) {
  elements = domElements;
  bindExportEvents();
}

/**
 * 绑定导出相关事件
 */
function bindExportEvents() {
  if (elements.exportBtn) {
    elements.exportBtn.addEventListener('click', handleExportClick);
  }
}

/**
 * 处理导出按钮点击
 */
async function handleExportClick() {
  console.log('[Export] 点击导出按钮');

  if (state.scrapedJobs.length === 0) {
    alert('没有可导出的数据');
    return;
  }

  // 验证导出数据
  const validation = validateExportData(state.scrapedJobs);
  if (!validation.isValid) {
    alert('导出数据验证失败:\n' + validation.errors.join('\n'));
    return;
  }

  // 显示警告信息
  if (validation.warnings && validation.warnings.length > 0) {
    const showWarnings = confirm(
      '数据验证发现以下问题：\n' +
      validation.warnings.slice(0, 5).join('\n') +
      (validation.warnings.length > 5 ? '\n... 等更多问题' : '') +
      '\n\n是否继续导出？'
    );

    if (!showWarnings) {
      return;
    }
  }

  try {
    // 更新按钮状态
    setExportButtonLoading(true);

    const exporter = new ExcelExporter(state.scrapedJobs);
    await exporter.exportToExcel();

    setExportButtonSuccess();

  } catch (error) {
    console.error('[Export] 导出失败:', error);
    alert('导出失败: ' + error.message);
    setExportButtonError();
  }
}

/**
 * Excel 导出类
 */
export class ExcelExporter {
  constructor(jobs) {
    this.jobs = jobs;
  }

  async exportToExcel() {
    console.log('[ExcelExporter] 开始导出 Excel...');

    // 加载 SheetJS 库
    const XLSX = await this.loadXLSX();

    // 格式化数据
    const data = this.formatData();

    // 创建工作表
    const ws = XLSX.utils.json_to_sheet(data);

    // 设置列宽
    ws['!cols'] = this.getColumnWidths();

    // 创建工作簿
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Boss直聘职位');

    // 导出文件
    const filename = `Boss直聘职位_${this.getDateString()}.xlsx`;
    XLSX.writeFile(wb, filename);

    console.log('[ExcelExporter] 导出完成:', filename);
  }

  formatData() {
    return this.jobs.map(job => ({
      '职位名称': job.title || '',
      '公司名称': job.company || '',
      '薪资范围': job.salary || '',
      '工作地点': job.location || '',
      '工作经验': job.experience || '',
      '学历要求': job.education || '',
      '职位描述': job.description || '',
      '福利待遇': this.formatWelfare(job.welfare),
      'HR活跃状态': job.hrActivity || '',
      '公司规模': job.companySize || '',
      '所属行业': job.industry || '',
      '职位链接': job.jobUrl || '',
      '采集时间': this.formatDate(job.scrapedAt)
    }));
  }

  formatWelfare(welfare) {
    if (Array.isArray(welfare)) {
      return welfare.join(', ');
    }
    return welfare || '';
  }

  formatDate(dateString) {
    if (!dateString) return '';

    try {
      return new Date(dateString).toLocaleString('zh-CN');
    } catch (error) {
      return dateString;
    }
  }

  getColumnWidths() {
    return [
      { wch: 25 }, // 职位名称
      { wch: 20 }, // 公司名称
      { wch: 15 }, // 薪资范围
      { wch: 20 }, // 工作地点
      { wch: 12 }, // 工作经验
      { wch: 10 }, // 学历要求
      { wch: 60 }, // 职位描述
      { wch: 35 }, // 福利待遇
      { wch: 18 }, // HR活跃状态
      { wch: 12 }, // 公司规模
      { wch: 15 }, // 所属行业
      { wch: 50 }, // 职位链接
      { wch: 18 }  // 采集时间
    ];
  }

  async loadXLSX() {
    return new Promise((resolve, reject) => {
      if (window.XLSX) {
        resolve(window.XLSX);
        return;
      }

      const script = document.createElement('script');
      script.src = '../../assets/libs/xlsx.full.min.js';
      script.onload = () => {
        console.log('[ExcelExporter] SheetJS 加载成功');
        resolve(window.XLSX);
      };
      script.onerror = () => {
        reject(new Error('加载 SheetJS 失败'));
      };
      document.head.appendChild(script);
    });
  }

  getDateString() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hour = String(now.getHours()).padStart(2, '0');
    const minute = String(now.getMinutes()).padStart(2, '0');
    return `${year}${month}${day}_${hour}${minute}`;
  }
}

/**
 * 设置导出按钮为加载状态
 */
function setExportButtonLoading(loading = true) {
  if (!elements.exportBtn) return;

  if (loading) {
    elements.exportBtn.disabled = true;
    elements.exportBtn.textContent = '导出中...';
  } else {
    elements.exportBtn.disabled = false;
    elements.exportBtn.innerHTML = '<span class="btn-icon">📥</span><span>导出 Excel</span>';
  }
}

/**
 * 设置导出按钮为成功状态
 */
function setExportButtonSuccess() {
  if (!elements.exportBtn) return;

  elements.exportBtn.textContent = '✅ 导出成功';
  setTimeout(() => {
    setExportButtonLoading(false);
  }, 2000);
}

/**
 * 设置导出按钮为错误状态
 */
function setExportButtonError() {
  if (!elements.exportBtn) return;

  elements.exportBtn.textContent = '❌ 导出失败';
  setTimeout(() => {
    setExportButtonLoading(false);
  }, 2000);
}

/**
 * 导出为 JSON 格式
 */
export async function exportToJSON() {
  if (state.scrapedJobs.length === 0) {
    throw new Error('没有可导出的数据');
  }

  const jsonData = JSON.stringify(state.scrapedJobs, null, 2);
  const blob = new Blob([jsonData], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `Boss直聘职位_${getDateString()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  URL.revokeObjectURL(url);
}

/**
 * 导出为 CSV 格式
 */
export async function exportToCSV() {
  if (state.scrapedJobs.length === 0) {
    throw new Error('没有可导出的数据');
  }

  const exporter = new ExcelExporter(state.scrapedJobs);
  const data = exporter.formatData();

  // 生成 CSV 内容
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => headers.map(header => `"${(row[header] || '').toString().replace(/"/g, '""')}"`).join(','))
  ].join('\n');

  // 添加 BOM 以支持中文
  const bom = '\uFEFF';
  const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `Boss直聘职位_${getDateString()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  URL.revokeObjectURL(url);
}

/**
 * 获取日期字符串（辅助函数）
 */
function getDateString() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hour = String(now.getHours()).padStart(2, '0');
  const minute = String(now.getMinutes()).padStart(2, '0');
  return `${year}${month}${day}_${hour}${minute}`;
}