/**
 * 进度组件模块
 * 处理进度显示逻辑
 */

// DOM 元素引用
let elements = {};

/**
 * 初始化进度组件
 */
export function initProgress(domElements) {
  elements = domElements;
}

/**
 * 更新进度显示
 */
export function updateProgress(progress, status) {
  if (elements.progressFill) {
    elements.progressFill.style.width = progress + '%';
  }

  if (elements.progressText) {
    elements.progressText.textContent = status || `${progress}%`;
  }
}

/**
 * 显示进度条
 */
export function showProgress() {
  if (elements.progressSection) {
    elements.progressSection.style.display = 'block';
  }
}

/**
 * 隐藏进度条
 */
export function hideProgress() {
  if (elements.progressSection) {
    elements.progressSection.style.display = 'none';
  }
}

/**
 * 重置进度条
 */
export function resetProgress() {
  updateProgress(0, '准备中...');
}

/**
 * 设置进度条为完成状态
 */
export function setProgressComplete(message = '完成！') {
  updateProgress(100, message);
}

/**
 * 设置进度条为错误状态
 */
export function setProgressError(message = '错误') {
  if (elements.progressText) {
    elements.progressText.textContent = message;
    elements.progressText.style.color = '#f56565';
  }

  if (elements.progressFill) {
    elements.progressFill.style.backgroundColor = '#f56565';
  }
}

/**
 * 恢复进度条正常状态
 */
export function restoreProgressStyle() {
  if (elements.progressText) {
    elements.progressText.style.color = '';
  }

  if (elements.progressFill) {
    elements.progressFill.style.backgroundColor = '';
  }
}

/**
 * 更新职位数量显示
 */
export function updateJobCount(count) {
  if (elements.jobCount) {
    elements.jobCount.textContent = `${count} 条`;
  }
}

/**
 * 处理采集完成后的进度显示
 */
export async function handleScrapingCompleteProgress(message) {
  setProgressComplete('采集完成！');
  updateJobCount(message.count);

  // 延迟隐藏进度条
  setTimeout(() => {
    hideProgress();
    restoreProgressStyle();
  }, 3000);
}

/**
 * 处理深度采集进度
 */
export async function handleDeepScrapeProgress(message) {
  console.log('[Progress] 收到深度采集进度:', message);
  const { current, total, progress, job } = message;

  // 确保进度条可见
  showProgress();
  updateProgress(progress, `深度采集中 ${current}/${total}`);

  if (job) {
    // 动态导入 addLog 函数以避免循环依赖
    const { addLog } = await import('./debug.js');
    addLog('info', `[${current}/${total}] ${job.title} - ${job.company}`);

    // 实时更新数据
    if (message.updatedJob) {
      // 动态导入 state 以避免循环依赖
      const { state } = await import('../state/index.js');
      const index = state.scrapedJobs.findIndex(j => j.jobId === message.updatedJob.jobId);
      if (index !== -1) {
        state.scrapedJobs[index] = message.updatedJob;
      }
    }
  }
}

/**
 * 处理深度采集完成后的进度显示
 */
export async function handleDeepScrapeCompleteProgress(message) {
  setProgressComplete('深度采集完成！');

  // 延迟隐藏进度条
  setTimeout(() => {
    hideProgress();
    restoreProgressStyle();
  }, 3000);
}

/**
 * 处理采集停止后的进度显示
 */
export function handleScrapingStoppedProgress(message) {
  updateProgress(message.progress || 0, '已停止');
  updateJobCount(message.count);

  // 延迟隐藏进度条
  setTimeout(() => {
    hideProgress();
    restoreProgressStyle();
  }, 3000);
}

/**
 * 处理采集错误后的进度显示
 */
export function handleScrapingErrorProgress(error) {
  setProgressError('采集失败');

  // 延迟隐藏进度条
  setTimeout(() => {
    hideProgress();
    restoreProgressStyle();
  }, 3000);
}

/**
 * 创建进度条动画效果
 */
export function animateProgress(targetProgress, duration = 1000) {
  const currentProgress = parseInt(elements.progressFill?.style.width) || 0;
  const progressStep = (targetProgress - currentProgress) / (duration / 16);
  let currentStep = currentProgress;

  const animate = () => {
    currentStep += progressStep;

    if ((progressStep > 0 && currentStep >= targetProgress) ||
        (progressStep < 0 && currentStep <= targetProgress)) {
      currentStep = targetProgress;
    }

    updateProgress(Math.round(currentStep));

    if (currentStep !== targetProgress) {
      requestAnimationFrame(animate);
    }
  };

  requestAnimationFrame(animate);
}

/**
 * 获取当前进度值
 */
export function getCurrentProgress() {
  const width = elements.progressFill?.style.width || '0%';
  return parseInt(width.replace('%', ''));
}