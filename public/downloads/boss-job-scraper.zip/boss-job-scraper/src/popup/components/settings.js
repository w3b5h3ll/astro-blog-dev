/**
 * 设置组件模块
 * 处理设置面板逻辑和字段配置UI更新
 */

import { state } from '../state/index.js';

// DOM 元素引用
let elements = {};

/**
 * 初始化设置组件
 */
export function initSettings(domElements) {
  elements = domElements;
  bindSettingEvents();
}

/**
 * 绑定设置相关事件
 */
function bindSettingEvents() {
  // 绑定限制数量开关事件
  if (elements.enableLimit) {
    elements.enableLimit.addEventListener('change', (e) => {
      if (e.target.checked) {
        elements.limitNumberContainer.style.display = 'block';
      } else {
        elements.limitNumberContainer.style.display = 'none';
      }
    });
  }

  // 可以在这里添加其他设置项的事件监听
  // 例如：延迟设置、验证选项等
}

/**
 * 更新详情页字段配置UI
 */
export function updateFieldConfigUI() {
  const fields = ['salary', 'description', 'welfare', 'hrActivity', 'companySize', 'industry'];

  fields.forEach(field => {
    const statusEl = document.getElementById(`status-${field}`);
    const configBtn = document.querySelector(`.btn-config[data-field="${field}"]`);
    const clearBtn = document.querySelector(`.btn-clear[data-field="${field}"]`);

    if (statusEl && configBtn && clearBtn) {
      if (state.detailFieldSelectors[field]) {
        // 已配置
        statusEl.textContent = '✓ 已配置';
        statusEl.className = 'field-status configured';
        configBtn.textContent = '重新配置';
        clearBtn.style.display = 'inline-block';
      } else {
        // 未配置
        statusEl.textContent = '未配置';
        statusEl.className = 'field-status unconfigured';
        configBtn.textContent = '配置';
        clearBtn.style.display = 'none';
      }
    }
  });
}

/**
 * 更新列表页字段配置UI
 */
export function updateListFieldConfigUI() {
  const fields = ['title', 'company', 'location', 'experience', 'education'];

  fields.forEach(field => {
    const statusEl = document.getElementById(`status-list-${field}`);
    const configBtn = document.querySelector(`.btn-config-list[data-field="${field}"]`);
    const clearBtn = document.querySelector(`.btn-clear-list[data-field="${field}"]`);

    if (statusEl && configBtn && clearBtn) {
      if (state.listFieldSelectors[field]) {
        // 已配置
        statusEl.textContent = '✓ 已配置';
        statusEl.className = 'field-status configured';
        configBtn.textContent = '重新配置';
        clearBtn.style.display = 'inline-block';
      } else {
        // 未配置
        statusEl.textContent = '未配置';
        statusEl.className = 'field-status unconfigured';
        configBtn.textContent = '配置';
        clearBtn.style.display = 'none';
      }
    }
  });
}

/**
 * 获取当前采集设置
 */
export function getScrapingSettings() {
  return {
    autoDedupe: elements.autoDedupe?.checked || false,
    enableLimit: elements.enableLimit?.checked || false,
    limitNumber: parseInt(elements.limitNumber?.value) || 10,
    scrollDelay: parseInt(elements.scrollDelay?.value) || 1000,
    randomDelay: elements.randomDelay?.checked || false,
    enableAIValidation: elements.enableAIValidation?.checked !== false,
    enableBasicValidation: elements.enableBasicValidation?.checked || false,
    detailDelay: parseInt(elements.detailDelay?.value) || 2000
  };
}

/**
 * 设置采集设置
 */
export function setScrapingSettings(settings) {
  if (elements.autoDedupe && settings.autoDedupe !== undefined) {
    elements.autoDedupe.checked = settings.autoDedupe;
  }

  if (elements.enableLimit && settings.enableLimit !== undefined) {
    elements.enableLimit.checked = settings.enableLimit;
    // 触发change事件以更新UI
    if (settings.enableLimit) {
      elements.limitNumberContainer.style.display = 'block';
    } else {
      elements.limitNumberContainer.style.display = 'none';
    }
  }

  if (elements.limitNumber && settings.limitNumber !== undefined) {
    elements.limitNumber.value = settings.limitNumber;
  }

  if (elements.scrollDelay && settings.scrollDelay !== undefined) {
    elements.scrollDelay.value = settings.scrollDelay;
  }

  if (elements.randomDelay && settings.randomDelay !== undefined) {
    elements.randomDelay.checked = settings.randomDelay;
  }

  if (elements.enableAIValidation && settings.enableAIValidation !== undefined) {
    elements.enableAIValidation.checked = settings.enableAIValidation;
  }

  if (elements.enableBasicValidation && settings.enableBasicValidation !== undefined) {
    elements.enableBasicValidation.checked = settings.enableBasicValidation;
  }

  if (elements.detailDelay && settings.detailDelay !== undefined) {
    elements.detailDelay.value = settings.detailDelay;
  }
}

/**
 * 重置设置为默认值
 */
export function resetSettings() {
  setScrapingSettings({
    autoDedupe: true,
    enableLimit: false,
    limitNumber: 10,
    scrollDelay: 1000,
    randomDelay: false,
    enableAIValidation: true,
    enableBasicValidation: false,
    detailDelay: 2000
  });
}

/**
 * 验证设置值
 */
export function validateSettings() {
  const settings = getScrapingSettings();
  const errors = [];

  if (settings.scrollDelay < 100 || settings.scrollDelay > 10000) {
    errors.push('滚动延迟应在 100-10000ms 之间');
  }

  if (settings.detailDelay < 500 || settings.detailDelay > 30000) {
    errors.push('详情页延迟应在 500-30000ms 之间');
  }

  if (settings.enableLimit && (settings.limitNumber < 1 || settings.limitNumber > 1000)) {
    errors.push('限制数量应在 1-1000 之间');
  }

  return {
    isValid: errors.length === 0,
    errors: errors
  };
}

/**
 * 显示设置面板
 */
export function showSettingsPanel() {
  // 可以在这里实现设置面板的显示逻辑
  console.log('[Settings] 显示设置面板');
}

/**
 * 隐藏设置面板
 */
export function hideSettingsPanel() {
  // 可以在这里实现设置面板的隐藏逻辑
  console.log('[Settings] 隐藏设置面板');
}

/**
 * 切换高级设置
 */
export function toggleAdvancedSettings() {
  // 可以在这里实现高级设置的切换逻辑
  console.log('[Settings] 切换高级设置');
}