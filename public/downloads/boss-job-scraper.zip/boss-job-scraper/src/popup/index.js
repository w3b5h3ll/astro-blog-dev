/**
 * Boss 直聘采集器 - Popup 主入口
 * 模块化重构版本
 */

// 导入模块
import { state, updateState, setSelectedSelector, setScrapedJobs, addDetailFieldSelector, addListFieldSelector } from './state/index.js';
import { loadStoredState, saveScrapedJobs, saveDetailFieldSelectors, saveListFieldSelectors } from './services/storage.js';
import { pingContentScript } from './services/scraping.js';
import { validateBossUrl } from './services/validation.js';

// 导入组件
import { initControls, handleSelectorConfirmed, handleSelectorCancelled, updateSelectorStatus } from './components/controls.js';
import { initSettings, updateFieldConfigUI, updateListFieldConfigUI } from './components/settings.js';
import {
  initProgress,
  updateProgress,
  handleScrapingCompleteProgress,
  handleDeepScrapeProgress,
  handleDeepScrapeCompleteProgress,
  handleScrapingStoppedProgress,
  handleScrapingErrorProgress,
  updateJobCount
} from './components/progress.js';
import { initDebug, addLog, handleRemoteLog } from './components/debug.js';
import { initExport } from './components/export.js';

/**
 * DOM 元素定义
 */
const elements = {
  // 控制按钮
  selectBtn: document.getElementById('select-btn'),
  startBtn: document.getElementById('start-btn'),
  stopBtn: document.getElementById('stop-btn'),
  deepScrapeBtn: document.getElementById('deep-scrape-btn'),
  pauseDeepBtn: document.getElementById('pause-deep-btn'),
  exportBtn: document.getElementById('export-btn'),

  // 状态显示
  statusText: document.getElementById('status-text'),
  jobCount: document.getElementById('job-count'),
  selectorInfo: document.getElementById('selector-info'),

  // 进度条
  progressSection: document.getElementById('progress-section'),
  progressFill: document.getElementById('progress-fill'),
  progressText: document.getElementById('progress-text'),

  // 设置项
  autoDedupe: document.getElementById('auto-dedupe'),
  enableLimit: document.getElementById('enable-limit'),
  limitNumber: document.getElementById('limit-number'),
  limitNumberContainer: document.getElementById('limit-number-container'),
  scrollDelay: document.getElementById('scroll-delay'),
  randomDelay: document.getElementById('random-delay'),
  enableAIValidation: document.getElementById('enable-ai-validation'),
  enableBasicValidation: document.getElementById('enable-basic-validation'),
  detailDelay: document.getElementById('detail-delay'),

  // 调试面板
  toggleDebug: document.getElementById('toggle-debug'),
  debugLogs: document.getElementById('debug-logs'),

  // 测试按钮
  testSilentFetchBtn: document.getElementById('test-silent-fetch-btn')
};

/**
 * 主初始化函数
 */
async function init() {
  console.log('[Popup] 初始化模块化版本...');

  try {
    // 初始化各个组件模块
    initComponents();

    // 加载保存的状态
    await loadState();

    // 检查当前标签页
    await checkCurrentTab();

    // 监听来自 content script 的消息
    chrome.runtime.onMessage.addListener(handleMessage);

    // 添加初始日志
    addLog('info', '模块化侧边栏已加载');

    console.log('[Popup] 初始化完成');

  } catch (error) {
    console.error('[Popup] 初始化失败:', error);
    addLog('error', '初始化失败: ' + error.message);
  }
}

/**
 * 初始化各个组件模块
 */
function initComponents() {
  console.log('[Popup] 初始化组件...');

  // 初始化各个组件，传递对应的DOM元素
  initControls(elements);
  initSettings(elements);
  initProgress(elements);
  initDebug(elements);
  initExport(elements);

  // 添加测试静默抓取按钮事件
  if (elements.testSilentFetchBtn) {
    elements.testSilentFetchBtn.addEventListener('click', handleTestSilentFetch);
  }

  console.log('[Popup] 组件初始化完成');
}

/**
 * 加载保存的状态
 */
async function loadState() {
  console.log('[Popup] 加载保存的状态...');

  try {
    const storedData = await loadStoredState();

    // 更新全局状态
    if (storedData.selectedSelector) {
      setSelectedSelector(storedData.selectedSelector);
      updateSelectorStatus(storedData.selectedSelector);
      elements.startBtn.disabled = false;
      addLog('info', '已恢复选择器配置');
    }

    if (storedData.scrapedJobs && storedData.scrapedJobs.length > 0) {
      setScrapedJobs(storedData.scrapedJobs);
      updateJobCount(storedData.scrapedJobs.length);
      elements.exportBtn.disabled = false;
      elements.deepScrapeBtn.disabled = false;
      elements.deepScrapeBtn.style.display = 'inline-flex';
      addLog('info', `已恢复 ${storedData.scrapedJobs.length} 条职位数据`);
    }

    if (storedData.detailFieldSelectors) {
      updateState({ detailFieldSelectors: storedData.detailFieldSelectors });
      updateFieldConfigUI();
      const fieldCount = Object.keys(storedData.detailFieldSelectors).length;
      if (fieldCount > 0) {
        addLog('info', `已恢复 ${fieldCount} 个详情页字段配置`);
      }
    }

    if (storedData.listFieldSelectors) {
      updateState({ listFieldSelectors: storedData.listFieldSelectors });
      updateListFieldConfigUI();
      const fieldCount = Object.keys(storedData.listFieldSelectors).length;
      if (fieldCount > 0) {
        addLog('info', `已恢复 ${fieldCount} 个列表页字段配置`);
      }
    }

    console.log('[Popup] 状态加载完成');

  } catch (error) {
    console.error('[Popup] 加载状态失败:', error);
    addLog('warning', '加载保存的状态失败: ' + error.message);
  }
}

/**
 * 检查当前标签页
 */
async function checkCurrentTab() {
  console.log('[Popup] 检查当前标签页...');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // 验证是否为 Boss 直聘页面
    const urlValidation = validateBossUrl(tab.url);
    if (!urlValidation.isValid) {
      elements.statusText.textContent = '请在 Boss 直聘页面使用';
      elements.selectBtn.disabled = true;
      addLog('warning', urlValidation.error);
      return;
    }

    // 检查 content script 是否就绪
    const isContentReady = await pingContentScript();
    if (isContentReady) {
      console.log('[Popup] Content script 已就绪');
      addLog('success', 'Content script 连接成功');
    } else {
      console.warn('[Popup] Content script 未就绪');
      addLog('warning', 'Content script 未就绪，请刷新页面');
    }

  } catch (error) {
    console.error('[Popup] 检查标签页失败:', error);
    addLog('error', '检查页面状态失败: ' + error.message);
  }
}

/**
 * 处理来自 content script 的消息
 */
function handleMessage(message, sender, sendResponse) {
  console.log('[Popup] 收到消息:', message.action);

  try {
    switch (message.action) {
      // 选择器相关
      case 'selectorConfirmed':
        handleSelectorConfirmed(message);
        break;
      case 'selectorCancelled':
        handleSelectorCancelled();
        break;

      // 采集进度相关
      case 'updateProgress':
        updateProgress(message.progress, message.status);
        break;

      // 采集完成/错误相关
      case 'scrapingComplete':
        handleScrapingComplete(message);
        break;
      case 'scrapingError':
        handleScrapingError(message);
        break;
      case 'scrapingStopped':
        handleScrapingStopped(message);
        break;

      // 深度采集相关
      case 'deepScrapeProgress':
        handleDeepScrapeProgress(message);
        break;
      case 'deepScrapeComplete':
        handleDeepScrapeComplete(message);
        break;
      case 'deepScrapeError':
        handleDeepScrapeError(message);
        break;

      // 字段配置相关
      case 'detailFieldConfigured':
        handleDetailFieldConfigured(message);
        break;
      case 'detailFieldCancelled':
        handleDetailFieldCancelled();
        break;
      case 'testConfigResult':
        handleTestConfigResult(message);
        break;
      case 'listFieldConfigured':
        handleListFieldConfigured(message);
        break;
      case 'listFieldCancelled':
        handleListFieldCancelled();
        break;
      case 'testListConfigResult':
        handleTestListConfigResult(message);
        break;

      // 调试日志
      case 'debugLog':
        handleRemoteLog(message);
        break;

      default:
        console.warn('[Popup] 未知消息类型:', message.action);
        addLog('warning', `收到未知消息: ${message.action}`);
    }
  } catch (error) {
    console.error('[Popup] 处理消息失败:', error);
    addLog('error', `处理消息失败: ${error.message}`);
  }
}

/**
 * 处理采集完成
 */
async function handleScrapingComplete(message) {
  console.log('[Popup] 采集完成:', message.count, '条');

  setScrapedJobs(message.jobs);
  updateState({ isScraping: false });

  // 保存数据
  await saveScrapedJobs(message.jobs);

  // 更新UI
  await handleScrapingCompleteProgress(message);
  elements.statusText.textContent = '采集完成';
  elements.startBtn.disabled = false;
  elements.startBtn.style.display = 'inline-flex';
  elements.stopBtn.style.display = 'none';
  elements.exportBtn.disabled = false;

  // 显示深度采集按钮
  if (message.count > 0) {
    elements.deepScrapeBtn.disabled = false;
    elements.deepScrapeBtn.style.display = 'inline-flex';
    addLog('success', `采集完成 ${message.count} 条，可以进行深度采集`);
  }
}

/**
 * 处理采集错误
 */
function handleScrapingError(message) {
  console.error('[Popup] 采集错误:', message.error);
  addLog('error', '采集错误: ' + message.error);
  alert('采集失败: ' + message.error);
  resetScrapingState();
  handleScrapingErrorProgress(message.error);
}

/**
 * 处理采集停止
 */
async function handleScrapingStopped(message) {
  console.log('[Popup] 采集已停止:', message.count, '条');
  addLog('warning', `采集已停止，共采集 ${message.count} 条数据`);

  if (message.jobs && message.jobs.length > 0) {
    setScrapedJobs(message.jobs);
    await saveScrapedJobs(message.jobs);

    elements.exportBtn.disabled = false;
    elements.deepScrapeBtn.disabled = false;
    elements.deepScrapeBtn.style.display = 'inline-flex';

    addLog('success', `已保存 ${message.count} 条数据，可以导出或深度采集`);
  } else {
    addLog('warning', '没有采集到数据');
  }

  handleScrapingStoppedProgress(message);
  elements.statusText.textContent = `已停止 (已采集 ${message.count} 条)`;
  resetScrapingState(true);
}

/**
 * 处理深度采集完成
 */
async function handleDeepScrapeComplete(message) {
  console.log('[Popup] 深度采集完成:', message.count, '条');
  addLog('success', `深度采集完成！成功: ${message.successCount}, 失败: ${message.failCount}`);

  if (message.jobs && message.jobs.length > 0) {
    setScrapedJobs(message.jobs);
    await saveScrapedJobs(message.jobs);
  }

  await handleDeepScrapeCompleteProgress(message);
  elements.statusText.textContent = `深度采集完成 (${message.count} 条)`;
  resetDeepScrapingState();
}

/**
 * 处理深度采集错误
 */
function handleDeepScrapeError(message) {
  console.error('[Popup] 深度采集错误:', message.error);
  addLog('error', '深度采集错误: ' + message.error);
  alert('深度采集失败: ' + message.error);
  resetDeepScrapingState();
}

/**
 * 处理详情页字段配置完成
 */
async function handleDetailFieldConfigured(message) {
  const { field, selector } = message;
  console.log('[Popup] 字段配置完成:', field, selector);

  addDetailFieldSelector(field, selector);
  await saveDetailFieldSelectors(state.detailFieldSelectors);

  updateFieldConfigUI();

  const { getDetailFieldName } = await import('./state/index.js');
  addLog('success', `✓ ${getDetailFieldName(field)} 配置完成: ${selector.substring(0, 30)}...`);
  elements.statusText.textContent = `${getDetailFieldName(field)} 配置完成`;
}

/**
 * 处理详情页字段配置取消
 */
function handleDetailFieldCancelled() {
  console.log('[Popup] 字段配置已取消');
  updateState({ configuringField: null });
  elements.statusText.textContent = '配置已取消';
  addLog('warning', '配置已取消');
}

/**
 * 处理测试配置结果
 */
async function handleTestConfigResult(message) {
  const { results } = message;
  console.log('[Popup] 测试结果:', results);

  const { getDetailFieldName } = await import('./state/index.js');

  addLog('info', '=== 测试结果 ===');

  Object.entries(results).forEach(([field, value]) => {
    const fieldName = getDetailFieldName(field);
    if (value && value.length > 0) {
      const preview = Array.isArray(value) ? value.join(', ') : value;
      addLog('success', `✓ ${fieldName}: ${preview.substring(0, 50)}${preview.length > 50 ? '...' : ''}`);
    } else {
      addLog('error', `✗ ${fieldName}: 未提取到数据`);
    }
  });

  addLog('info', '=== 测试完成 ===');
}

/**
 * 处理列表页字段配置完成
 */
async function handleListFieldConfigured(message) {
  const { field, selector } = message;
  console.log('[Popup] 列表字段配置完成:', field, selector);

  addListFieldSelector(field, selector);
  await saveListFieldSelectors(state.listFieldSelectors);

  updateListFieldConfigUI();

  const { getListFieldName } = await import('./state/index.js');
  addLog('success', `✓ ${getListFieldName(field)} 配置完成: ${selector.substring(0, 30)}...`);
  elements.statusText.textContent = `${getListFieldName(field)} 配置完成`;
}

/**
 * 处理列表页字段配置取消
 */
function handleListFieldCancelled() {
  console.log('[Popup] 列表字段配置已取消');
  updateState({ configuringField: null });
  elements.statusText.textContent = '配置已取消';
  addLog('warning', '配置已取消');
}

/**
 * 处理测试列表配置结果
 */
async function handleTestListConfigResult(message) {
  const { results } = message;
  console.log('[Popup] 测试列表配置结果:', results);

  const { getListFieldName } = await import('./state/index.js');

  addLog('info', '=== 列表字段测试结果 ===');

  Object.entries(results).forEach(([field, value]) => {
    const fieldName = getListFieldName(field);
    if (value && value.length > 0) {
      const preview = Array.isArray(value) ? value.join(', ') : value;
      addLog('success', `✓ ${fieldName}: ${preview.substring(0, 50)}${preview.length > 50 ? '...' : ''}`);
    } else {
      addLog('error', `✗ ${fieldName}: 未提取到数据`);
    }
  });

  addLog('info', '=== 测试完成 ===');
}

/**
 * 重置采集状态
 */
function resetScrapingState(keepStatusText = false) {
  updateState({ isScraping: false });
  elements.startBtn.disabled = false;
  elements.startBtn.style.display = 'inline-flex';
  elements.stopBtn.style.display = 'none';
  elements.stopBtn.disabled = false;
  elements.progressSection.style.display = 'none';

  if (!keepStatusText && state.scrapedJobs.length === 0) {
    elements.statusText.textContent = '采集失败';
  }
}

/**
 * 重置深度采集状态
 */
function resetDeepScrapingState() {
  updateState({
    isDeepScraping: false,
    deepScrapePaused: false
  });
  elements.deepScrapeBtn.disabled = false;
  elements.deepScrapeBtn.style.display = 'inline-flex';
  elements.pauseDeepBtn.style.display = 'none';
  elements.exportBtn.disabled = false;
}

/**
 * 测试静默抓取可行性
 */
async function handleTestSilentFetch() {
  console.log('[Popup] 测试静默抓取...');
  addLog('info', '开始测试静默抓取可行性...');

  try {
    // 获取当前标签页
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // 验证是否为 Boss 直聘详情页
    if (!tab.url.includes('zhipin.com/job_detail')) {
      addLog('error', '请先打开任意 Boss 直聘职位详情页');
      alert('请先打开任意 Boss 直聘职位详情页再测试');
      return;
    }

    const testUrl = tab.url;
    addLog('info', `测试 URL: ${testUrl.substring(0, 60)}...`);

    // 禁用按钮，防止重复点击
    elements.testSilentFetchBtn.disabled = true;
    elements.testSilentFetchBtn.textContent = '测试中...';

    // 使用 fetch 获取页面 HTML
    const startTime = Date.now();
    const response = await fetch(testUrl);
    const html = await response.text();
    const fetchTime = Date.now() - startTime;

    // 分析结果
    addLog('info', `✓ Fetch 成功 (耗时: ${fetchTime}ms)`);
    addLog('info', `HTML 长度: ${html.length} 字符`);

    // 检查关键内容
    const checks = {
      '职位描述': html.includes('职位描述') || html.includes('职位要求'),
      '薪资信息': html.includes('薪资') || html.includes('工资') || html.includes('K/月'),
      'HR信息': html.includes('hr') || html.includes('招聘者') || html.includes('活跃'),
      '公司规模': html.includes('公司规模') || html.includes('人数'),
      '福利待遇': html.includes('福利') || html.includes('五险')
    };

    addLog('info', '=== 关键内容检测 ===');
    let successCount = 0;
    for (const [name, found] of Object.entries(checks)) {
      if (found) {
        addLog('success', `✓ ${name}: 已找到`);
        successCount++;
      } else {
        addLog('warning', `✗ ${name}: 未找到`);
      }
    }

    // 使用 DOMParser 解析 HTML 测试
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    addLog('info', '=== DOM 解析测试 ===');

    // 测试一些常见的选择器
    const testSelectors = [
      { name: '职位标题', selector: 'h1, .job-title, .detail-title' },
      { name: '薪资', selector: '.salary, .job-salary, [class*="salary"]' },
      { name: '公司名称', selector: '.company-name, .company, [class*="company"]' }
    ];

    for (const { name, selector } of testSelectors) {
      const element = doc.querySelector(selector);
      if (element) {
        const text = element.textContent.trim().substring(0, 50);
        addLog('success', `✓ ${name}: ${text}${element.textContent.length > 50 ? '...' : ''}`);
      } else {
        addLog('warning', `✗ ${name}: 选择器未匹配`);
      }
    }

    // 总结
    addLog('info', '=== 测试总结 ===');
    if (successCount >= 3) {
      addLog('success', `✓ 静默抓取可行！检测到 ${successCount}/5 个关键内容`);
      addLog('info', '建议：可以使用 fetch + DOMParser 实现后台静默抓取');
    } else if (successCount >= 1) {
      addLog('warning', `⚠ 部分可行：检测到 ${successCount}/5 个关键内容`);
      addLog('info', '建议：某些字段可能需要调整选择器或使用其他方案');
    } else {
      addLog('error', '✗ 静默抓取不可行：未检测到关键内容');
      addLog('info', '原因：页面可能使用前端渲染，需要执行 JavaScript');
      addLog('info', '建议：使用 offscreen API 或保持当前的 window.open 方案');
    }

    // 将完整 HTML 输出到控制台供进一步分析
    console.log('[Test] HTML 预览:', html.substring(0, 2000));
    addLog('info', '完整 HTML 已输出到浏览器控制台（F12查看）');

  } catch (error) {
    console.error('[Popup] 测试失败:', error);
    addLog('error', `测试失败: ${error.message}`);

    if (error.message.includes('Failed to fetch')) {
      addLog('info', '可能原因：CORS 限制或网络问题');
    }
  } finally {
    // 恢复按钮状态
    elements.testSilentFetchBtn.disabled = false;
    elements.testSilentFetchBtn.innerHTML = '<span class="btn-icon">🔬</span><span>测试静默抓取可行性</span>';
  }
}

/**
 * 页面加载完成后初始化
 */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// 导出主要函数供调试使用
window.popupApp = {
  init,
  state,
  elements,
  checkCurrentTab,
  loadState
};