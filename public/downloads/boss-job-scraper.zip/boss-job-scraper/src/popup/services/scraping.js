/**
 * 采集服务模块
 * 处理采集相关的消息发送和状态管理
 */

/**
 * 获取当前活动标签页
 */
export async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

/**
 * 检查当前标签页是否为 Boss 直聘页面
 */
export async function checkBossTab() {
  const tab = await getCurrentTab();

  if (!tab.url || !tab.url.includes('zhipin.com')) {
    throw new Error('请在 Boss 直聘页面使用');
  }

  return tab;
}

/**
 * 向 content script 发送消息
 */
export async function sendMessageToContent(message) {
  const tab = await getCurrentTab();
  return chrome.tabs.sendMessage(tab.id, message);
}

/**
 * Ping content script 检查是否就绪
 */
export async function pingContentScript() {
  try {
    await sendMessageToContent({ action: 'ping' });
    return true;
  } catch (error) {
    console.warn('[ScrapingService] Content script 未加载:', error);
    return false;
  }
}

/**
 * 激活元素选择器
 */
export async function activateSelector() {
  await checkBossTab();
  return sendMessageToContent({ action: 'activateSelector' });
}

/**
 * 开始采集
 */
export async function startScraping(config) {
  await checkBossTab();
  return sendMessageToContent({
    action: 'startScraping',
    config: config
  });
}

/**
 * 停止采集
 */
export async function stopScraping() {
  await checkBossTab();
  return sendMessageToContent({
    action: 'stopScraping'
  });
}

/**
 * 开始深度采集
 */
export async function startDeepScraping(config) {
  await checkBossTab();
  return sendMessageToContent({
    action: 'startDeepScraping',
    config: config
  });
}

/**
 * 暂停深度采集
 */
export async function pauseDeepScraping() {
  await checkBossTab();
  return sendMessageToContent({
    action: 'pauseDeepScraping'
  });
}

/**
 * 继续深度采集
 */
export async function resumeDeepScraping() {
  await checkBossTab();
  return sendMessageToContent({
    action: 'resumeDeepScraping'
  });
}

/**
 * 配置详情页字段
 */
export async function configureDetailField(field, fieldName) {
  const tab = await getCurrentTab();

  // 检查是否在详情页
  if (!tab.url || !tab.url.includes('zhipin.com/job_detail')) {
    throw new Error('请先打开任意一个职位详情页！\n\n提示：在列表页点击任意职位，打开详情页后再配置。');
  }

  return sendMessageToContent({
    action: 'configureDetailField',
    field: field,
    fieldName: fieldName
  });
}

/**
 * 测试详情页配置
 */
export async function testDetailConfig(selectors) {
  const tab = await getCurrentTab();

  if (!tab.url || !tab.url.includes('zhipin.com/job_detail')) {
    throw new Error('请在职位详情页测试配置！');
  }

  return sendMessageToContent({
    action: 'testDetailConfig',
    selectors: selectors
  });
}

/**
 * 配置列表页字段
 */
export async function configureListField(field, fieldName) {
  await checkBossTab();

  return sendMessageToContent({
    action: 'configureListField',
    field: field,
    fieldName: fieldName
  });
}

/**
 * 测试列表页配置
 */
export async function testListConfig(selectors, listSelector) {
  await checkBossTab();

  return sendMessageToContent({
    action: 'testListConfig',
    selectors: selectors,
    listSelector: listSelector
  });
}