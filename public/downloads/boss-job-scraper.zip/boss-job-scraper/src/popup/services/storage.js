/**
 * 存储服务模块
 * 封装所有 chrome.storage 操作
 */

/**
 * 保存选择器到存储
 */
export async function saveSelectedSelector(selector) {
  await chrome.storage.local.set({
    selectedSelector: selector
  });
}

/**
 * 保存采集的职位数据到存储
 */
export async function saveScrapedJobs(jobs) {
  await chrome.storage.local.set({
    scrapedJobs: jobs
  });
}

/**
 * 保存详情页字段选择器到存储
 */
export async function saveDetailFieldSelectors(selectors) {
  await chrome.storage.local.set({
    detailFieldSelectors: selectors
  });
}

/**
 * 保存列表页字段选择器到存储
 */
export async function saveListFieldSelectors(selectors) {
  await chrome.storage.local.set({
    listFieldSelectors: selectors
  });
}

/**
 * 从存储中加载保存的状态
 */
export async function loadStoredState() {
  const data = await chrome.storage.local.get([
    'selectedSelector',
    'scrapedJobs',
    'detailFieldSelectors',
    'listFieldSelectors'
  ]);

  return {
    selectedSelector: data.selectedSelector || null,
    scrapedJobs: data.scrapedJobs || [],
    detailFieldSelectors: data.detailFieldSelectors || {},
    listFieldSelectors: data.listFieldSelectors || {}
  };
}

/**
 * 清除存储中的所有数据
 */
export async function clearAllStorage() {
  await chrome.storage.local.clear();
}

/**
 * 清除特定键的存储数据
 */
export async function clearStorageKeys(keys) {
  await chrome.storage.local.remove(keys);
}