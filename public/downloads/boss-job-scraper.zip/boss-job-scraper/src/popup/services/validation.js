/**
 * 验证服务模块
 * 包含配置验证和数据验证相关逻辑
 */

/**
 * 验证采集配置
 */
export function validateScrapingConfig(config) {
  const errors = [];

  // 验证延迟设置
  if (config.scrollDelay < 100) {
    errors.push('滚动延迟不能少于 100ms');
  }

  if (config.scrollDelay > 10000) {
    errors.push('滚动延迟不能超过 10 秒');
  }

  // 验证限制数量
  if (config.enableLimit) {
    if (!config.limitNumber || config.limitNumber < 1) {
      errors.push('限制数量必须大于 0');
    }

    if (config.limitNumber > 1000) {
      errors.push('限制数量不能超过 1000');
    }
  }

  return {
    isValid: errors.length === 0,
    errors: errors
  };
}

/**
 * 验证深度采集配置
 */
export function validateDeepScrapingConfig(config) {
  const errors = [];

  // 验证职位数据
  if (!config.jobs || config.jobs.length === 0) {
    errors.push('没有可采集的职位数据');
  }

  // 验证延迟设置
  if (config.detailDelay < 500) {
    errors.push('详情页延迟不能少于 500ms');
  }

  if (config.detailDelay > 30000) {
    errors.push('详情页延迟不能超过 30 秒');
  }

  return {
    isValid: errors.length === 0,
    errors: errors
  };
}

/**
 * 验证字段选择器配置
 */
export function validateFieldSelectors(selectors) {
  const errors = [];
  const validFields = ['salary', 'description', 'welfare', 'hrActivity', 'companySize', 'industry'];

  Object.entries(selectors).forEach(([field, selector]) => {
    if (!validFields.includes(field)) {
      errors.push(`未知的字段类型: ${field}`);
    }

    if (!selector || typeof selector !== 'string') {
      errors.push(`字段 ${field} 的选择器无效`);
    }

    if (selector.length > 500) {
      errors.push(`字段 ${field} 的选择器过长`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors: errors
  };
}

/**
 * 验证列表字段选择器配置
 */
export function validateListFieldSelectors(selectors) {
  const errors = [];
  const validFields = ['title', 'company', 'location', 'experience', 'education'];

  Object.entries(selectors).forEach(([field, selector]) => {
    if (!validFields.includes(field)) {
      errors.push(`未知的列表字段类型: ${field}`);
    }

    if (!selector || typeof selector !== 'string') {
      errors.push(`列表字段 ${field} 的选择器无效`);
    }

    if (selector.length > 500) {
      errors.push(`列表字段 ${field} 的选择器过长`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors: errors
  };
}

/**
 * 验证职位数据格式
 */
export function validateJobData(job) {
  const warnings = [];

  if (!job.title || job.title.trim() === '') {
    warnings.push('职位名称为空');
  }

  if (!job.company || job.company.trim() === '') {
    warnings.push('公司名称为空');
  }

  if (!job.jobUrl || !job.jobUrl.startsWith('http')) {
    warnings.push('职位链接无效');
  }

  return {
    hasWarnings: warnings.length > 0,
    warnings: warnings
  };
}

/**
 * 验证导出数据
 */
export function validateExportData(jobs) {
  if (!Array.isArray(jobs)) {
    return {
      isValid: false,
      errors: ['数据格式无效']
    };
  }

  if (jobs.length === 0) {
    return {
      isValid: false,
      errors: ['没有可导出的数据']
    };
  }

  const warnings = [];
  jobs.forEach((job, index) => {
    const validation = validateJobData(job);
    if (validation.hasWarnings) {
      warnings.push(`第 ${index + 1} 条数据: ${validation.warnings.join(', ')}`);
    }
  });

  return {
    isValid: true,
    warnings: warnings
  };
}

/**
 * 验证 URL 是否为 Boss 直聘页面
 */
export function validateBossUrl(url) {
  if (!url) {
    return {
      isValid: false,
      error: 'URL 不能为空'
    };
  }

  if (!url.includes('zhipin.com')) {
    return {
      isValid: false,
      error: '不是 Boss 直聘页面'
    };
  }

  return {
    isValid: true
  };
}