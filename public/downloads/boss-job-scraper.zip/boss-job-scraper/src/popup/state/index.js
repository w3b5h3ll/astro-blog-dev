/**
 * 状态管理模块
 * 管理 popup 的全局状态和状态操作函数
 */

// 全局状态对象
export const state = {
  selectedSelector: null,
  scrapedJobs: [],
  isScraping: false,
  isDeepScraping: false,
  deepScrapePaused: false,
  detailFieldSelectors: {}, // 详情页字段选择器配置
  listFieldSelectors: {}, // 列表页字段选择器配置
  configuringField: null // 当前正在配置的字段
};

/**
 * 更新状态的工具函数
 */
export function updateState(updates) {
  Object.assign(state, updates);
}

/**
 * 重置采集状态
 */
export function resetScrapingState() {
  state.isScraping = false;
}

/**
 * 重置深度采集状态
 */
export function resetDeepScrapingState() {
  state.isDeepScraping = false;
  state.deepScrapePaused = false;
}

/**
 * 设置选择的选择器
 */
export function setSelectedSelector(selector) {
  state.selectedSelector = selector;
}

/**
 * 设置采集的职位数据
 */
export function setScrapedJobs(jobs) {
  state.scrapedJobs = jobs;
}

/**
 * 添加详情页字段选择器
 */
export function addDetailFieldSelector(field, selector) {
  state.detailFieldSelectors[field] = selector;
}

/**
 * 移除详情页字段选择器
 */
export function removeDetailFieldSelector(field) {
  delete state.detailFieldSelectors[field];
}

/**
 * 添加列表页字段选择器
 */
export function addListFieldSelector(field, selector) {
  state.listFieldSelectors[field] = selector;
}

/**
 * 移除列表页字段选择器
 */
export function removeListFieldSelector(field) {
  delete state.listFieldSelectors[field];
}

/**
 * 设置当前配置中的字段
 */
export function setConfiguringField(field) {
  state.configuringField = field;
}

/**
 * 获取状态的只读副本
 */
export function getState() {
  return { ...state };
}

/**
 * 获取详情页字段名称映射
 */
export function getDetailFieldName(field) {
  const names = {
    salary: '薪资范围',
    description: '职位描述',
    welfare: '福利待遇',
    hrActivity: 'HR活跃状态',
    companySize: '公司规模',
    industry: '所属行业'
  };
  return names[field] || field;
}

/**
 * 获取列表页字段名称映射
 */
export function getListFieldName(field) {
  const names = {
    title: '职位名称',
    company: '公司名称',
    location: '工作地点',
    experience: '工作经验',
    education: '学历要求'
  };
  return names[field] || field;
}