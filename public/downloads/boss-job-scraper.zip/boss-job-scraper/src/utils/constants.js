// 通用常量定义
export const CONSTANTS = {
  // 网站相关
  SITE_URL: 'https://www.zhipin.com',
  SITE_NAME: 'Boss 直聘',

  // 采集配置
  DEFAULT_SCROLL_DELAY: 1000,
  DEFAULT_DETAIL_DELAY: 2000,
  MAX_JOB_LIMIT: 10000,
  DEFAULT_LIMIT: 10,

  // 日志配置
  MAX_LOG_COUNT: 100,

  // 存储键
  STORAGE_KEYS: {
    SELECTED_SELECTOR: 'selectedSelector',
    SCRAPED_JOBS: 'scrapedJobs',
    DETAIL_FIELD_SELECTORS: 'detailFieldSelectors',
    LIST_FIELD_SELECTORS: 'listFieldSelectors',
    CONFIG: 'config'
  },

  // 消息类型
  MESSAGE_TYPES: {
    PING: 'ping',
    ACTIVATE_SELECTOR: 'activateSelector',
    START_SCRAPING: 'startScraping',
    STOP_SCRAPING: 'stopScraping',
    START_DEEP_SCRAPING: 'startDeepScraping',
    PAUSE_DEEP_SCRAPING: 'pauseDeepScraping',
    RESUME_DEEP_SCRAPING: 'resumeDeepScraping',
    UPDATE_PROGRESS: 'updateProgress',
    SCRAPING_COMPLETE: 'scrapingComplete',
    SCRAPING_ERROR: 'scrapingError',
    SCRAPING_STOPPED: 'scrapingStopped'
  },

  // 字段名称映射
  FIELD_NAMES: {
    // 详情页字段
    salary: '薪资范围',
    description: '职位描述',
    welfare: '福利待遇',
    hrActivity: 'HR活跃状态',
    companySize: '公司规模',
    industry: '所属行业',

    // 列表页字段
    title: '职位名称',
    company: '公司名称',
    location: '工作地点',
    experience: '工作经验',
    education: '学历要求'
  }
};
